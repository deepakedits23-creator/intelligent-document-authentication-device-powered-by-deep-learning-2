import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  checkBackendHealth, 
  uploadAndVerifyDocument, 
  verifyCameraCapture, 
  loadDemoScenario, 
  getVerificationHistory,
  getApiBaseUrl,
  setApiBaseUrl,
  isForceDemoMode,
  setForceDemoMode
} from '../services/api';
import { DEMO_SCENARIOS, INITIAL_VERIFICATION_HISTORY } from '../data/mockData';

const AppContext = createContext(null);

export const PROCESSING_STAGES = [
  { step: 1, name: "Image Preprocessing & Deskew", desc: "Bilateral filtering, CLAHE contrast balance & edge normalization" },
  { step: 2, name: "Multi-Stage OCR Text Extraction", desc: "Parsing holder name, document serial ID, issuing authority & dates" },
  { step: 3, name: "Explainable Image Forensics (ELA)", desc: "Detecting localized JPEG compression variances & spliced patch boundaries" },
  { step: 4, name: "Authoritative Registry Ledger Lookup", desc: "Cross-referencing institutional databases for identity collision checks" },
  { step: 5, name: "Deterministic Decision Synthesis", desc: "Applying zero-trust decision rules & generating cryptographic SHA-256 report" },
];

export const AppProvider = ({ children }) => {
  const [currentPage, setCurrentPage] = useState('home');
  const [currentResult, setCurrentResult] = useState(null);
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem('IDAS_HISTORY');
    return saved ? JSON.parse(saved) : INITIAL_VERIFICATION_HISTORY;
  });
  const [backendHealth, setBackendHealth] = useState({ isLive: false, mode: 'checking', details: null });
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStageIndex, setProcessingStageIndex] = useState(0);
  const [toasts, setToasts] = useState([]);
  const [settings, setSettings] = useState({
    apiBaseUrl: getApiBaseUrl(),
    forceDemo: isForceDemoMode(),
    cameraDeviceId: 'default',
    autoWarp: true,
    confidenceThreshold: 85,
  });

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('IDAS_HISTORY', JSON.stringify(history));
  }, [history]);

  // Check backend health on mount and periodically
  const checkHealth = useCallback(async () => {
    const health = await checkBackendHealth();
    setBackendHealth(health);
  }, []);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 15000);
    return () => clearInterval(interval);
  }, [checkHealth]);

  // Add toast notification
  const addToast = (toast) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    const newToast = { id, type: 'info', ...toast };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  };

  const removeToast = (id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add item to history
  const addHistoryItem = (item) => {
    setHistory((prev) => [item, ...prev]);
  };

  const deleteHistoryItem = (id) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
    addToast({ type: 'info', title: 'Case Removed', message: `Case ${id} deleted from audit log.` });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('IDAS_HISTORY');
    addToast({ type: 'info', title: 'History Cleared', message: 'Verification audit history has been reset.' });
  };

  // Update Settings
  const updateSettings = (newSettings) => {
    setSettings((prev) => {
      const merged = { ...prev, ...newSettings };
      if (newSettings.apiBaseUrl !== undefined) {
        setApiBaseUrl(newSettings.apiBaseUrl);
      }
      if (newSettings.forceDemo !== undefined) {
        setForceDemoMode(newSettings.forceDemo);
      }
      return merged;
    });
    checkHealth();
    addToast({ type: 'success', title: 'Settings Saved', message: 'Preferences updated successfully.' });
  };

  // Run animated verification pipeline
  const runVerification = async (fileOrBlob, isCamera = false) => {
    setIsProcessing(true);
    setProcessingStageIndex(0);

    // Staged animation progress
    const stageInterval = setInterval(() => {
      setProcessingStageIndex((prev) => {
        if (prev < PROCESSING_STAGES.length - 1) return prev + 1;
        return prev;
      });
    }, 700);

    try {
      let result;
      if (isCamera) {
        result = await verifyCameraCapture(fileOrBlob, settings.autoWarp);
      } else {
        result = await uploadAndVerifyDocument(fileOrBlob);
      }

      // Allow stages to complete visibly
      await new Promise((r) => setTimeout(r, 2600));
      clearInterval(stageInterval);

      setCurrentResult(result);
      addHistoryItem({
        id: result.caseUid,
        docName: result.fileName,
        docType: result.extractedData?.doc_type || 'Document',
        holderName: result.extractedData?.holder_name || 'N/A',
        timestamp: new Date().toLocaleString(),
        status: result.outcome,
        badge: result.statusBadge,
        confidence: result.confidence,
        fileSize: isCamera ? '1.4 MB' : `${Math.round(fileOrBlob.size / 1024)} KB`,
        sha256: result.fileHash || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        summary: result.decisionReason,
      });

      setIsProcessing(false);
      setCurrentPage('results');

      addToast({
        type: result.statusBadge === 'genuine' ? 'success' : result.statusBadge === 'forged' ? 'error' : 'warning',
        title: 'Verification Complete',
        message: `Outcome: ${result.outcome}`
      });
      return result;
    } catch (err) {
      clearInterval(stageInterval);
      setIsProcessing(false);
      addToast({
        type: 'error',
        title: 'Verification Failed',
        message: err.message || 'Error executing verification pipeline.'
      });
      throw err;
    }
  };

  // Run demo scenario directly
  const runDemoScenario = async (scenarioId) => {
    setIsProcessing(true);
    setProcessingStageIndex(0);

    const stageInterval = setInterval(() => {
      setProcessingStageIndex((prev) => (prev < PROCESSING_STAGES.length - 1 ? prev + 1 : prev));
    }, 550);

    try {
      const result = await loadDemoScenario(scenarioId);
      await new Promise((r) => setTimeout(r, 1800));
      clearInterval(stageInterval);

      setCurrentResult(result);
      addHistoryItem({
        id: result.caseUid,
        docName: result.fileName,
        docType: result.extractedData?.doc_type || 'Document',
        holderName: result.extractedData?.holder_name || 'N/A',
        timestamp: new Date().toLocaleString(),
        status: result.outcome,
        badge: result.statusBadge,
        confidence: result.confidence,
        fileSize: '1.2 MB',
        sha256: result.fileHash,
        summary: result.decisionReason,
      });

      setIsProcessing(false);
      setCurrentPage('results');
      return result;
    } catch (err) {
      clearInterval(stageInterval);
      setIsProcessing(false);
      addToast({
        type: 'error',
        title: 'Demo Error',
        message: err.message || 'Could not load demo scenario.'
      });
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        currentResult,
        setCurrentResult,
        history,
        addHistoryItem,
        deleteHistoryItem,
        clearHistory,
        backendHealth,
        checkHealth,
        settings,
        updateSettings,
        toasts,
        addToast,
        removeToast,
        isProcessing,
        processingStageIndex,
        runVerification,
        runDemoScenario,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
