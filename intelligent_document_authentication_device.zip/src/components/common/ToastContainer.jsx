import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertTriangle, XCircle, Info, X } from 'lucide-react';

export const ToastContainer = () => {
  const { toasts, removeToast } = useApp();

  if (!toasts.length) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        let border = 'border-cyan-500/40 bg-navy-900/90 text-cyan-200';
        let Icon = Info;
        if (toast.type === 'success') {
          border = 'border-emerald-500/50 bg-emerald-950/90 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.25)]';
          Icon = CheckCircle2;
        } else if (toast.type === 'error') {
          border = 'border-rose-500/50 bg-rose-950/90 text-rose-200 shadow-[0_0_20px_rgba(244,63,94,0.25)]';
          Icon = XCircle;
        } else if (toast.type === 'warning') {
          border = 'border-amber-500/50 bg-amber-950/90 text-amber-200 shadow-[0_0_20px_rgba(245,158,11,0.25)]';
          Icon = AlertTriangle;
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl border backdrop-blur-xl shadow-xl transition-all duration-300 animate-slideUp ${border}`}
          >
            <Icon className="w-5 h-5 shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              {toast.title && <div className="font-bold text-slate-100">{toast.title}</div>}
              <div className="text-slate-300 mt-0.5 leading-relaxed">{toast.message}</div>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-100 transition-colors p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
