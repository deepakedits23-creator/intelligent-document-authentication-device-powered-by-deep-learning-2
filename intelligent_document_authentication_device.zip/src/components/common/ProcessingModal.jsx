import React from 'react';
import { useApp, PROCESSING_STAGES } from '../../context/AppContext';
import { Shield, CheckCircle2, Loader2, Sparkles, Binary, Cpu } from 'lucide-react';

export const ProcessingModal = () => {
  const { isProcessing, processingStageIndex } = useApp();

  if (!isProcessing) return null;

  const currentStage = PROCESSING_STAGES[processingStageIndex] || PROCESSING_STAGES[0];
  const progressPercent = Math.min(100, Math.round(((processingStageIndex + 1) / PROCESSING_STAGES.length) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl rounded-2xl border border-cyan-500/40 bg-navy-900/90 shadow-[0_0_50px_rgba(0,240,255,0.25)] p-6 md:p-8 overflow-hidden">
        {/* Animated Cyber Background Accents */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-center justify-between pb-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="relative p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="w-6 h-6 animate-pulse" />
              <div className="absolute inset-0 rounded-xl border border-cyan-400/40 animate-ping opacity-30" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-100 text-lg">AI Verification Engine</h3>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Active
                </span>
              </div>
              <p className="text-xs text-slate-400">Deep-learning multi-stage forensic analysis in progress</p>
            </div>
          </div>
          <div className="text-right font-mono">
            <span className="text-2xl font-black text-cyan-400">{progressPercent}%</span>
          </div>
        </div>

        {/* Radar / Scanner Visualizer */}
        <div className="relative my-6 h-28 rounded-xl bg-navy-950/90 border border-cyan-500/20 overflow-hidden flex items-center justify-center">
          {/* Cyber Grid Lines */}
          <div className="absolute inset-0 cyber-grid opacity-40" />

          {/* Laser Scanner Bar */}
          <div className="laser-scanner" />

          {/* Central Target Display */}
          <div className="relative z-10 flex flex-col items-center gap-2 text-center px-4">
            <div className="flex items-center gap-2 font-mono text-xs text-cyan-300">
              <Binary className="w-4 h-4 animate-spin text-cyan-400" />
              <span className="tracking-widest uppercase">STAGE {processingStageIndex + 1} OF 5</span>
            </div>
            <div className="font-semibold text-slate-100 text-sm md:text-base">
              {currentStage.name}
            </div>
            <div className="text-xs text-slate-400 max-w-sm line-clamp-1">
              {currentStage.desc}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative w-full h-2 bg-navy-950 rounded-full overflow-hidden border border-slate-800 mb-6">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-400 transition-all duration-500 ease-out shadow-[0_0_12px_#00F0FF]"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Stage Steps List */}
        <div className="space-y-2.5">
          {PROCESSING_STAGES.map((st, idx) => {
            const isCompleted = idx < processingStageIndex;
            const isCurrent = idx === processingStageIndex;
            return (
              <div
                key={st.step}
                className={`flex items-center gap-3 p-2.5 rounded-lg border transition-all text-xs font-mono ${
                  isCurrent
                    ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-200'
                    : isCompleted
                    ? 'bg-navy-950/40 border-slate-800 text-slate-400'
                    : 'bg-transparent border-transparent text-slate-600'
                }`}
              >
                <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : isCurrent ? (
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                  ) : (
                    <div className="w-2 h-2 rounded-full bg-slate-700" />
                  )}
                </div>
                <div className="flex-1 truncate">
                  <span className={isCurrent ? 'font-semibold text-cyan-300' : ''}>
                    {st.step}. {st.name}
                  </span>
                </div>
                {isCompleted && <span className="text-[10px] text-emerald-400 font-bold uppercase">Passed</span>}
                {isCurrent && <span className="text-[10px] text-cyan-400 animate-pulse font-bold uppercase">Running</span>}
              </div>
            );
          })}
        </div>

        {/* Security Notice */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
          <span className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-500/70" />
            Offline Neural Pipeline (Zero Speculation)
          </span>
          <span>SHA-256 Guard</span>
        </div>
      </div>
    </div>
  );
};
