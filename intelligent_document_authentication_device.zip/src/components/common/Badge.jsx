import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Shield, Info } from 'lucide-react';

export const Badge = ({ status = 'genuine', text, size = 'md', className = '' }) => {
  const normalized = (status || '').toLowerCase();

  let styles = 'bg-slate-800/80 text-slate-300 border-slate-700';
  let Icon = Info;
  let defaultText = 'Pending';
  let dotColor = 'bg-slate-400';

  if (normalized.includes('genuine') || normalized.includes('real') || normalized.includes('verified')) {
    styles = 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)]';
    Icon = CheckCircle2;
    defaultText = 'GENUINE — VERIFIED';
    dotColor = 'bg-emerald-400 shadow-[0_0_8px_#34d399]';
  } else if (normalized.includes('forged') || normalized.includes('fake') || normalized.includes('evidence')) {
    styles = 'bg-rose-950/60 text-rose-300 border-rose-500/40 shadow-[0_0_15px_rgba(244,63,94,0.2)]';
    Icon = XCircle;
    defaultText = 'POTENTIALLY FORGED';
    dotColor = 'bg-rose-400 shadow-[0_0_8px_#fb7185]';
  } else if (normalized.includes('inconclusive') || normalized.includes('suspicious') || normalized.includes('manual') || normalized.includes('review')) {
    styles = 'bg-amber-950/60 text-amber-300 border-amber-500/40 shadow-[0_0_15px_rgba(245,158,11,0.2)]';
    Icon = AlertTriangle;
    defaultText = 'INCONCLUSIVE — REVIEW';
    dotColor = 'bg-amber-400 shadow-[0_0_8px_#fbbf24]';
  }

  const sizeClasses = {
    sm: 'text-xs px-2.5 py-0.5 gap-1.5',
    md: 'text-xs font-semibold px-3 py-1 gap-2',
    lg: 'text-sm font-bold px-4 py-1.5 gap-2.5 tracking-wide',
  }[size] || 'text-xs px-3 py-1 gap-2';

  return (
    <span className={`inline-flex items-center rounded-full border backdrop-blur-md ${styles} ${sizeClasses} ${className}`}>
      <span className={`w-2 h-2 rounded-full animate-pulse ${dotColor}`} />
      <Icon className={size === 'lg' ? 'w-4 h-4' : 'w-3.5 h-3.5'} />
      <span>{text || defaultText}</span>
    </span>
  );
};
