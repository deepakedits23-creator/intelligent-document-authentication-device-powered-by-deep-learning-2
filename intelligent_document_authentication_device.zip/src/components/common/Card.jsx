import React from 'react';

export const Card = ({
  children,
  className = '',
  title,
  subtitle,
  icon: Icon,
  badge,
  action,
  glow = false,
  glowColor = 'cyan',
  hover = true,
  onClick,
}) => {
  const glowBorder = {
    cyan: 'border-cyan-500/30 hover:border-cyan-400/60 hover:shadow-[0_0_25px_rgba(0,240,255,0.18)]',
    blue: 'border-blue-500/30 hover:border-blue-400/60 hover:shadow-[0_0_25px_rgba(37,99,235,0.22)]',
    emerald: 'border-emerald-500/30 hover:border-emerald-400/60 hover:shadow-[0_0_25px_rgba(16,185,129,0.22)]',
    crimson: 'border-rose-500/30 hover:border-rose-400/60 hover:shadow-[0_0_25px_rgba(244,63,94,0.22)]',
    amber: 'border-amber-500/30 hover:border-amber-400/60 hover:shadow-[0_0_25px_rgba(245,158,11,0.22)]',
  }[glowColor] || 'border-cyan-500/20';

  return (
    <div
      onClick={onClick}
      className={`relative rounded-xl border bg-navy-900/70 backdrop-blur-xl p-5 md:p-6 transition-all duration-300 ${
        glow ? glowBorder : 'border-slate-800/80 hover:border-slate-700/80'
      } ${hover ? 'hover:-translate-y-0.5' : ''} ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {(title || Icon || badge || action) && (
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800/60">
          <div className="flex items-center gap-3">
            {Icon && (
              <div className="p-2 rounded-lg bg-navy-800/80 border border-cyan-500/20 text-cyan-400">
                <Icon className="w-5 h-5" />
              </div>
            )}
            <div>
              {title && <h3 className="font-semibold text-slate-100 text-base">{title}</h3>}
              {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {badge && <div>{badge}</div>}
            {action && <div>{action}</div>}
          </div>
        </div>
      )}
      {children}
    </div>
  );
};
