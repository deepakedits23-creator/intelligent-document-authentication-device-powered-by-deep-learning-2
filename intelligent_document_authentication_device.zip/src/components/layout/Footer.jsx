import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Heart, Terminal, Lock, Cpu, Sparkles } from 'lucide-react';

export const Footer = () => {
  const { setCurrentPage } = useApp();

  return (
    <footer className="mt-20 border-t border-cyan-500/15 bg-navy-950/90 backdrop-blur-xl relative overflow-hidden">
      {/* Decorative gradient blur */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Column 1: Identity & Hackathon Credit */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-base tracking-tight text-slate-100">
                Intelligent Document Authentication System
              </span>
            </div>
            <p className="text-sm text-slate-400 max-w-md leading-relaxed">
              AI-Powered Document Verification & Forgery Detection built for <strong className="text-cyan-300">QUANTIX 2K26 — 24-Hour Hackathon</strong> by <strong className="text-slate-200">Team Nexora</strong> (Leader: S. Deepak | L. Dhanushya, M. S. Elamparuthi, G. Kavin). Unifying multi-stage OCR entity extraction, PyTorch deep learning, and explainable Error Level Analysis (ELA) forensics.
            </p>
            <div className="flex flex-wrap gap-2 text-xs font-mono text-cyan-400/80">
              <span className="px-2.5 py-1 rounded bg-navy-900 border border-slate-800">React + Vite</span>
              <span className="px-2.5 py-1 rounded bg-navy-900 border border-slate-800">Tailwind CSS</span>
              <span className="px-2.5 py-1 rounded bg-navy-900 border border-slate-800">FastAPI Backend Ready</span>
              <span className="px-2.5 py-1 rounded bg-navy-900 border border-slate-800">OpenCV + ELA Forensics</span>
            </div>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
              Core Navigation
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => setCurrentPage('home')} className="hover:text-cyan-300 transition-colors">
                  Home Landing
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('dashboard')} className="hover:text-cyan-300 transition-colors">
                  Executive Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('verify')} className="hover:text-cyan-300 transition-colors">
                  Verify Document / Webcam
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('demos')} className="hover:text-cyan-300 transition-colors">
                  Interactive Demo Center
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('history')} className="hover:text-cyan-300 transition-colors">
                  Audit History Logs
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Documentation & Jury Info */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
              Jury Reference
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => setCurrentPage('how-it-works')} className="hover:text-cyan-300 transition-colors">
                  How The AI Pipeline Works
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('about')} className="hover:text-cyan-300 transition-colors">
                  About Team & Mission
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage('settings')} className="hover:text-cyan-300 transition-colors">
                  Backend API & Device Settings
                </button>
              </li>
              <li className="pt-2">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-[11px] font-mono">
                  <Lock className="w-3 h-3" />
                  100% Offline Capable
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Disclaimer & Copyright */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 Intelligent Document Authentication System. Built for QUANTIX 2K26.</p>
          <p className="text-[11px] text-slate-400/80 max-w-md text-center sm:text-right">
            Important Notice: Simulated demonstration cases are designed for hackathon evaluation and do not replace legal forensic handwriting examination.
          </p>
        </div>
      </div>
    </footer>
  );
};
