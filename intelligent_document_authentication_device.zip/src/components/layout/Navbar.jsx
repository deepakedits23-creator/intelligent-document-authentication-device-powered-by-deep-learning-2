import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShieldCheck, 
  LayoutDashboard, 
  FileCheck2, 
  FlaskConical, 
  History, 
  HelpCircle, 
  Info, 
  Settings, 
  Menu, 
  X, 
  Cpu, 
  Sparkles,
  Wifi,
  WifiOff
} from 'lucide-react';

export const Navbar = () => {
  const { currentPage, setCurrentPage, backendHealth } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: ShieldCheck },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'verify', label: 'Verify Document', icon: FileCheck2 },
    { id: 'demos', label: 'Demo Center', icon: FlaskConical },
    { id: 'history', label: 'Audit History', icon: History },
    { id: 'how-it-works', label: 'How It Works', icon: HelpCircle },
    { id: 'about', label: 'About', icon: Info },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (id) => {
    setCurrentPage(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-cyan-500/15 bg-navy-950/80 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          
          {/* Logo & Project Identity */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative p-2.5 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/40 text-cyan-400 group-hover:border-cyan-300 group-hover:shadow-[0_0_20px_rgba(0,240,255,0.4)] transition-all duration-300">
              <ShieldCheck className="w-6 h-6 md:w-7 md:h-7" />
              <div className="absolute inset-0 rounded-xl bg-cyan-400/10 blur-sm group-hover:bg-cyan-400/20 transition-all" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base md:text-lg tracking-tight bg-gradient-to-r from-slate-100 via-cyan-100 to-cyan-300 bg-clip-text text-transparent">
                  IDAS
                </span>
                <span className="hidden sm:inline-block text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-900/60 text-cyan-300 border border-cyan-500/30">
                  AI Forensics v2.0
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-400 font-medium">
                Intelligent Document Authentication System
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                      : 'text-slate-300 hover:text-cyan-300 hover:bg-navy-900/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 md:gap-3">
            {/* Backend Connectivity Status Pill */}
            <div 
              onClick={() => handleNavClick('settings')}
              title={backendHealth.isLive ? 'Connected to live FastAPI backend' : 'Running in Offline / Demo Simulation Mode'}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono border cursor-pointer transition-all hover:opacity-90"
              style={{
                backgroundColor: backendHealth.isLive ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)',
                borderColor: backendHealth.isLive ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)',
                color: backendHealth.isLive ? '#34d399' : '#fbbf24',
              }}
            >
              {backendHealth.isLive ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping opacity-75" />
                  <Wifi className="w-3 h-3 text-emerald-400" />
                  <span>FastAPI Live</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <Cpu className="w-3 h-3 text-amber-400" />
                  <span>Demo Mode</span>
                </>
              )}
            </div>

            {/* Quick Action Button */}
            <button
              onClick={() => handleNavClick('verify')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-navy-950 shadow-[0_0_20px_rgba(0,240,255,0.35)] transition-all active:scale-95"
            >
              <FileCheck2 className="w-4 h-4 text-navy-950" />
              <span>Verify Doc</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg bg-navy-900 border border-slate-700 text-slate-300 hover:text-cyan-400"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-cyan-500/20 bg-navy-950/95 backdrop-blur-2xl px-4 pt-3 pb-6 space-y-2 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-800">
            <span className="text-xs font-mono text-slate-400">Navigation Menu</span>
            <div 
              onClick={() => handleNavClick('settings')}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono border"
              style={{
                backgroundColor: backendHealth.isLive ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)',
                borderColor: backendHealth.isLive ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)',
                color: backendHealth.isLive ? '#34d399' : '#fbbf24',
              }}
            >
              {backendHealth.isLive ? 'FastAPI Connected' : 'Demo Simulation Mode'}
            </div>
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-300 hover:bg-navy-900 hover:text-cyan-400'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
