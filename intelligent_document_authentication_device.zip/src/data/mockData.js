// Mock & Demo Data for Intelligent Document Authentication System
// All demo data is clearly identified as simulated data for hackathon demonstrations.

export const MOCK_STATS = {
  totalChecked: 142,
  genuineCount: 98,
  forgedCount: 31,
  inconclusiveCount: 13,
  successRate: 98.6,
  avgProcessingTimeSec: 1.42,
  lastUpdated: new Date().toISOString(),
  trends: {
    totalCheckedGrowth: "+18.4% this week",
    genuineRate: "69.0%",
    forgeryRate: "21.8%",
    inconclusiveRate: "9.2%",
  }
};

export const MOCK_CHART_HISTORY = [
  { day: "Mon", genuine: 14, forged: 4, inconclusive: 1 },
  { day: "Tue", genuine: 18, forged: 6, inconclusive: 2 },
  { day: "Wed", genuine: 22, forged: 5, inconclusive: 3 },
  { day: "Thu", genuine: 16, forged: 8, inconclusive: 2 },
  { day: "Fri", genuine: 24, forged: 5, inconclusive: 3 },
  { day: "Sat", genuine: 20, forged: 2, inconclusive: 1 },
  { day: "Sun", genuine: 28, forged: 7, inconclusive: 3 },
];

export const MOCK_DOC_TYPES = [
  { name: "Academic Degrees & Diplomas", percentage: 42, count: 60, color: "#00F0FF" },
  { name: "National ID Cards / Passports", percentage: 28, count: 40, color: "#2563EB" },
  { name: "Employment & Experience Letters", percentage: 18, count: 26, color: "#10B981" },
  { name: "Financial & Tax Records", percentage: 12, count: 16, color: "#F59E0B" },
];

export const DEMO_SCENARIOS = [
  {
    id: "sample-1",
    scenarioKey: "REAL",
    title: "Scenario 1: Verified Degree Certificate",
    subtitle: "REAL — VERIFIED",
    docType: "Degree Certificate",
    outcome: "REAL — VERIFIED",
    statusBadge: "genuine",
    badgeColor: "emerald",
    filename: "sample1_verified_degree.png",
    previewUrl: "/samples/sample1_verified_degree.png",
    localFallbackUrl: "/samples/sample1_verified_degree.png",
    description: "Authentic university degree certificate. The Document ID matches the authoritative college registry ledger with zero compression tampering or spliced boundary anomalies.",
    highlights: [
      "Authoritative ledger match found in registry",
      "ELA image compression is completely uniform (mean difference 8.2)",
      "Zero gradient edge discontinuities or spliced patches",
      "Typography & layout alignment integrity verified"
    ],
    confidence: 99.2,
    caseUid: "QV-2026-DEMO-001",
    timestamp: "2026-10-23T11:45:00Z",
    extractedData: {
      doc_type: "Bachelor of Technology (Computer Science)",
      doc_number: "KSR-2026-ENG-8492",
      holder_name: "DEEPAK KUMAR S",
      issue_date: "2026-05-18",
      issuer_name: "KSR Educational Institutions",
      cgpa_or_grade: "First Class with Distinction (8.92 CGPA)",
      verification_status: "Verified in National Academic Depository"
    },
    forensicData: {
      ela_anomaly_detected: false,
      ela_mean_difference: 8.2,
      laplacian_blur_score: 284.5,
      is_blurry: false,
      edge_discontinuities: 0,
      metadata_footprint: "Clean vector rendering, no editing software signatures detected",
      evidence_list: [
        { label: "Authoritative Registry Lookup", passed: true, note: "Confirmed active in institutional registry" },
        { label: "Error Level Analysis (ELA)", passed: true, note: "Uniform compression across all text blocks" },
        { label: "Resolution & Focus Quality", passed: true, note: "Sharp high-frequency details (Laplacian: 284.5)" },
        { label: "EXIF & Software Footprints", passed: true, note: "No Photoshop/GIMP editing signatures" }
      ]
    },
    decisionReason: "Authoritative registry record matched with zero forensic anomalies. The certificate meets all cryptographic and physical credential integrity criteria."
  },
  {
    id: "sample-2",
    scenarioKey: "FAKE",
    title: "Scenario 2: Altered Identity / Field Mismatch",
    subtitle: "FAKE — EVIDENCE FOUND",
    docType: "National Identity Card",
    outcome: "FAKE — EVIDENCE FOUND",
    statusBadge: "forged",
    badgeColor: "crimson",
    filename: "sample2_altered_identity.png",
    previewUrl: "/samples/sample2_altered_identity.png",
    localFallbackUrl: "/samples/sample2_altered_identity.png",
    description: "The registered document ID exists in the national database for 'Priya Sharma', but the visual card was altered to display 'Robert Vance' with spliced text and photo boundary artifacts.",
    highlights: [
      "Registry identity collision: ID belongs to Priya Sharma, not Robert Vance",
      "High ELA variance around name field and photo box (score: 41.8)",
      "Spliced boundary edge discontinuity detected",
      "Adobe Photoshop signature in embedded metadata"
    ],
    confidence: 34.6,
    caseUid: "QV-2026-DEMO-002",
    timestamp: "2026-10-23T10:15:00Z",
    extractedData: {
      doc_type: "National Identity Smart Card",
      doc_number: "NAT-2026-ID-4410",
      holder_name: "ROBERT VANCE",
      issue_date: "2024-03-12",
      issuer_name: "Department of National Registration",
      registered_holder_conflict: "PRIYA SHARMA (Registry record)",
      verification_status: "IDENTITY CONFLICT DETECTED"
    },
    forensicData: {
      ela_anomaly_detected: true,
      ela_mean_difference: 41.8,
      laplacian_blur_score: 210.0,
      is_blurry: false,
      edge_discontinuities: 4,
      metadata_footprint: "Adobe Photoshop CC 2024 (Windows) detected in XMP chunk",
      suspicious_boxes: [
        { label: "Altered Name Block", x: "28%", y: "42%", width: "45%", height: "12%" },
        { label: "Spliced Photo Boundary", x: "65%", y: "25%", width: "28%", height: "45%" }
      ],
      evidence_list: [
        { label: "Authoritative Registry Conflict", passed: false, note: "Document ID registered to a different person" },
        { label: "Error Level Analysis (ELA)", passed: false, note: "Localized high resaving error rate around name patch" },
        { label: "Edge Discontinuity Inspection", passed: false, note: "Artificial sharp boundary transitions found" },
        { label: "Digital Editing Footprint", passed: false, note: "Photoshop modification timestamp found in metadata" }
      ]
    },
    decisionReason: "Flagrant credential fraud detected: The extracted document ID is legally assigned to another identity in the authoritative registry, corroborated by high localized compression discrepancies."
  },
  {
    id: "sample-3",
    scenarioKey: "INCONCLUSIVE",
    title: "Scenario 3: Degraded Scan / Insufficient Evidence",
    subtitle: "INCONCLUSIVE — MANUAL REVIEW REQUIRED",
    docType: "Academic Transcript",
    outcome: "INCONCLUSIVE — MANUAL REVIEW REQUIRED",
    statusBadge: "inconclusive",
    badgeColor: "amber",
    filename: "sample4_blurry_scan.png",
    previewUrl: "/samples/sample4_blurry_scan.png",
    localFallbackUrl: "/samples/sample4_blurry_scan.png",
    description: "Heavily blurred or degraded capture. OCR text recognition confidence is low and image resolution is inadequate to definitively rule in or rule out tampering.",
    highlights: [
      "Laplace variance below threshold (score: 42.1 vs required 95.0)",
      "Partial OCR character loss on serial number and seal",
      "No authoritative digital watermark or QR payload accessible",
      "Human expert verification recommended"
    ],
    confidence: null, // As required: no fake confidence score when inconclusive
    caseUid: "QV-2026-DEMO-003",
    timestamp: "2026-10-23T09:30:00Z",
    extractedData: {
      doc_type: "Official Academic Transcript (Partial)",
      doc_number: "TR-2025-??-91[UNREADABLE]",
      holder_name: "ALEXANDER M[AMBIGUOUS]",
      issue_date: "2023-??-??",
      issuer_name: "State Board of Technical Education",
      verification_status: "UNRESOLVED - OCR CONFIDENCE INSUFFICIENT"
    },
    forensicData: {
      ela_anomaly_detected: false,
      ela_mean_difference: 14.5,
      laplacian_blur_score: 42.1,
      is_blurry: true,
      edge_discontinuities: 0,
      metadata_footprint: "Mobile camera capture with heavy motion compression",
      evidence_list: [
        { label: "Authoritative Registry Lookup", passed: false, note: "Serial number partially obscured; cannot query ledger" },
        { label: "Image Clarity & Focus", passed: false, note: "Severe motion blur (Laplacian score: 42.1 < 95.0)" },
        { label: "Error Level Analysis (ELA)", passed: true, note: "No obvious digital splicing discovered, but inconclusive" },
        { label: "Seal & Pattern Inspection", passed: false, note: "Embossed seal micro-printing details blurred" }
      ]
    },
    decisionReason: "Automated verification aborted safely: Insufficient optical resolution and high blur score prevent conclusive determination. Manual institutional audit required."
  }
];

export const INITIAL_VERIFICATION_HISTORY = [
  {
    id: "QV-2026-8812B4",
    docName: "KSR_University_Degree_Deepak.pdf",
    docType: "Degree Certificate",
    holderName: "Deepak Kumar S",
    timestamp: "2026-10-23 11:45 AM",
    status: "REAL — VERIFIED",
    badge: "genuine",
    confidence: 99.2,
    fileSize: "1.8 MB",
    sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    summary: "Authoritative college ledger matched with 0 forensic tampering flags."
  },
  {
    id: "QV-2026-9041A1",
    docName: "National_ID_Card_Altered.png",
    docType: "National ID Card",
    holderName: "Robert Vance (Priya Sharma)",
    timestamp: "2026-10-23 10:15 AM",
    status: "FAKE — EVIDENCE FOUND",
    badge: "forged",
    confidence: 34.6,
    fileSize: "842 KB",
    sha256: "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb",
    summary: "Identity mismatch with national registry + ELA splicing around name field."
  },
  {
    id: "QV-2026-7734C9",
    docName: "Transcript_Blurry_Scan.jpg",
    docType: "Academic Transcript",
    holderName: "Alexander M (Partial)",
    timestamp: "2026-10-23 09:30 AM",
    status: "INCONCLUSIVE — MANUAL REVIEW REQUIRED",
    badge: "inconclusive",
    confidence: null,
    fileSize: "614 KB",
    sha256: "8743b52063cd84097a65d1633f5c74f5",
    summary: "Severe motion blur (score 42.1) prevents conclusive automated determination."
  },
  {
    id: "QV-2026-6218D3",
    docName: "Employment_Experience_Letter.pdf",
    docType: "Experience Certificate",
    holderName: "Vikram Malhotra",
    timestamp: "2026-10-22 04:20 PM",
    status: "REAL — VERIFIED",
    badge: "genuine",
    confidence: 97.8,
    fileSize: "1.2 MB",
    sha256: "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
    summary: "Corporate HR registry verified with uniform typographic font consistency."
  },
  {
    id: "QV-2026-5590E8",
    docName: "Passport_Front_Page.jpg",
    docType: "Passport Document",
    holderName: "Kavitha R",
    timestamp: "2026-10-22 02:10 PM",
    status: "REAL — VERIFIED",
    badge: "genuine",
    confidence: 98.4,
    fileSize: "2.4 MB",
    sha256: "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a",
    summary: "MRZ machine-readable checksum matched with optical face hologram boundary."
  },
  {
    id: "QV-2026-4412F2",
    docName: "Bank_Statement_May2026.pdf",
    docType: "Financial Statement",
    holderName: "Arun Patel",
    timestamp: "2026-10-22 11:05 AM",
    status: "FAKE — EVIDENCE FOUND",
    badge: "forged",
    confidence: 28.9,
    fileSize: "1.5 MB",
    sha256: "ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d",
    summary: "Font glyph kerning alteration and modified transaction balance row detected."
  },
  {
    id: "QV-2026-3389G5",
    docName: "Provisional_Degree_Certificate.png",
    docType: "Degree Certificate",
    holderName: "Ananya Deshmukh",
    timestamp: "2026-10-21 05:40 PM",
    status: "INCONCLUSIVE — MANUAL REVIEW REQUIRED",
    badge: "inconclusive",
    confidence: null,
    fileSize: "920 KB",
    sha256: "1e4a6486fa411c57e8fa1c4f6b4618e00c3b88b0ea17a02796dc957c9cfb7218",
    summary: "Unregistered institutional code not found in central registrar network."
  }
];
