import React from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { 
  ShieldCheck, 
  FileSearch, 
  Camera, 
  FlaskConical, 
  Layers, 
  Lock, 
  Cpu, 
  Activity, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Sparkles,
  Zap,
  ChevronRight
} from 'lucide-react';

export const HomePage = () => {
  const { setCurrentPage, runDemoScenario } = useApp();

  return (
    <div className="space-y-16 md:space-y-24">
      
      {/* Hero Section */}
      <section className="relative pt-6 md:pt-12 pb-8 overflow-hidden">
        {/* Glowing backdrop elements */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-blue-600/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center space-y-6 relative z-10">
          
          {/* Hackathon Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-navy-900/90 border border-cyan-500/30 text-xs font-mono text-cyan-300 shadow-[0_0_20px_rgba(0,240,255,0.2)]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
            <span>QUANTIX 2K26 — Hackathon Jury Demonstration</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-100 leading-[1.1]">
            Intelligent Document <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 bg-clip-text text-transparent drop-shadow-sm">
              Authentication System
            </span>
          </h1>

          {/* Tagline */}
          <p className="text-lg sm:text-xl md:text-2xl text-slate-300 font-light max-w-3xl mx-auto leading-relaxed">
            AI-Powered Document Verification &amp; Forgery Detection
          </p>

          <p className="text-sm md:text-base text-slate-400 max-w-2xl mx-auto">
            Combines multi-stage OCR entity extraction, explainable Error Level Analysis (ELA) image forensics, and zero-trust authoritative registry cross-examination.
          </p>

          {/* Action CTAs */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
            <Button
              size="lg"
              variant="primary"
              icon={FileSearch}
              onClick={() => setCurrentPage('verify')}
              className="text-base px-8 py-3.5"
            >
              Verify Document Now
            </Button>

            <Button
              size="lg"
              variant="secondary"
              icon={FlaskConical}
              onClick={() => setCurrentPage('demos')}
              className="text-base px-6 py-3.5"
            >
              Test Demo Scenarios
            </Button>
          </div>

          {/* Live Metrics Quick Strip */}
          <div className="pt-10 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto text-left font-mono">
            <div className="p-3.5 rounded-xl bg-navy-900/70 border border-slate-800 backdrop-blur-md">
              <span className="text-[11px] text-slate-400 uppercase">Detection Speed</span>
              <div className="text-xl font-bold text-cyan-400 mt-0.5">~1.4 sec</div>
              <span className="text-[10px] text-emerald-400">Offline Optimized</span>
            </div>
            <div className="p-3.5 rounded-xl bg-navy-900/70 border border-slate-800 backdrop-blur-md">
              <span className="text-[11px] text-slate-400 uppercase">Forensic Engine</span>
              <div className="text-xl font-bold text-slate-200 mt-0.5">Multi-Stage ELA</div>
              <span className="text-[10px] text-cyan-400">Explainable Heatmaps</span>
            </div>
            <div className="p-3.5 rounded-xl bg-navy-900/70 border border-slate-800 backdrop-blur-md">
              <span className="text-[11px] text-slate-400 uppercase">Inference Policy</span>
              <div className="text-xl font-bold text-slate-200 mt-0.5">Zero-Trust</div>
              <span className="text-[10px] text-amber-400">No Speculation</span>
            </div>
            <div className="p-3.5 rounded-xl bg-navy-900/70 border border-slate-800 backdrop-blur-md">
              <span className="text-[11px] text-slate-400 uppercase">Audit Defense</span>
              <div className="text-xl font-bold text-emerald-400 mt-0.5">SHA-256</div>
              <span className="text-[10px] text-slate-400">Cryptographic Trail</span>
            </div>
          </div>

        </div>
      </section>

      {/* Interactive 3 Outcome Preview Strip */}
      <section className="space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-400 uppercase tracking-widest">
            <Activity className="w-3.5 h-3.5" />
            <span>Deterministic Three-Way Verdicts</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-100">
            Defensible &amp; Explainable Outcomes
          </h2>
          <p className="text-sm text-slate-400 max-w-xl mx-auto">
            Instead of opaque "black-box" guessing, the system enforces three strict, auditable outcome categories:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Genuine Card */}
          <Card
            glow
            glowColor="emerald"
            className="flex flex-col justify-between"
            title="REAL — VERIFIED"
            icon={CheckCircle2}
            badge={<Badge status="genuine" text="Authoritative" size="sm" />}
          >
            <div className="space-y-3 my-2 text-xs text-slate-300">
              <p className="leading-relaxed">
                Document identifier and credentials match an authoritative issuing registry ledger with zero forensic image anomalies.
              </p>
              <ul className="space-y-1.5 text-slate-400 font-mono text-[11px]">
                <li className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Registry confirmed active
                </li>
                <li className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Uniform compression rate
                </li>
                <li className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Zero spliced boundaries
                </li>
              </ul>
            </div>
            <div className="pt-4 border-t border-slate-800">
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => runDemoScenario('sample-1')}
              >
                Launch Genuine Demo
              </Button>
            </div>
          </Card>

          {/* Forged Card */}
          <Card
            glow
            glowColor="crimson"
            className="flex flex-col justify-between"
            title="FAKE — EVIDENCE FOUND"
            icon={XCircle}
            badge={<Badge status="forged" text="Tampering Flag" size="sm" />}
          >
            <div className="space-y-3 my-2 text-xs text-slate-300">
              <p className="leading-relaxed">
                Reliable evidence of fraud uncovered: registry identity mismatch or corroborating forensic tampering (ELA resaving artifacts + edge splicing).
              </p>
              <ul className="space-y-1.5 text-slate-400 font-mono text-[11px]">
                <li className="flex items-center gap-1.5 text-rose-400">
                  <XCircle className="w-3.5 h-3.5" /> Altered name / identity conflict
                </li>
                <li className="flex items-center gap-1.5 text-rose-400">
                  <XCircle className="w-3.5 h-3.5" /> ELA compression variance &gt; 35
                </li>
                <li className="flex items-center gap-1.5 text-rose-400">
                  <XCircle className="w-3.5 h-3.5" /> Photoshop metadata detected
                </li>
              </ul>
            </div>
            <div className="pt-4 border-t border-slate-800">
              <Button
                variant="danger"
                size="sm"
                className="w-full"
                onClick={() => runDemoScenario('sample-2')}
              >
                Launch Forged Demo
              </Button>
            </div>
          </Card>

          {/* Inconclusive Card */}
          <Card
            glow
            glowColor="amber"
            className="flex flex-col justify-between"
            title="INCONCLUSIVE"
            subtitle="MANUAL REVIEW REQUIRED"
            icon={AlertTriangle}
            badge={<Badge status="inconclusive" text="Caution" size="sm" />}
          >
            <div className="space-y-3 my-2 text-xs text-slate-300">
              <p className="leading-relaxed">
                Safe default for ambiguous cases: Severe motion blur, low OCR confidence, degraded scanning, or unregistered institutional credentials.
              </p>
              <ul className="space-y-1.5 text-slate-400 font-mono text-[11px]">
                <li className="flex items-center gap-1.5 text-amber-400">
                  <AlertTriangle className="w-3.5 h-3.5" /> Defocus / blur score &lt; 95.0
                </li>
                <li className="flex items-center gap-1.5 text-amber-400">
                  <AlertTriangle className="w-3.5 h-3.5" /> Ambiguous seal or pattern
                </li>
                <li className="flex items-center gap-1.5 text-amber-400">
                  <AlertTriangle className="w-3.5 h-3.5" /> Manual audit checklist provided
                </li>
              </ul>
            </div>
            <div className="pt-4 border-t border-slate-800">
              <Button
                variant="glass"
                size="sm"
                className="w-full text-amber-300 hover:border-amber-400"
                onClick={() => runDemoScenario('sample-3')}
              >
                Launch Inconclusive Demo
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Key Architectural Pillars */}
      <section className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest">
              Core Capabilities
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-100 mt-1">
              Multi-Layered Verification Architecture
            </h2>
          </div>
          <Button
            variant="outline"
            size="sm"
            icon={ChevronRight}
            iconPosition="right"
            onClick={() => setCurrentPage('how-it-works')}
          >
            Explore Pipeline Details
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          <Card glow glowColor="cyan" className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FileSearch className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-100 text-base">Multi-Engine OCR</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Combines Windows native neural OCR, PyPDF vector parsing, and PyTesseract fallback to extract structured fields reliably.
            </p>
          </Card>

          <Card glow glowColor="blue" className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-100 text-base">Image Forensics (ELA)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Error Level Analysis resaves frames at 90% quality to isolate non-uniform compression error rates and spliced patches.
            </p>
          </Card>

          <Card glow glowColor="emerald" className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-100 text-base">Registry Ledger</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Zero-trust cross-referencing against authoritative issuer ledgers and synthetic credential databases to prevent identity collisions.
            </p>
          </Card>

          <Card glow glowColor="amber" className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Camera className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-100 text-base">Webcam Scanner</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Real-time browser camera ingestion with document boundary frame, perspective deskewing, and live blur/lighting diagnostics.
            </p>
          </Card>
        </div>
      </section>

      {/* Quick Launch Banner for Hackathon Jury */}
      <section className="relative rounded-2xl border border-cyan-500/30 bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 p-8 md:p-12 overflow-hidden shadow-[0_0_50px_rgba(0,240,255,0.15)]">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-mono">
            <Zap className="w-3.5 h-3.5" />
            Ready for Live Presentation
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
            Start Live Document Examination
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Drag-and-drop any academic certificate, national ID, or financial document — or switch to the laptop webcam for live interactive capture.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <Button
              variant="primary"
              size="md"
              icon={FileSearch}
              onClick={() => setCurrentPage('verify')}
            >
              Open Verification Workspace
            </Button>
            <Button
              variant="secondary"
              size="md"
              icon={FlaskConical}
              onClick={() => setCurrentPage('demos')}
            >
              Explore Demo Cases
            </Button>
          </div>
        </div>
      </section>

    </div>
  );
};
