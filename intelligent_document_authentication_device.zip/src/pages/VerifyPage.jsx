import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { 
  Upload, 
  Camera, 
  FileText, 
  Image as ImageIcon, 
  Trash2, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Scan, 
  Eye, 
  Cpu, 
  Layers, 
  SlidersHorizontal,
  Video,
  VideoOff,
  Sparkles
} from 'lucide-react';

export const VerifyPage = () => {
  const { runVerification, isProcessing, addToast } = useApp();
  const [activeTab, setActiveTab] = useState('upload'); // 'upload' | 'camera'

  // Upload State
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const fileInputRef = useRef(null);

  // Camera State
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState(null);
  const [capturedBlob, setCapturedBlob] = useState(null);
  const [capturedPreview, setCapturedPreview] = useState(null);
  const [cameraError, setCameraError] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Pipeline Options
  const [pipelineOptions, setPipelineOptions] = useState({
    runELA: true,
    runOCR: true,
    crossMatchRegistry: true,
    autoWarp: true,
  });

  const MAX_FILE_SIZE = 15 * 1024 * 1024; // 15MB
  const ALLOWED_EXTS = ['.pdf', '.png', '.jpg', '.jpeg'];

  // Handle File Selection
  const validateAndSelectFile = (file) => {
    setUploadError(null);
    if (!file) return;

    const ext = '.' + file.name.split('.').pop().toLowerCase();
    if (!ALLOWED_EXTS.includes(ext)) {
      setUploadError(`Unsupported file format '${ext}'. Please upload a PDF, PNG, JPG, or JPEG.`);
      addToast({ type: 'error', title: 'Invalid File Format', message: `Only PDF, PNG, JPG, and JPEG files are supported.` });
      return;
    }

    if (file.size > MAX_FILE_SIZE) {
      setUploadError(`File is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Maximum limit is 15 MB.`);
      addToast({ type: 'error', title: 'File Too Large', message: 'Maximum allowed file size is 15 MB.' });
      return;
    }

    setSelectedFile(file);
    if (file.type.startsWith('image/')) {
      const previewUrl = URL.createObjectURL(file);
      setFilePreview(previewUrl);
    } else {
      setFilePreview(null);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSelectFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleRemoveFile = () => {
    if (filePreview) URL.revokeObjectURL(filePreview);
    setSelectedFile(null);
    setFilePreview(null);
    setUploadError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // ==================== CAMERA OPERATIONS ====================

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access is not supported by your browser.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          facingMode: 'user',
        },
      });
      setCameraStream(stream);
      setCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      let errorMsg = 'Could not access the laptop camera.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = 'Camera permission was denied. Please allow camera access in your browser settings to scan documents live.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        errorMsg = 'No camera device found on this laptop.';
      } else if (err.name === 'NotReadableError') {
        errorMsg = 'Camera is currently in use by another application.';
      }
      setCameraError(errorMsg);
      setCameraActive(false);
      addToast({ type: 'error', title: 'Camera Error', message: errorMsg });
    }
  };

  const stopCamera = useCallback(() => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
    setCameraActive(false);
  }, [cameraStream]);

  // Clean up camera stream on tab change or unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  const captureSnapshot = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (!blob) return;
      setCapturedBlob(blob);
      const url = URL.createObjectURL(blob);
      setCapturedPreview(url);
      stopCamera();
    }, 'image/jpeg', 0.95);
  };

  const handleRetakeSnapshot = () => {
    if (capturedPreview) URL.revokeObjectURL(capturedPreview);
    setCapturedBlob(null);
    setCapturedPreview(null);
    startCamera();
  };

  // Quick-load demo sample directly into intake
  const loadQuickSample = async (filename, title) => {
    try {
      const res = await fetch(`/samples/${filename}`);
      if (!res.ok) throw new Error('Could not fetch sample document');
      const blob = await res.blob();
      const file = new File([blob], filename, { type: 'image/png' });
      validateAndSelectFile(file);
      addToast({
        type: 'info',
        title: 'Demo Sample Loaded',
        message: `Loaded ${title}. Click 'Verify Document with AI Forensics' below to execute analysis.`
      });
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Sample Load Failed',
        message: err.message
      });
    }
  };

  // ==================== VERIFICATION TRIGGER ====================

  const handleStartVerification = async () => {
    if (activeTab === 'upload') {
      if (!selectedFile) {
        setUploadError('Please select or drop a document to verify, or click one of the 1-Click Demo Samples below.');
        addToast({
          type: 'warning',
          title: 'Document Required',
          message: 'Please choose or drag-and-drop a file, or click a 1-Click Demo Sample below before verifying.'
        });
        return;
      }
      try {
        await runVerification(selectedFile, false);
      } catch (err) {
        console.error(err);
      }
    } else {
      if (!capturedBlob) {
        setCameraError('Please capture a document snapshot before verifying.');
        addToast({
          type: 'warning',
          title: 'Camera Snapshot Required',
          message: 'Please start the webcam and click "Capture Document Snapshot" before verifying.'
        });
        return;
      }
      try {
        await runVerification(capturedBlob, true);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      
      {/* Title & Introduction */}
      <div className="space-y-2 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
          <Scan className="w-3.5 h-3.5" />
          <span>Interactive Document Intake</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
          Document Verification Workspace
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Ingest credentials via secure drag-and-drop or position your physical document before the live laptop camera scanner.
        </p>
      </div>

      {/* Intake Method Tabs */}
      <div className="flex rounded-xl bg-navy-900/80 p-1.5 border border-slate-800 backdrop-blur-md">
        <button
          onClick={() => {
            stopCamera();
            setActiveTab('upload');
          }}
          className={`flex-1 flex items-center justify-center gap-2.5 py-3 rounded-lg text-sm font-semibold transition-all ${
            activeTab === 'upload'
              ? 'bg-gradient-to-r from-cyan-500/20 to-blue-600/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span>Upload File (PDF / Images)</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('camera');
            if (!capturedBlob) startCamera();
          }}
          className={`flex-1 flex items-center justify-center gap-2.5 py-3 rounded-lg text-sm font-semibold transition-all ${
            activeTab === 'camera'
              ? 'bg-gradient-to-r from-cyan-500/20 to-blue-600/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Live Laptop Webcam Scanner</span>
        </button>
      </div>

      {/* ==================== TAB A: FILE UPLOAD ==================== */}
      {activeTab === 'upload' && (
        <Card className="space-y-6">
          {!selectedFile ? (
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className={`relative border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-300 ${
                isDragOver
                  ? 'border-cyan-400 bg-cyan-500/10 shadow-[0_0_30px_rgba(0,240,255,0.25)] scale-[1.01]'
                  : 'border-slate-700/80 hover:border-cyan-500/50 hover:bg-navy-850/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    validateAndSelectFile(e.target.files[0]);
                  }
                }}
              />

              <div className="flex flex-col items-center gap-4">
                <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                  <Upload className="w-8 h-8 sm:w-10 sm:h-10 animate-bounce" />
                </div>
                <div className="space-y-1.5">
                  <h3 className="text-base sm:text-lg font-bold text-slate-100">
                    Drag and drop your document here
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400">
                    Supports <strong className="text-cyan-300">PDF, JPG, JPEG, and PNG</strong> formats up to 15 MB
                  </p>
                </div>
                <Button variant="outline" size="sm" className="mt-2">
                  Browse Local Files
                </Button>
              </div>
            </div>
          ) : (
            /* Selected File Preview Box */
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-semibold text-slate-200">File Ingested</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={RefreshCw}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    Replace
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    icon={Trash2}
                    onClick={handleRemoveFile}
                  >
                    Remove
                  </Button>
                </div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    validateAndSelectFile(e.target.files[0]);
                  }
                }}
              />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-center p-4 rounded-xl bg-navy-950/80 border border-slate-800">
                {/* Visual Preview */}
                <div className="md:col-span-1 flex items-center justify-center p-2 rounded-lg bg-navy-900 border border-slate-800 min-h-[160px] overflow-hidden">
                  {filePreview ? (
                    <img
                      src={filePreview}
                      alt="Document Preview"
                      className="max-h-36 object-contain rounded shadow"
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-slate-400 py-6">
                      <FileText className="w-12 h-12 text-cyan-400" />
                      <span className="text-[11px] font-mono uppercase">PDF Document</span>
                    </div>
                  )}
                </div>

                {/* File Metadata */}
                <div className="md:col-span-2 space-y-2 text-xs font-mono">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase">File Name</span>
                    <div className="font-semibold text-slate-100 text-sm truncate font-sans">
                      {selectedFile.name}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase">File Size</span>
                      <div className="text-slate-200 font-bold">
                        {(selectedFile.size / 1024).toFixed(1)} KB
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase">MIME Type</span>
                      <div className="text-cyan-300 font-bold">{selectedFile.type || 'Document'}</div>
                    </div>
                  </div>
                  <div className="pt-2 text-[11px] text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>File integrity &amp; format validated. Ready for neural analysis.</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 1-Click Hackathon Sample Cases for Quick Testing */}
          <div className="p-4 rounded-xl bg-navy-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase text-slate-400 flex items-center gap-1.5 font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                1-Click Hackathon Sample Cases
              </span>
              <span className="text-[11px] text-slate-500 font-mono">Load directly into scanner</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => loadQuickSample('sample1_verified_degree.png', 'Sample 1: Legitimate Degree (REAL)')}
                className="p-3 rounded-lg bg-navy-900/90 border border-emerald-500/30 hover:border-emerald-400 hover:bg-emerald-950/30 text-left transition-all group"
              >
                <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
                  <span>Sample 1 (REAL)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Verified</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 group-hover:text-slate-300">Degree Certificate — Deepak</p>
              </button>

              <button
                type="button"
                onClick={() => loadQuickSample('sample2_altered_identity.png', 'Sample 2: Altered Identity (FAKE)')}
                className="p-3 rounded-lg bg-navy-900/90 border border-rose-500/30 hover:border-rose-400 hover:bg-rose-950/30 text-left transition-all group"
              >
                <div className="flex items-center justify-between text-xs font-bold text-rose-400">
                  <span>Sample 2 (FAKE)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">Altered</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 group-hover:text-slate-300">National ID — Spliced Name</p>
              </button>

              <button
                type="button"
                onClick={() => loadQuickSample('sample4_blurry_scan.png', 'Sample 4: Blurry Scan (INCONCLUSIVE)')}
                className="p-3 rounded-lg bg-navy-900/90 border border-amber-500/30 hover:border-amber-400 hover:bg-amber-950/30 text-left transition-all group"
              >
                <div className="flex items-center justify-between text-xs font-bold text-amber-400">
                  <span>Sample 4 (REVIEW)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">Inconclusive</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 group-hover:text-slate-300">Academic Scan — Low Clarity</p>
              </button>
            </div>
          </div>

          {uploadError && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}
        </Card>
      )}

      {/* ==================== TAB B: CAMERA CAPTURE ==================== */}
      {activeTab === 'camera' && (
        <Card className="space-y-6">
          {cameraError && (
            <div className="flex items-start gap-2.5 p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
              <VideoOff className="w-5 h-5 shrink-0 mt-0.5 text-rose-400" />
              <div className="space-y-1">
                <span className="font-bold">Camera Initialization Notice:</span>
                <p className="leading-relaxed">{cameraError}</p>
                <div className="pt-2">
                  <Button variant="outline" size="sm" onClick={startCamera}>
                    Retry Camera Access
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Active Camera Live Stream */}
          {cameraActive && !capturedPreview && (
            <div className="space-y-4">
              <div className="relative rounded-2xl bg-black border border-cyan-500/30 overflow-hidden aspect-video flex items-center justify-center">
                {/* Video Element */}
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />

                {/* Laser scan animation */}
                <div className="laser-scanner" />

                {/* Document Bounding Guide Overlay */}
                <div className="absolute inset-8 sm:inset-12 border-2 border-dashed border-cyan-400/70 rounded-xl pointer-events-none flex flex-col justify-between p-3">
                  <div className="flex justify-between text-[11px] font-mono text-cyan-300 bg-navy-950/70 px-2 py-0.5 rounded self-start">
                    ALIGNED DOCUMENT BOUNDARY GUIDE
                  </div>
                  <div className="flex justify-between items-center text-[10px] font-mono text-slate-300">
                    <span className="bg-navy-950/70 px-2 py-0.5 rounded">Ensure even room lighting</span>
                    <span className="bg-navy-950/70 px-2 py-0.5 rounded">Keep card steady</span>
                  </div>
                </div>

                {/* Target Reticle in Center */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40">
                  <div className="w-12 h-12 border border-cyan-400 rounded-full" />
                </div>
              </div>

              {/* Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Live Video Feed (1080p Resolution)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={VideoOff}
                    onClick={stopCamera}
                  >
                    Turn Off Camera
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    icon={Camera}
                    onClick={captureSnapshot}
                  >
                    Capture Document Image
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Captured Snapshot Preview */}
          {capturedPreview && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Snapshot Captured</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  icon={RefreshCw}
                  onClick={handleRetakeSnapshot}
                >
                  Retake Photo
                </Button>
              </div>

              <div className="relative rounded-2xl bg-navy-950 border border-slate-800 overflow-hidden flex items-center justify-center max-h-96">
                <img
                  src={capturedPreview}
                  alt="Captured Document"
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-navy-950/70 border border-slate-800 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Captured at {new Date().toLocaleTimeString()}</span>
                <span className="text-emerald-400">Resolution: 1920x1080 (Sharp Quality)</span>
              </div>
            </div>
          )}

          {/* If camera is closed and no preview */}
          {!cameraActive && !capturedPreview && !cameraError && (
            <div className="text-center py-12 space-y-4">
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 inline-block">
                <Camera className="w-10 h-10" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-100">Webcam Scanner Ready</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Hold your ID card, academic certificate, or passport in front of your laptop webcam for real-time capture.
                </p>
              </div>
              <Button variant="primary" size="md" icon={Video} onClick={startCamera}>
                Enable Laptop Camera
              </Button>
            </div>
          )}

          {/* Hidden Canvas for Frame Capture */}
          <canvas ref={canvasRef} className="hidden" />
        </Card>
      )}

      {/* ==================== SECTION C: VERIFICATION CONTROLS ==================== */}
      <Card
        glow
        glowColor="cyan"
        className="space-y-5"
        title="Verification Engine Configuration"
        subtitle="Zero-trust forensic parameters applied during screening"
        icon={SlidersHorizontal}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          <label className="flex items-center gap-2 p-2.5 rounded-lg bg-navy-950/60 border border-slate-800 cursor-pointer hover:border-cyan-500/40">
            <input
              type="checkbox"
              checked={pipelineOptions.runOCR}
              onChange={(e) => setPipelineOptions({ ...pipelineOptions, runOCR: e.target.checked })}
              className="accent-cyan-400 w-4 h-4 rounded"
            />
            <span className="text-slate-200">Multi-Stage OCR</span>
          </label>

          <label className="flex items-center gap-2 p-2.5 rounded-lg bg-navy-950/60 border border-slate-800 cursor-pointer hover:border-cyan-500/40">
            <input
              type="checkbox"
              checked={pipelineOptions.runELA}
              onChange={(e) => setPipelineOptions({ ...pipelineOptions, runELA: e.target.checked })}
              className="accent-cyan-400 w-4 h-4 rounded"
            />
            <span className="text-slate-200">Error Level Analysis</span>
          </label>

          <label className="flex items-center gap-2 p-2.5 rounded-lg bg-navy-950/60 border border-slate-800 cursor-pointer hover:border-cyan-500/40">
            <input
              type="checkbox"
              checked={pipelineOptions.crossMatchRegistry}
              onChange={(e) => setPipelineOptions({ ...pipelineOptions, crossMatchRegistry: e.target.checked })}
              className="accent-cyan-400 w-4 h-4 rounded"
            />
            <span className="text-slate-200">Registry Cross-Match</span>
          </label>

          <label className="flex items-center gap-2 p-2.5 rounded-lg bg-navy-950/60 border border-slate-800 cursor-pointer hover:border-cyan-500/40">
            <input
              type="checkbox"
              checked={pipelineOptions.autoWarp}
              onChange={(e) => setPipelineOptions({ ...pipelineOptions, autoWarp: e.target.checked })}
              className="accent-cyan-400 w-4 h-4 rounded"
            />
            <span className="text-slate-200">Auto-Deskew Warp</span>
          </label>
        </div>

        {/* Big Prominent Verify Document Button */}
        <div className="pt-2">
          <Button
            variant="primary"
            size="lg"
            icon={ShieldCheck}
            loading={isProcessing}
            disabled={isProcessing}
            onClick={handleStartVerification}
            className="w-full text-base py-4 font-bold shadow-[0_0_30px_rgba(0,240,255,0.4)]"
          >
            Verify Document with AI Forensics
          </Button>
          <p className="text-center text-[11px] font-mono text-slate-500 mt-2">
            Multi-stage screening initiates Bilateral Preprocessing, OCR entity parsing, and Error Level Analysis.
          </p>
        </div>
      </Card>

    </div>
  );
};
