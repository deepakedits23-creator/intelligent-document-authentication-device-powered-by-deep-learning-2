import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { 
  Settings, 
  Server, 
  Wifi, 
  WifiOff, 
  Camera, 
  Sliders, 
  Trash2, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle,
  Terminal,
  Cpu
} from 'lucide-react';
import { checkBackendHealth } from '../services/api';

export const SettingsPage = () => {
  const { settings, updateSettings, backendHealth, checkHealth, clearHistory, addToast } = useApp();

  const [apiUrl, setApiUrl] = useState(settings.apiBaseUrl);
  const [forceDemo, setForceDemo] = useState(settings.forceDemo);
  const [autoWarp, setAutoWarp] = useState(settings.autoWarp);
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setTestResult(null);
    try {
      const res = await checkBackendHealth();
      setTestResult(res);
      if (res.isLive) {
        addToast({
          type: 'success',
          title: 'Backend Connected',
          message: `Connected to ${res.details?.project || 'FastAPI Service'} (${res.details?.active_engine || 'Neural OCR'})`
        });
      } else {
        addToast({
          type: 'warning',
          title: 'Backend Offline',
          message: 'FastAPI server not responding. Demo mode will continue to handle all verification requests.'
        });
      }
    } catch (err) {
      setTestResult({ isLive: false, error: err.message });
    } finally {
      setTestingConnection(false);
    }
  };

  const handleSaveSettings = () => {
    updateSettings({
      apiBaseUrl: apiUrl,
      forceDemo: forceDemo,
      autoWarp: autoWarp,
    });
  };

  const handleResetDefaults = () => {
    setApiUrl('/api');
    setForceDemo(false);
    setAutoWarp(true);
    updateSettings({
      apiBaseUrl: '/api',
      forceDemo: false,
      autoWarp: true,
    });
    addToast({ type: 'info', title: 'Defaults Restored', message: 'API and camera settings reset to default values.' });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      
      {/* Page Title */}
      <div className="space-y-2 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
          <Settings className="w-4 h-4" />
          <span>System Configuration</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
          Settings &amp; Integration
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Configure API endpoints, camera diagnostics, and toggle between the live deep-learning backend and high-fidelity demo mode.
        </p>
      </div>

      {/* Backend API Configuration Card */}
      <Card
        glow
        glowColor="cyan"
        title="Backend API Service Connection"
        subtitle="Connect to local or remote Python FastAPI / Flask forensic server"
        icon={Server}
        badge={
          backendHealth.isLive ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              FastAPI Server Live
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono bg-amber-950/60 text-amber-300 border border-amber-500/40">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              Offline / Demo Simulation
            </span>
          )
        }
      >
        <div className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-slate-300 font-semibold">
              API Base URL
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                placeholder="/api or http://127.0.0.1:8000/api"
                className="flex-1 px-3.5 py-2 rounded-lg bg-navy-950 border border-slate-700 text-slate-100 text-xs font-mono focus:border-cyan-400 focus:outline-none"
              />
              <Button
                variant="outline"
                size="sm"
                loading={testingConnection}
                onClick={handleTestConnection}
              >
                Test Connection
              </Button>
            </div>
            <p className="text-[11px] text-slate-400">
              Default is <code className="text-cyan-300">/api</code> (proxied via Vite to http://127.0.0.1:8000).
            </p>
          </div>

          {/* Connection Test Output Box */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs font-mono space-y-1 ${
                testResult.isLive
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                  : 'bg-amber-950/30 border-amber-500/40 text-amber-300'
              }`}
            >
              <div className="font-bold flex items-center gap-2">
                {testResult.isLive ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Ping Successful: Backend Responding</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                    <span>Backend Offline or Unreachable</span>
                  </>
                )}
              </div>
              {testResult.details && (
                <div className="text-[11px] text-slate-300 pt-1 space-y-0.5 font-sans">
                  <div>Project: <strong>{testResult.details.project}</strong></div>
                  <div>Active OCR Engine: <strong>{testResult.details.active_engine}</strong></div>
                  <div>Database: <strong>{testResult.details.db_status}</strong></div>
                </div>
              )}
            </div>
          )}

          {/* Force Demo Simulation Mode Toggle */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-mono text-slate-200 font-semibold">
                Force Demo Simulation Mode
              </span>
              <p className="text-[11px] text-slate-400">
                Disables live network calls to Python and runs pre-packaged demo scenarios with instant realistic response.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={forceDemo}
                onChange={(e) => setForceDemo(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-navy-950 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-300 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500 border border-slate-700"></div>
            </label>
          </div>
        </div>
      </Card>

      {/* How to Launch the Python Backend Guide */}
      <Card
        title="How to Connect the Python Backend"
        subtitle="Run the offline deep-learning & image forensics server"
        icon={Terminal}
      >
        <div className="space-y-3 pt-2 text-xs font-mono text-slate-300">
          <p className="text-slate-400 font-sans">
            To activate live multi-stage OCR and Error Level Analysis (ELA) processing on this laptop, open a terminal in the project directory and run:
          </p>
          <div className="p-3.5 rounded-xl bg-navy-950 border border-slate-800 text-cyan-300 select-all font-mono">
            python run.py
          </div>
          <p className="text-[11px] text-slate-500">
            The FastAPI server will start on <strong className="text-slate-300">http://127.0.0.1:8000</strong>. The Vite development server automatically proxies all <code className="text-cyan-400">/api/*</code> requests to it.
          </p>
        </div>
      </Card>

      {/* Camera & Vision Options */}
      <Card
        title="Webcam & Vision Preprocessing"
        subtitle="Adjust perspective deskewing and scanner behavior"
        icon={Camera}
      >
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-mono text-slate-200 font-semibold">
                Automatic Document Perspective Deskewing
              </span>
              <p className="text-[11px] text-slate-400">
                Uses OpenCV 4-point contour transformation to correct trapezoidal tilt when capturing documents from angles.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={autoWarp}
                onChange={(e) => setAutoWarp(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-navy-950 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-300 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500 border border-slate-700"></div>
            </label>
          </div>
        </div>
      </Card>

      {/* Data Management & Save Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
        <Button
          variant="danger"
          size="sm"
          icon={Trash2}
          onClick={clearHistory}
        >
          Clear Audit Logs
        </Button>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            icon={RotateCcw}
            onClick={handleResetDefaults}
          >
            Reset Defaults
          </Button>
          <Button
            variant="primary"
            size="md"
            icon={Save}
            onClick={handleSaveSettings}
          >
            Save Changes
          </Button>
        </div>
      </div>

    </div>
  );
};
