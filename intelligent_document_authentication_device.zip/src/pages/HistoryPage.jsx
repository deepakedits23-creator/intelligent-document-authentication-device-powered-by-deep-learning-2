import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { 
  History, 
  Search, 
  Filter, 
  Download, 
  Eye, 
  Trash2, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  FileText,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export const HistoryPage = () => {
  const { history, setCurrentResult, setCurrentPage, deleteHistoryItem, clearHistory, addToast } = useApp();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [currentPageNum, setCurrentPageNum] = useState(1);
  const itemsPerPage = 6;

  // Filter & Search Logic
  const filteredCases = useMemo(() => {
    return history.filter((item) => {
      const s = searchTerm.toLowerCase();
      const matchesSearch = 
        item.id.toLowerCase().includes(s) ||
        item.docName.toLowerCase().includes(s) ||
        (item.holderName && item.holderName.toLowerCase().includes(s)) ||
        (item.docType && item.docType.toLowerCase().includes(s));

      if (!matchesSearch) return false;

      if (statusFilter === 'ALL') return true;
      if (statusFilter === 'GENUINE') {
        return (item.status || '').toUpperCase().includes('REAL') || (item.status || '').toUpperCase().includes('VERIFIED');
      }
      if (statusFilter === 'FORGED') {
        return (item.status || '').toUpperCase().includes('FAKE') || (item.status || '').toUpperCase().includes('EVIDENCE');
      }
      if (statusFilter === 'INCONCLUSIVE') {
        return (item.status || '').toUpperCase().includes('INCONCLUSIVE') || (item.status || '').toUpperCase().includes('SUSPICIOUS');
      }
      return true;
    });
  }, [history, searchTerm, statusFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredCases.length / itemsPerPage) || 1;
  const paginatedCases = useMemo(() => {
    const start = (currentPageNum - 1) * itemsPerPage;
    return filteredCases.slice(start, start + itemsPerPage);
  }, [filteredCases, currentPageNum]);

  const handleInspect = (caseItem) => {
    setCurrentResult({
      caseUid: caseItem.id,
      fileName: caseItem.docName,
      fileHash: caseItem.sha256,
      timestamp: caseItem.timestamp,
      outcome: caseItem.status,
      statusBadge: caseItem.badge,
      headline: caseItem.summary || caseItem.status,
      decisionReason: caseItem.summary,
      confidence: caseItem.confidence,
      extractedData: {
        doc_type: caseItem.docType,
        holder_name: caseItem.holderName,
        doc_number: caseItem.id,
        issue_date: '2026-05-18',
        issuer_name: 'Authoritative Body',
      },
      forensicData: {
        ela_mean_difference: caseItem.badge === 'forged' ? 41.8 : 8.2,
        laplacian_blur_score: caseItem.badge === 'inconclusive' ? 42.1 : 284.5,
        is_blurry: caseItem.badge === 'inconclusive',
        evidence_list: [
          { label: 'Registry Match', passed: caseItem.badge === 'genuine', note: caseItem.summary },
          { label: 'ELA Uniformity Check', passed: caseItem.badge !== 'forged', note: 'Error rate analyzed' }
        ]
      },
      referenceData: { matched: caseItem.badge === 'genuine' },
      isSimulated: true
    });
    setCurrentPage('results');
  };

  const handleDownloadSingleReport = (caseItem) => {
    const reportData = {
      caseUid: caseItem.id,
      fileName: caseItem.docName,
      holderName: caseItem.holderName,
      timestamp: caseItem.timestamp,
      status: caseItem.status,
      confidence: caseItem.confidence,
      sha256: caseItem.sha256,
      summary: caseItem.summary
    };
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Verification_Certificate_${caseItem.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addToast({
      type: 'success',
      title: 'Report Downloaded',
      message: `Saved Verification_Certificate_${caseItem.id}.json`
    });
  };

  const handleExportCSV = () => {
    const headers = ['Verification ID,Document Name,Holder Name,Document Type,Timestamp,Status,Confidence,SHA256'];
    const rows = history.map(h => 
      `"${h.id}","${h.docName}","${h.holderName}","${h.docType}","${h.timestamp}","${h.status}","${h.confidence || 'N/A'}","${h.sha256}"`
    );
    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `IDAS_Audit_History_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    addToast({ type: 'success', title: 'CSV Exported', message: 'Full audit history exported to CSV.' });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
            <History className="w-3.5 h-3.5" />
            <span>Audit &amp; Forensic Logs</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
            Verification History
          </h1>
          <p className="text-sm text-slate-400">
            Cryptographically sealed verification audits and historical forensic screening records.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Button
            variant="outline"
            size="sm"
            icon={FileSpreadsheet}
            onClick={handleExportCSV}
          >
            Export CSV
          </Button>
          {history.length > 0 && (
            <Button
              variant="danger"
              size="sm"
              icon={Trash2}
              onClick={clearHistory}
            >
              Clear Log
            </Button>
          )}
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <Card className="p-4 space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Search Box */}
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, document, holder name..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPageNum(1);
              }}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-navy-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-slate-100 text-xs font-mono placeholder:text-slate-500"
            />
          </div>

          {/* Status Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto text-xs font-mono">
            {[
              { id: 'ALL', label: 'All Cases' },
              { id: 'GENUINE', label: 'Genuine' },
              { id: 'FORGED', label: 'Forged' },
              { id: 'INCONCLUSIVE', label: 'Inconclusive' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setStatusFilter(tab.id);
                  setCurrentPageNum(1);
                }}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  statusFilter === tab.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'bg-navy-950/60 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

        </div>
      </Card>

      {/* History Table */}
      <Card className="p-0 overflow-hidden">
        {paginatedCases.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-navy-950/80 border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                  <th className="py-3.5 px-4">Verification ID</th>
                  <th className="py-3.5 px-4">Document / Holder</th>
                  <th className="py-3.5 px-4">Date &amp; Time</th>
                  <th className="py-3.5 px-4">Verification Status</th>
                  <th className="py-3.5 px-4">Confidence</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {paginatedCases.map((c) => (
                  <tr key={c.id} className="hover:bg-navy-850/50 transition-colors">
                    {/* ID */}
                    <td className="py-3.5 px-4 font-bold text-cyan-400 whitespace-nowrap">
                      {c.id}
                    </td>

                    {/* Doc / Holder */}
                    <td className="py-3.5 px-4 font-sans">
                      <div className="font-semibold text-slate-100">{c.docName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{c.holderName} • {c.docType}</div>
                    </td>

                    {/* Date */}
                    <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                      {c.timestamp}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <Badge status={c.badge} text={c.status} size="sm" />
                    </td>

                    {/* Confidence */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {c.confidence ? (
                        <span className="font-bold text-cyan-300">{c.confidence}%</span>
                      ) : (
                        <span className="text-slate-500 italic">N/A (Review)</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        icon={Eye}
                        onClick={() => handleInspect(c)}
                      >
                        Details
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        icon={Download}
                        onClick={() => handleDownloadSingleReport(c)}
                        title="Download JSON Report"
                      >
                        Report
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 space-y-3">
            <Search className="w-10 h-10 mx-auto text-slate-600" />
            <h3 className="text-base font-bold text-slate-200">No Matching Verification Cases</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No audit logs matched your search terms or filter. Try clearing the search or status filter.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('ALL');
              }}
            >
              Reset Filters
            </Button>
          </div>
        )}

        {/* Pagination Footer */}
        {filteredCases.length > itemsPerPage && (
          <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">
              Showing {(currentPageNum - 1) * itemsPerPage + 1} to {Math.min(currentPageNum * itemsPerPage, filteredCases.length)} of {filteredCases.length} records
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                icon={ChevronLeft}
                disabled={currentPageNum === 1}
                onClick={() => setCurrentPageNum(prev => Math.max(1, prev - 1))}
              >
                Previous
              </Button>
              <span className="px-3 py-1 rounded bg-navy-950 border border-slate-800 text-cyan-400 font-bold">
                {currentPageNum} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                icon={ChevronRight}
                iconPosition="right"
                disabled={currentPageNum === totalPages}
                onClick={() => setCurrentPageNum(prev => Math.min(totalPages, prev + 1))}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>

    </div>
  );
};
