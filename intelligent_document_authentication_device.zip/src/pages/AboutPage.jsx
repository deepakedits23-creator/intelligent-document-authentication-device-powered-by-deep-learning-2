import React from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { 
  Info, 
  Users, 
  Award, 
  ShieldCheck, 
  Cpu, 
  Terminal, 
  Layers, 
  CheckCircle2, 
  Sparkles,
  School,
  Lock,
  Code2
} from 'lucide-react';

export const AboutPage = () => {
  const { setCurrentPage } = useApp();

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      
      {/* Page Title */}
      <div className="space-y-3 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
          <Info className="w-4 h-4" />
          <span>Project Overview &amp; Team</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
          About The Project
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
          Developed for the <strong className="text-cyan-300">QUANTIX 2K26 24-Hour Hackathon</strong> by <strong className="text-slate-200">Team Nexora</strong> (Lead: S. Deepak) at KSR Educational Institutions.
        </p>
      </div>

      {/* Hackathon Context Banner */}
      <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-cyan-500/30 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 space-y-4 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-mono">
            <Award className="w-3.5 h-3.5" />
            <span>QUANTIX 2K26 — Hackathon Entry • Team Nexora</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
            Intelligent Document Authentication System Powered by Deep Learning
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Credential fraud is an escalating challenge for universities, employers, and government institutions. Digital uploads (PDFs, scans, webcam captures) are frequently subject to image manipulation, spliced designations, altered marks, or forged names.
          </p>
          <p className="text-sm text-slate-400 leading-relaxed">
            Our mission is to provide an <strong>offline, laptop-first cybersecurity and computer vision application</strong> that extracts structured data using OCR, detects forensic tampering without black-box guesswork, and validates records against authoritative registries.
          </p>
        </div>
      </div>

      {/* Team Information */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Users className="w-5 h-5 text-cyan-400" />
          <span>Team Nexora — Project Credits</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <Card glow glowColor="cyan" className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold font-mono">
              SD
            </div>
            <h4 className="font-bold text-slate-100 text-base">S. Deepak</h4>
            <span className="text-xs text-cyan-400 font-mono font-semibold">Team Leader</span>
            <p className="text-xs text-slate-400 pt-1 leading-relaxed">
              Full Stack Architecture, React frontend, decision engine rules, and pipeline integration.
            </p>
          </Card>

          <Card glow glowColor="blue" className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold font-mono">
              LD
            </div>
            <h4 className="font-bold text-slate-100 text-base">L. Dhanushya</h4>
            <span className="text-xs text-blue-400 font-mono font-semibold">Team Member</span>
            <p className="text-xs text-slate-400 pt-1 leading-relaxed">
              Machine Learning Engineering, PyTorch Dual-Stream model, and deep forgery feature extraction.
            </p>
          </Card>

          <Card glow glowColor="emerald" className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold font-mono">
              ME
            </div>
            <h4 className="font-bold text-slate-100 text-base">M. S. Elamparuthi</h4>
            <span className="text-xs text-emerald-400 font-mono font-semibold">Team Member</span>
            <p className="text-xs text-slate-400 pt-1 leading-relaxed">
              Computer Vision &amp; Image Forensics, Error Level Analysis (ELA), and multi-engine OCR cascade.
            </p>
          </Card>

          <Card glow glowColor="purple" className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold font-mono">
              GK
            </div>
            <h4 className="font-bold text-slate-100 text-base">G. Kavin</h4>
            <span className="text-xs text-purple-400 font-mono font-semibold">Team Member</span>
            <p className="text-xs text-slate-400 pt-1 leading-relaxed">
              Backend API Services, SQLite authoritative registry cache, and automated PDF report generator.
            </p>
          </Card>
        </div>
      </div>

      {/* Technology Stack Grid */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Code2 className="w-5 h-5 text-cyan-400" />
          <span>Technology Stack</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold">React 18 + Vite</span>
            <p className="text-slate-400 text-[11px]">Modern reactive frontend with instant HMR</p>
          </div>
          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold">Tailwind CSS</span>
            <p className="text-slate-400 text-[11px]">Cybersecurity dark navy styling &amp; glassmorphism</p>
          </div>
          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold">FastAPI / Python</span>
            <p className="text-slate-400 text-[11px]">High-speed asynchronous Python backend</p>
          </div>
          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold">OpenCV &amp; ELA</span>
            <p className="text-slate-400 text-[11px]">Explainable image forensics &amp; blur scoring</p>
          </div>
        </div>
      </div>

      {/* Ethical AI & Jury Assurance */}
      <Card
        glow
        glowColor="cyan"
        title="Ethical AI & Defensibility Guarantee"
        icon={ShieldCheck}
      >
        <div className="space-y-3 text-xs text-slate-300 leading-relaxed pt-2">
          <p>
            Our project strictly adheres to responsible AI principles:
          </p>
          <ul className="space-y-2 list-disc list-inside text-slate-400">
            <li><strong className="text-slate-200">No Speculative Confidence Scores:</strong> The system will not output ungrounded percentages on ambiguous documents.</li>
            <li><strong className="text-slate-200">Defensible Decision Rules:</strong> Every flag is accompanied by corroborating evidence (e.g. ELA variance delta, edge splicing, or registry identity conflict).</li>
            <li><strong className="text-slate-200">100% Offline Laptop Execution:</strong> Zero external cloud API dependencies. Ingested documents remain strictly on the host laptop.</li>
          </ul>
        </div>
      </Card>

    </div>
  );
};
