import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { 
  HelpCircle, 
  Upload, 
  Cpu, 
  FileSearch, 
  Layers, 
  CheckCircle2, 
  ShieldCheck, 
  ArrowRight, 
  Terminal, 
  Lock, 
  Sparkles,
  FileCheck2,
  Scan
} from 'lucide-react';

export const HowItWorksPage = () => {
  const { setCurrentPage } = useApp();
  const [selectedStep, setSelectedStep] = useState(1);

  const steps = [
    {
      step: 1,
      title: 'Upload or Capture Document',
      icon: Upload,
      headline: 'Multi-Format Input Ingestion & Boundary Auto-Warp',
      summary: 'Accepts PDF vector documents or raster scans (PNG, JPG, JPEG) up to 15 MB, or opens the live laptop webcam via MediaDevices API with live document guide framing.',
      details: [
        'Client-side MIME type verification and 15 MB buffer check',
        'Live webcam feed with real-time blur and lighting diagnostics',
        'Perspective transform and 4-point contour deskewing'
      ],
      techSpecs: 'HTML5 Drag & Drop API • MediaDevices getUserMedia • OpenCV Perspective Warp'
    },
    {
      step: 2,
      title: 'Preprocess the Image',
      icon: Cpu,
      headline: 'Noise Filtration, Deskewing & Contrast Enhancement',
      summary: 'Prepares the ingested scan for high-fidelity computer vision using Bilateral Filtering and Contrast Limited Adaptive Histogram Equalization (CLAHE).',
      details: [
        'Bilateral Filter preserves crisp text edges while smoothing sensor noise',
        'CLAHE equalizes harsh document shadows and uneven lighting glare',
        'Laplacian variance analysis checks for motion defocus blur (threshold 95.0)'
      ],
      techSpecs: 'cv2.bilateralFilter • cv2.createCLAHE • cv2.Laplacian Variance'
    },
    {
      step: 3,
      title: 'Extract Document Features (OCR)',
      icon: FileSearch,
      headline: 'Multi-Engine Neural OCR & Entity Normalization',
      summary: 'Executes a robust multi-stage cascade to extract critical credential entities: Document Type, Serial Number, Holder Name, Issue Date, and Issuing Authority.',
      details: [
        'Primary: Windows.Media.Ocr native hardware-accelerated neural engine',
        'PDF Ingestion: Direct vector font and stream parsing via PyPDF',
        'Fallback: PyTesseract OCR with regex structured entity classification'
      ],
      techSpecs: 'Windows.Media.Ocr • PyPDF Vector Extraction • PyTesseract Engine'
    },
    {
      step: 4,
      title: 'Analyze Suspicious Patterns (Forensics)',
      icon: Layers,
      headline: 'Explainable Image Forensics (ELA) & Registry Matching',
      summary: 'Applies Error Level Analysis (ELA) to expose localized JPEG resaving compression discrepancies and cross-references extracted serials against authoritative registry databases.',
      details: [
        'ELA resaves image at 90% quality to compute pixel error deltas (Scale: 15)',
        'Spliced boundary detection locates sharp edge discontinuities from pasted text',
        'Registry lookup checks for identity collisions (e.g. valid ID altered to another name)',
        'EXIF metadata examination uncovers Photoshop/GIMP editing signatures'
      ],
      techSpecs: 'ELA Compression Delta • Canny Edge Gradient • SQLite Normalized Lookup'
    },
    {
      step: 5,
      title: 'Display Verification Result',
      icon: ShieldCheck,
      headline: 'Deterministic Zero-Trust Verdict & Audit Certificate',
      summary: 'Synthesizes forensic indicators and registry status into one of three defensible outcomes: GENUINE, POTENTIALLY FORGED, or INCONCLUSIVE with downloadable SHA-256 audit reports.',
      details: [
        'REAL — VERIFIED: Authoritative registry match + zero forensic anomalies',
        'FAKE — EVIDENCE FOUND: Document tampering or identity collision detected',
        'INCONCLUSIVE: Motion blur or unverified credentials requiring manual registrar stamp',
        'Exportable PDF audit certificates and structured JSON checksums'
      ],
      techSpecs: 'Deterministic Decision Engine • ReportLab PDF Generator • SHA-256 Digest'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      
      {/* Page Title */}
      <div className="space-y-3 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
          <HelpCircle className="w-4 h-4" />
          <span>Technical Architecture &amp; Methodology</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
          How The AI Pipeline Works
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
          Learn how our 5-stage verification architecture detects credential forgery through explainable forensic computer vision rather than speculative black-box scores.
        </p>
      </div>

      {/* 5-Step Progress Timeline Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3">
        {steps.map((st) => {
          const Icon = st.icon;
          const isSelected = selectedStep === st.step;
          return (
            <button
              key={st.step}
              onClick={() => setSelectedStep(st.step)}
              className={`p-3.5 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'bg-cyan-500/15 border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.2)]'
                  : 'bg-navy-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-mono font-bold ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`}>
                  STEP 0{st.step}
                </span>
                <Icon className={`w-4 h-4 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />
              </div>
              <div className={`text-xs font-semibold truncate ${isSelected ? 'text-slate-100' : 'text-slate-300'}`}>
                {st.title}
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Step Deep-Dive Card */}
      {(() => {
        const active = steps.find(s => s.step === selectedStep) || steps[0];
        const Icon = active.icon;
        return (
          <Card
            glow
            glowColor="cyan"
            className="p-6 md:p-8 space-y-6"
            title={`Step ${active.step}: ${active.title}`}
            subtitle={active.headline}
            icon={Icon}
          >
            <p className="text-sm md:text-base text-slate-200 leading-relaxed">
              {active.summary}
            </p>

            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-mono uppercase text-cyan-400 tracking-wider font-bold">
                Key Processing Functions:
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {active.details.map((d, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-navy-950/70 border border-slate-800 text-xs text-slate-300 space-y-1">
                    <span className="text-cyan-400 font-mono font-bold text-[11px]">0{idx + 1}.</span>
                    <p className="leading-relaxed">{d}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
              <span className="text-slate-400">
                Technology Stack: <strong className="text-slate-200">{active.techSpecs}</strong>
              </span>
              <div className="flex items-center gap-2">
                {active.step > 1 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedStep(active.step - 1)}
                  >
                    Previous Step
                  </Button>
                )}
                {active.step < 5 && (
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => setSelectedStep(active.step + 1)}
                  >
                    Next Step
                  </Button>
                )}
              </div>
            </div>
          </Card>
        );
      })()}

      {/* Forensic Science Breakdown: What is Error Level Analysis (ELA)? */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card
          title="What is Error Level Analysis (ELA)?"
          subtitle="The physics behind digital tampering detection"
          icon={Layers}
        >
          <div className="space-y-3 text-xs text-slate-300 leading-relaxed pt-2">
            <p>
              When an image is saved as a JPEG, the image data is compressed in 8x8 pixel blocks. When a fraudulent image is created, text or images from a secondary source are pasted into the document and resaved.
            </p>
            <p>
              Our ELA engine resaves the document at a known 90% error scale and computes the difference matrix. Because unmodified regions have already reached compression equilibrium, they appear dark. Tampered, newly pasted text blocks stand out with intense bright artifacts.
            </p>
          </div>
        </Card>

        <Card
          title="Strict Zero-Trust Outcome Rules"
          subtitle="Why we refuse speculative probabilistic guessing"
          icon={ShieldCheck}
        >
          <div className="space-y-3 text-xs text-slate-300 leading-relaxed pt-2">
            <p>
              Many hackathon projects output arbitrary 92% or 88% confidence percentages from uncalibrated neural networks. In legal, university, and enterprise credential screening, a false confidence score is unacceptable.
            </p>
            <p>
              Our engine requires positive authoritative registry confirmation and zero forensic anomalies to declare a document <strong>REAL</strong>. Any identity conflict or compression anomaly triggers <strong>FAKE</strong>. Low clarity defaults safely to <strong>INCONCLUSIVE</strong>.
            </p>
          </div>
        </Card>
      </div>

      {/* CTA Strip */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900 to-navy-850 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-100 text-base">Ready to test the pipeline live?</h3>
          <p className="text-xs text-slate-400 mt-1">Upload a document or launch the live laptop camera scanner.</p>
        </div>
        <Button
          variant="primary"
          size="md"
          icon={FileCheck2}
          onClick={() => setCurrentPage('verify')}
        >
          Launch Verification Workspace
        </Button>
      </div>

    </div>
  );
};
