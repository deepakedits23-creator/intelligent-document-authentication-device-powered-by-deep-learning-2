import React from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { DEMO_SCENARIOS } from '../data/mockData';
import { 
  FlaskConical, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles, 
  Download, 
  Eye, 
  ArrowRight,
  ShieldCheck,
  Cpu,
  Layers,
  FileCheck2
} from 'lucide-react';

export const DemoDocumentsPage = () => {
  const { runDemoScenario, addToast } = useApp();

  const handleDownloadSample = (scenario) => {
    // Trigger download or open preview
    const a = document.createElement('a');
    a.href = scenario.previewUrl || scenario.localFallbackUrl;
    a.target = '_blank';
    a.download = scenario.filename;
    a.click();
    addToast({
      type: 'info',
      title: 'Sample Downloaded',
      message: `Downloaded ${scenario.filename}. You can also drag-and-drop this in the Upload tab!`
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      
      {/* Header */}
      <div className="space-y-3 text-center sm:text-left">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
          <FlaskConical className="w-4 h-4" />
          <span>Interactive Jury Demonstration Center</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-100">
          Demo Document Scenarios
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Pre-packaged synthetic test scenarios built specifically for college hackathon judges to evaluate all 3 verification outcomes instantly.
        </p>
      </div>

      {/* Mandatory Disclaimer Alert */}
      <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs font-mono space-y-1">
        <div className="flex items-center gap-2 font-bold text-amber-300">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
          <span>Jury Notice: Simulated Demonstration Credentials</span>
        </div>
        <p className="leading-relaxed text-amber-200/90 pl-6">
          These documents are synthetic samples engineered with controlled modifications. Results demonstrate how our multi-stage pipeline isolates forensic anomalies and enforces zero-trust rules. These are simulated demonstrations, not legal forensic verification.
        </p>
      </div>

      {/* 3 Core Interactive Scenarios Grid */}
      <div className="space-y-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <span>Primary Hackathon Evaluation Cases</span>
          <span className="text-xs font-mono font-normal text-cyan-400 px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30">
            3 Scenarios
          </span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DEMO_SCENARIOS.map((scenario) => {
            const isGenuine = scenario.statusBadge === 'genuine';
            const isForged = scenario.statusBadge === 'forged';
            const isInconclusive = scenario.statusBadge === 'inconclusive';

            const glowColor = isGenuine ? 'emerald' : isForged ? 'crimson' : 'amber';

            return (
              <Card
                key={scenario.id}
                glow
                glowColor={glowColor}
                className="flex flex-col justify-between"
                title={scenario.title}
                badge={
                  <Badge
                    status={scenario.statusBadge}
                    text={scenario.subtitle}
                    size="sm"
                  />
                }
              >
                <div className="space-y-4 my-2">
                  {/* Thumbnail Preview */}
                  <div className="relative rounded-lg bg-navy-950 border border-slate-800 overflow-hidden h-36 flex items-center justify-center group">
                    <img
                      src={scenario.previewUrl || scenario.localFallbackUrl}
                      alt={scenario.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = scenario.localFallbackUrl;
                      }}
                    />
                    <div className="absolute inset-0 bg-navy-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <Button
                        variant="glass"
                        size="sm"
                        icon={Eye}
                        onClick={() => runDemoScenario(scenario.id)}
                      >
                        Inspect
                      </Button>
                    </div>
                  </div>

                  {/* Scenario Description */}
                  <p className="text-xs text-slate-300 leading-relaxed min-h-[50px]">
                    {scenario.description}
                  </p>

                  {/* Key Highlights to Observe */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-800/80 font-mono text-[11px]">
                    <span className="text-slate-500 uppercase text-[10px]">What Jurors Should Observe:</span>
                    {scenario.highlights.map((h, i) => (
                      <div key={i} className="flex items-start gap-1.5 text-slate-400">
                        <span className="text-cyan-400 mt-0.5">•</span>
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-4 mt-2 border-t border-slate-800 flex items-center gap-2">
                  <Button
                    variant={isGenuine ? 'success' : isForged ? 'danger' : 'outline'}
                    size="sm"
                    icon={FileCheck2}
                    onClick={() => runDemoScenario(scenario.id)}
                    className="flex-1 font-bold text-xs"
                  >
                    Load &amp; Verify
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={Download}
                    onClick={() => handleDownloadSample(scenario)}
                    title="Download file to test upload"
                  >
                    File
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Jury Walkthrough Box */}
      <Card
        glow
        glowColor="cyan"
        title="Hackathon Jury Walkthrough Guide"
        subtitle="How to demonstrate this system in 3 minutes during live judging"
        icon={Sparkles}
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-xs font-mono">
          <div className="p-3.5 rounded-xl bg-navy-950/70 border border-slate-800 space-y-1.5">
            <div className="text-cyan-400 font-bold">1. Genuine Verification</div>
            <p className="text-slate-300 text-[11px] leading-relaxed font-sans">
              Click <strong>Scenario 1</strong>. Notice how the system extracts the holder name, confirms the student ID in the simulated university ledger, and computes a uniform ELA score.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-navy-950/70 border border-slate-800 space-y-1.5">
            <div className="text-rose-400 font-bold">2. Forgery &amp; Tamper Map</div>
            <p className="text-slate-300 text-[11px] leading-relaxed font-sans">
              Click <strong>Scenario 2</strong>. Observe the registry collision ("Robert Vance" vs registered "Priya Sharma") and toggle the <strong>ELA Tamper Map</strong> to see the spliced name boundary glowing red.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-navy-950/70 border border-slate-800 space-y-1.5">
            <div className="text-amber-400 font-bold">3. Defocus Guard</div>
            <p className="text-slate-300 text-[11px] leading-relaxed font-sans">
              Click <strong>Scenario 3</strong>. Explain that our system refuses to make risky speculative guesses when blur or low optical resolution prevents conclusive proof.
            </p>
          </div>
        </div>
      </Card>

    </div>
  );
};
