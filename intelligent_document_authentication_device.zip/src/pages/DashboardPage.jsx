import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { MOCK_STATS, MOCK_CHART_HISTORY, MOCK_DOC_TYPES } from '../data/mockData';
import { 
  FileCheck2, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  TrendingUp, 
  Clock, 
  ShieldAlert, 
  ArrowUpRight, 
  Sparkles, 
  FileSearch, 
  Camera, 
  FlaskConical, 
  Calendar,
  Layers,
  Database,
  Eye,
  Download
} from 'lucide-react';

export const DashboardPage = () => {
  const { setCurrentPage, setCurrentResult, history, backendHealth } = useApp();
  const [activeChartTab, setActiveChartTab] = useState('weekly');

  const stats = {
    total: history.length > 0 ? history.length : MOCK_STATS.totalChecked,
    genuine: history.filter(h => (h.status || '').toUpperCase().includes('REAL') || (h.status || '').toUpperCase().includes('VERIFIED')).length || MOCK_STATS.genuineCount,
    forged: history.filter(h => (h.status || '').toUpperCase().includes('FAKE') || (h.status || '').toUpperCase().includes('EVIDENCE')).length || MOCK_STATS.forgedCount,
    inconclusive: history.filter(h => (h.status || '').toUpperCase().includes('INCONCLUSIVE') || (h.status || '').toUpperCase().includes('SUSPICIOUS')).length || MOCK_STATS.inconclusiveCount,
  };

  const recentCases = history.slice(0, 5);

  const handleViewCase = (caseItem) => {
    setCurrentResult({
      caseUid: caseItem.id,
      fileName: caseItem.docName,
      fileHash: caseItem.sha256,
      timestamp: caseItem.timestamp,
      outcome: caseItem.status,
      statusBadge: caseItem.badge,
      headline: caseItem.summary || caseItem.status,
      decisionReason: caseItem.summary,
      confidence: caseItem.confidence,
      extractedData: {
        doc_type: caseItem.docType,
        holder_name: caseItem.holderName,
        doc_number: caseItem.id,
        issue_date: '2026-05-18',
        issuer_name: 'Institutional Authority',
      },
      forensicData: {
        ela_mean_difference: caseItem.badge === 'forged' ? 41.8 : 8.2,
        laplacian_blur_score: caseItem.badge === 'inconclusive' ? 42.1 : 284.5,
        is_blurry: caseItem.badge === 'inconclusive',
        evidence_list: [
          { label: 'Registry Verification', passed: caseItem.badge === 'genuine', note: caseItem.summary },
          { label: 'ELA Compression Uniformity', passed: caseItem.badge !== 'forged', note: 'Forensic integrity check' }
        ]
      },
      referenceData: { matched: caseItem.badge === 'genuine' },
      isSimulated: true
    });
    setCurrentPage('results');
  };

  return (
    <div className="space-y-8">
      
      {/* Sample Data Notice Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs font-mono text-cyan-300">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong>Demo Analytics:</strong> Dashboard aggregates synthetic test credentials &amp; live verification audit records.
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-400">Status:</span>
          <span className="text-slate-200">{backendHealth.isLive ? 'FastAPI Backend Synchronized' : 'Local Offline Engine'}</span>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        
        {/* Total Documents Checked */}
        <Card
          glow
          glowColor="cyan"
          className="relative overflow-hidden"
          title="Total Documents Checked"
          icon={FileSearch}
          badge={<span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">+18.4%</span>}
        >
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-slate-100 font-mono tracking-tight">
              {stats.total}
            </span>
            <span className="text-xs text-slate-400 font-mono">Processed</span>
          </div>
          <p className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            <span>High verification throughput</span>
          </p>
        </Card>

        {/* Genuine Documents */}
        <Card
          glow
          glowColor="emerald"
          className="relative overflow-hidden"
          title="Genuine Documents"
          icon={CheckCircle2}
          badge={<span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">69.0%</span>}
        >
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-emerald-400 font-mono tracking-tight">
              {stats.genuine}
            </span>
            <span className="text-xs text-emerald-400/80 font-mono">Verified Authentic</span>
          </div>
          <p className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Registry &amp; ELA integrity confirmed</span>
          </p>
        </Card>

        {/* Potentially Forged */}
        <Card
          glow
          glowColor="crimson"
          className="relative overflow-hidden"
          title="Potentially Forged"
          icon={XCircle}
          badge={<span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-300">21.8%</span>}
        >
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-rose-400 font-mono tracking-tight">
              {stats.forged}
            </span>
            <span className="text-xs text-rose-400/80 font-mono">Evidence Found</span>
          </div>
          <p className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>Tampering / Conflict Flagged</span>
          </p>
        </Card>

        {/* Inconclusive / Review */}
        <Card
          glow
          glowColor="amber"
          className="relative overflow-hidden"
          title="Inconclusive Cases"
          icon={AlertTriangle}
          badge={<span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">9.2%</span>}
        >
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-3xl font-extrabold text-amber-400 font-mono tracking-tight">
              {stats.inconclusive}
            </span>
            <span className="text-xs text-amber-400/80 font-mono">Manual Review</span>
          </div>
          <p className="mt-2 text-xs text-slate-400 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Low OCR / Blur / Unregistered</span>
          </p>
        </Card>

      </div>

      {/* Charts & Breakdown Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Verification Success Statistics Chart */}
        <Card
          className="lg:col-span-2 space-y-4"
          title="Verification Velocity & Outcome Distribution"
          subtitle="Simulated 7-day screening trends across credential ingestion points"
          icon={TrendingUp}
        >
          {/* Chart Bars */}
          <div className="pt-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400 pb-2 border-b border-slate-800">
              <span>Day of Week</span>
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Genuine</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-rose-500" /> Forged</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-amber-500" /> Review</span>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              {MOCK_CHART_HISTORY.map((item) => {
                const total = item.genuine + item.forged + item.inconclusive;
                const genuineWidth = (item.genuine / 35) * 100;
                const forgedWidth = (item.forged / 35) * 100;
                const inconclusiveWidth = (item.inconclusive / 35) * 100;

                return (
                  <div key={item.day} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300 font-semibold">{item.day}</span>
                      <span className="text-slate-400 text-[11px]">{total} total verifications</span>
                    </div>
                    <div className="h-4 w-full bg-navy-950 rounded-md overflow-hidden flex border border-slate-800/80">
                      <div
                        style={{ width: `${genuineWidth}%` }}
                        className="bg-emerald-500/80 hover:bg-emerald-400 transition-all duration-300 relative group"
                        title={`${item.day} Genuine: ${item.genuine}`}
                      />
                      <div
                        style={{ width: `${forgedWidth}%` }}
                        className="bg-rose-500/80 hover:bg-rose-400 transition-all duration-300"
                        title={`${item.day} Forged: ${item.forged}`}
                      />
                      <div
                        style={{ width: `${inconclusiveWidth}%` }}
                        className="bg-amber-500/80 hover:bg-amber-400 transition-all duration-300"
                        title={`${item.day} Inconclusive: ${item.inconclusive}`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Average Decision Speed: <strong className="text-cyan-400">1.42s</strong></span>
            <span>Zero-Trust Decision Rules: <strong className="text-emerald-400">Strict Active</strong></span>
          </div>
        </Card>

        {/* Document Ingestion Breakdown */}
        <Card
          title="Document Types Verified"
          subtitle="Distribution of incoming credential categories"
          icon={Layers}
        >
          <div className="space-y-4 pt-2">
            {MOCK_DOC_TYPES.map((type) => (
              <div key={type.name} className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-200 font-medium">{type.name}</span>
                  <span className="text-cyan-400 font-mono">{type.percentage}%</span>
                </div>
                <div className="h-2 w-full bg-navy-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${type.percentage}%`, backgroundColor: type.color }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Quick Engine Health Indicators */}
          <div className="mt-6 pt-5 border-t border-slate-800 space-y-2.5 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-400">
              <span>Windows Neural OCR:</span>
              <span className="text-emerald-400 font-bold">ONLINE</span>
            </div>
            <div className="flex justify-between items-center text-slate-400">
              <span>Error Level Analysis:</span>
              <span className="text-cyan-400 font-bold">ACTIVE (Scale: 15)</span>
            </div>
            <div className="flex justify-between items-center text-slate-400">
              <span>Registry Ledger Database:</span>
              <span className="text-emerald-400 font-bold">SQLITE CONNECTED</span>
            </div>
          </div>
        </Card>

      </div>

      {/* Recent Verification History Table */}
      <Card
        title="Recent Verification Cases"
        subtitle="Live audit trail of recently analyzed physical credentials & scans"
        icon={Clock}
        action={
          <Button
            variant="ghost"
            size="sm"
            icon={ArrowUpRight}
            iconPosition="right"
            onClick={() => setCurrentPage('history')}
          >
            View All History
          </Button>
        }
      >
        <div className="overflow-x-auto -mx-5 sm:mx-0">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-3 px-4">Verification ID</th>
                <th className="py-3 px-4">Document / Name</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Date &amp; Time</th>
                <th className="py-3 px-4">Status Verdict</th>
                <th className="py-3 px-4">Confidence</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {recentCases.map((c) => (
                <tr key={c.id} className="hover:bg-navy-800/40 transition-colors">
                  <td className="py-3 px-4 font-bold text-cyan-400">{c.id}</td>
                  <td className="py-3 px-4 text-slate-200">
                    <div className="font-sans font-semibold text-slate-100">{c.docName}</div>
                    <div className="text-[11px] text-slate-400">{c.holderName}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-400">{c.docType}</td>
                  <td className="py-3 px-4 text-slate-400">{c.timestamp}</td>
                  <td className="py-3 px-4">
                    <Badge status={c.badge} text={c.status} size="sm" />
                  </td>
                  <td className="py-3 px-4">
                    {c.confidence ? (
                      <span className="font-bold text-cyan-300">{c.confidence}%</span>
                    ) : (
                      <span className="text-slate-500 italic">N/A (Review)</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      icon={Eye}
                      onClick={() => handleViewCase(c)}
                    >
                      Inspect
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Quick Launch Strip */}
      <div className="p-6 rounded-xl bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-cyan-500/20 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-bold text-slate-100 text-base">Ready to verify a new credential?</h4>
          <p className="text-xs text-slate-400 mt-1">
            Choose between file drag-and-drop or use the live laptop webcam with auto-cropping.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <Button
            variant="primary"
            size="md"
            icon={FileSearch}
            onClick={() => setCurrentPage('verify')}
          >
            Upload File
          </Button>
          <Button
            variant="secondary"
            size="md"
            icon={Camera}
            onClick={() => {
              setCurrentPage('verify');
            }}
          >
            Open Webcam
          </Button>
        </div>
      </div>

    </div>
  );
};
