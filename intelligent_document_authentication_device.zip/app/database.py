import sqlite3
import json
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any
from app.config import DB_PATH

logger = logging.getLogger(__name__)

def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    """Initialize database tables with parameterized schemas."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # 1. Reference records table (Clearly labeled synthetic records)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reference_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id TEXT UNIQUE NOT NULL,
                doc_type TEXT NOT NULL,
                issuer_name TEXT NOT NULL,
                holder_name TEXT NOT NULL,
                issue_date TEXT,
                expiry_date TEXT,
                status TEXT DEFAULT 'ACTIVE',
                is_authoritative INTEGER DEFAULT 0,
                notes TEXT,
                metadata_json TEXT,
                created_at TEXT NOT NULL
            )
        """)
        
        # 2. Verification cases table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS verification_cases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                case_uid TEXT UNIQUE NOT NULL,
                file_name TEXT NOT NULL,
                file_hash TEXT NOT NULL,
                doc_type TEXT,
                extracted_data_json TEXT NOT NULL,
                reference_data_json TEXT NOT NULL,
                forensic_data_json TEXT NOT NULL,
                decision_outcome TEXT NOT NULL,
                decision_reason TEXT NOT NULL,
                severity TEXT DEFAULT 'INFO',
                image_path TEXT,
                heatmap_path TEXT,
                pdf_path TEXT,
                created_at TEXT NOT NULL
            )
        """)
        
        # 3. Audit events log table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                case_uid TEXT,
                event_type TEXT NOT NULL,
                details TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        conn.commit()
    logger.info("Database schema initialized successfully at %s", DB_PATH)

# ==================== CASE MANAGEMENT ====================

def save_case(
    case_uid: str,
    file_name: str,
    file_hash: str,
    doc_type: str,
    extracted_data: Dict[str, Any],
    reference_data: Dict[str, Any],
    forensic_data: Dict[str, Any],
    decision_outcome: str,
    decision_reason: str,
    severity: str = "INFO",
    image_path: Optional[str] = None,
    heatmap_path: Optional[str] = None,
    pdf_path: Optional[str] = None
) -> None:
    now = datetime.now().isoformat()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO verification_cases (
                case_uid, file_name, file_hash, doc_type,
                extracted_data_json, reference_data_json, forensic_data_json,
                decision_outcome, decision_reason, severity,
                image_path, heatmap_path, pdf_path, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            case_uid,
            file_name,
            file_hash,
            doc_type,
            json.dumps(extracted_data),
            json.dumps(reference_data),
            json.dumps(forensic_data),
            decision_outcome,
            decision_reason,
            severity,
            image_path,
            heatmap_path,
            pdf_path,
            now
        ))
        cursor.execute("""
            INSERT INTO audit_events (case_uid, event_type, details, timestamp)
            VALUES (?, 'CASE_CREATED', ?, ?)
        """, (case_uid, f"Verification case {case_uid} evaluated with outcome {decision_outcome}", now))
        conn.commit()

def get_cases(
    search: Optional[str] = None,
    doc_type: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
) -> List[Dict[str, Any]]:
    query = "SELECT * FROM verification_cases WHERE 1=1"
    params = []
    
    if search:
        query += " AND (case_uid LIKE ? OR file_name LIKE ? OR doc_type LIKE ?)"
        like_search = f"%{search}%"
        params.extend([like_search, like_search, like_search])
        
    if doc_type and doc_type != "ALL":
        query += " AND doc_type = ?"
        params.append(doc_type)
        
    if status and status != "ALL":
        query += " AND decision_outcome LIKE ?"
        params.append(f"%{status}%")
        
    query += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
    result = []
    for r in rows:
        d = dict(r)
        d["extracted_data"] = json.loads(d["extracted_data_json"]) if d["extracted_data_json"] else {}
        d["reference_data"] = json.loads(d["reference_data_json"]) if d["reference_data_json"] else {}
        d["forensic_data"] = json.loads(d["forensic_data_json"]) if d["forensic_data_json"] else {}
        result.append(d)
    return result

def get_case_by_uid(case_uid: str) -> Optional[Dict[str, Any]]:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM verification_cases WHERE case_uid = ?", (case_uid,))
        row = cursor.fetchone()
        if not row:
            return None
        d = dict(row)
        d["extracted_data"] = json.loads(d["extracted_data_json"]) if d["extracted_data_json"] else {}
        d["reference_data"] = json.loads(d["reference_data_json"]) if d["reference_data_json"] else {}
        d["forensic_data"] = json.loads(d["forensic_data_json"]) if d["forensic_data_json"] else {}
        return d

def delete_case_by_uid(case_uid: str) -> bool:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM verification_cases WHERE case_uid = ?", (case_uid,))
        affected = cursor.rowcount
        cursor.execute("""
            INSERT INTO audit_events (case_uid, event_type, details, timestamp)
            VALUES (?, 'CASE_DELETED', 'Case manually deleted by user', ?)
        """, (case_uid, datetime.now().isoformat()))
        conn.commit()
    return affected > 0

# ==================== REFERENCE RECORD MANAGEMENT ====================

def get_reference_records(search: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
    query = "SELECT * FROM reference_records WHERE 1=1"
    params = []
    if search:
        query += " AND (record_id LIKE ? OR holder_name LIKE ? OR issuer_name LIKE ? OR doc_type LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s, s])
    query += " ORDER BY id ASC LIMIT ?"
    params.append(limit)
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
    return [dict(r) for r in rows]

def get_reference_record_by_number(doc_number: str) -> Optional[Dict[str, Any]]:
    if not doc_number:
        return None
    # Normalize clean alphanumeric
    clean_num = "".join(ch for ch in doc_number if ch.isalnum()).upper()
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        # Direct exact match first
        cursor.execute("SELECT * FROM reference_records WHERE record_id = ?", (doc_number.strip(),))
        row = cursor.fetchone()
        if row:
            return dict(row)
            
        # Try alphanumeric matching
        cursor.execute("SELECT * FROM reference_records")
        rows = cursor.fetchall()
        for r in rows:
            r_clean = "".join(ch for ch in r["record_id"] if ch.isalnum()).upper()
            if r_clean == clean_num or (len(clean_num) > 5 and clean_num in r_clean):
                return dict(r)
    return None

def add_reference_record(
    record_id: str,
    doc_type: str,
    issuer_name: str,
    holder_name: str,
    issue_date: str,
    expiry_date: Optional[str] = None,
    status: str = "ACTIVE",
    is_authoritative: int = 0,
    notes: Optional[str] = None,
    metadata_json: Optional[str] = None
) -> int:
    now = datetime.now().isoformat()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO reference_records (
                record_id, doc_type, issuer_name, holder_name,
                issue_date, expiry_date, status, is_authoritative,
                notes, metadata_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            record_id.strip(),
            doc_type.strip(),
            issuer_name.strip(),
            holder_name.strip(),
            issue_date.strip() if issue_date else "",
            expiry_date.strip() if expiry_date else None,
            status.strip().upper(),
            is_authoritative,
            notes,
            metadata_json or "{}",
            now
        ))
        conn.commit()
        return cursor.lastrowid

def delete_reference_record(record_id_or_db_id: str) -> bool:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if str(record_id_or_db_id).isdigit():
            cursor.execute("DELETE FROM reference_records WHERE id = ?", (int(record_id_or_db_id),))
        else:
            cursor.execute("DELETE FROM reference_records WHERE record_id = ?", (record_id_or_db_id,))
        conn.commit()
        return cursor.rowcount > 0

def log_audit(event_type: str, details: str, case_uid: Optional[str] = None) -> None:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO audit_events (case_uid, event_type, details, timestamp)
            VALUES (?, ?, ?, ?)
        """, (case_uid, event_type, details, datetime.now().isoformat()))
        conn.commit()
