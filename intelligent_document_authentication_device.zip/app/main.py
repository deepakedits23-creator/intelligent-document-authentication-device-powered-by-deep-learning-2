import os
import io
import re
import uuid
import json
import shutil
import hashlib
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
import cv2

from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Request, Depends
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.config import (
    PROJECT_NAME,
    TAGLINE,
    DEVELOPER_CREDIT,
    EVENT_NAME,
    PROJECT_GOAL,
    UPLOAD_DIR,
    REPORTS_DIR,
    SAMPLES_DIR,
    STATIC_DIR,
    TEMPLATES_DIR,
    MAX_FILE_SIZE_BYTES,
    ALLOWED_EXTENSIONS,
    ALLOWED_MIME_TYPES,
    STATUS_REAL,
    STATUS_FAKE,
    STATUS_SUSPICIOUS
)
from app.database import (
    init_db,
    save_case,
    get_cases,
    get_case_by_uid,
    delete_case_by_uid,
    get_reference_records,
    add_reference_record,
    delete_reference_record,
    log_audit
)
from app.demo_data import (
    seed_reference_database,
    generate_synthetic_samples,
    DEMO_SAMPLES_METADATA
)
from app.ocr_engine import perform_ocr, parse_extracted_fields
from app.forensics import run_forensic_pipeline
from app.reference_db import compare_with_reference
from app.decision_engine import evaluate_verification_case
from app.report_generator import generate_pdf_report, generate_json_report
from app.camera_helper import process_camera_frame
from app.ml_model import run_deep_learning_inference, get_model_summary
from app.security_features import decode_qr_code, detect_logo_and_seal, verify_certificate_triple_lock

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("document_verifier")

from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing database and demo environment...")
    init_db()
    seed_reference_database()
    generate_synthetic_samples(force=False)
    logger.info("Startup complete. INTELLIGENT DOCUMENT AUTHENTICATION DEVICE ready on laptop.")
    yield

app = FastAPI(
    title=PROJECT_NAME,
    description=f"{TAGLINE} - Built for {EVENT_NAME}",
    version="2.0.0",
    lifespan=lifespan
)

# Enable CORS for local development & camera operations
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# Mount sample images directly for frontend preview
if SAMPLES_DIR.exists():
    app.mount("/samples", StaticFiles(directory=str(SAMPLES_DIR)), name="samples")

PUBLIC_DIR = Path(__file__).resolve().parent.parent / "public"
if PUBLIC_DIR.exists():
    app.mount("/public", StaticFiles(directory=str(PUBLIC_DIR)), name="public")

# Mount React production build assets if built
DIST_DIR = Path(__file__).resolve().parent.parent / "dist"
if (DIST_DIR / "assets").exists():
    app.mount("/assets", StaticFiles(directory=str(DIST_DIR / "assets")), name="react-assets")

# Pydantic Request Models
class ReEvaluateRequest(BaseModel):
    case_uid: str
    doc_type: Optional[str] = None
    doc_number: Optional[str] = None
    holder_name: Optional[str] = None
    issue_date: Optional[str] = None
    issuer_name: Optional[str] = None

class NewReferenceRecordRequest(BaseModel):
    record_id: str
    doc_type: str
    issuer_name: str
    holder_name: str
    issue_date: Optional[str] = ""
    expiry_date: Optional[str] = None
    status: str = "ACTIVE"
    is_authoritative: int = 0
    notes: Optional[str] = None

# Helper: Compute SHA-256
def get_file_sha256(file_path: Path) -> str:
    sha = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(65536):
            sha.update(chunk)
    return sha.hexdigest()

# Helper: Run Complete Verification Pipeline
def execute_pipeline(file_path: Path, file_name: str, case_uid: Optional[str] = None) -> Dict[str, Any]:
    if not case_uid:
        case_uid = f"QV-2026-{uuid.uuid4().hex[:8].upper()}"

    file_hash = get_file_sha256(file_path)

    # 1. OCR text extraction
    raw_text, ocr_engine, ocr_confidence = perform_ocr(file_path)
    extracted_fields = parse_extracted_fields(raw_text)

    # 2. Image Forensics
    forensics = run_forensic_pipeline(file_path, case_uid, UPLOAD_DIR)

    # 2.5 PyTorch Deep Learning Model Inference
    dl_result = run_deep_learning_inference(file_path, case_uid)

    # 3. Reference DB comparison
    reference_match = compare_with_reference(extracted_fields)

    # 3.5 Physical & Digital Security Features (Logo, QR Code & Triple-Lock Name Match)
    img_cv = cv2.imread(str(file_path))
    if img_cv is not None:
        qr_info = decode_qr_code(img_cv)
        seal_info = detect_logo_and_seal(img_cv)
        security_features = verify_certificate_triple_lock(extracted_fields, qr_info, seal_info, reference_match)
    else:
        qr_info = {"qr_detected": False}
        seal_info = {"logo_detected": False, "seal_detected": False}
        security_features = {"overall_status": "UNVERIFIED", "has_critical_conflict": False, "security_checklist": []}

    # 4. Decision Engine
    ocr_data = {
        "fields": extracted_fields,
        "confidence": ocr_confidence,
        "engine": ocr_engine,
        "raw_text": raw_text
    }
    decision = evaluate_verification_case(ocr_data, forensics, reference_match, security_features)

    # 5. Generate Reports
    case_data = {
        "case_uid": case_uid,
        "file_name": file_name,
        "file_hash": file_hash,
        "created_at": datetime.now().isoformat(),
        "ocr_engine": ocr_engine,
        "ocr_confidence": ocr_confidence,
        "extracted_data": extracted_fields,
        "forensic_data": forensics,
        "reference_data": reference_match,
        "security_features": security_features,
        "decision": decision,
        "deep_learning": dl_result
    }

    pdf_filename = f"report_{case_uid}.pdf"
    pdf_path = REPORTS_DIR / pdf_filename
    generate_pdf_report(case_data, pdf_path)
    
    json_filename = f"report_{case_uid}.json"
    json_path = REPORTS_DIR / json_filename
    generate_json_report(case_data, json_path)

    # 6. Save in SQLite
    save_case(
        case_uid=case_uid,
        file_name=file_name,
        file_hash=file_hash,
        doc_type=extracted_fields.get("doc_type", "Unspecified"),
        extracted_data=extracted_fields,
        reference_data=reference_match,
        forensic_data=forensics,
        decision_outcome=decision["outcome"],
        decision_reason=decision["reason"],
        severity=decision.get("severity", "INFO"),
        image_path=str(file_path.name),
        heatmap_path=forensics.get("heatmap_file"),
        pdf_path=pdf_filename
    )

    case_data["pdf_url"] = f"/api/cases/{case_uid}/pdf"
    case_data["json_url"] = f"/api/cases/{case_uid}/json"
    case_data["image_url"] = f"/api/files/image/{file_path.name}"
    case_data["heatmap_url"] = f"/api/files/heatmap/{forensics.get('heatmap_file')}"
    return case_data

# ==================== MAIN PAGE ROUTE ====================

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    react_index = DIST_DIR / "index.html"
    if react_index.exists():
        return react_index.read_text(encoding="utf-8")
    index_file = TEMPLATES_DIR / "index.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="Index template not found.")
    return index_file.read_text(encoding="utf-8")

# ==================== API ENDPOINTS ====================

@app.post("/api/upload")
async def upload_document(file: UploadFile = File(...)):
    """Handle document file upload, validate constraints, and run verification."""
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{ext}'. Allowed extensions: PDF, PNG, JPG, JPEG."
        )

    # Read content with size guard
    contents = await file.read()
    if len(contents) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds maximum allowed size ({MAX_FILE_SIZE_BYTES / (1024*1024):.0f} MB)."
        )
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes).")

    case_uid = f"QV-2026-{uuid.uuid4().hex[:8].upper()}"
    safe_name = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", file.filename)
    dest_path = UPLOAD_DIR / f"{case_uid}_{safe_name}"

    with open(dest_path, "wb") as f:
        f.write(contents)

    try:
        case_data = execute_pipeline(dest_path, file.filename, case_uid)
        return JSONResponse(content=case_data)
    except Exception as e:
        logger.exception("Verification pipeline error")
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")

@app.post("/api/scan")
async def scan_camera_document(file: UploadFile = File(...), auto_warp: bool = Form(True)):
    """Receive frame captured via laptop camera, validate boundaries, and run pipeline."""
    contents = await file.read()
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="No camera image data received.")

    case_uid = f"QV-CAM-{uuid.uuid4().hex[:8].upper()}"
    dest_path = UPLOAD_DIR / f"{case_uid}_webcam_capture.jpg"

    try:
        proc_info = process_camera_frame(contents, dest_path, auto_warp=auto_warp)
        case_data = execute_pipeline(dest_path, "webcam_scan.jpg", case_uid)
        case_data["camera_diagnostics"] = proc_info
        return JSONResponse(content=case_data)
    except Exception as e:
        logger.exception("Camera verification error")
        raise HTTPException(status_code=500, detail=f"Camera processing failed: {str(e)}")

@app.post("/api/camera/analyze-frame")
async def live_frame_check(file: UploadFile = File(...)):
    """Pre-scan frame analysis to provide real-time guidance before document capture."""
    contents = await file.read()
    temp_path = UPLOAD_DIR / f"temp_frame_{uuid.uuid4().hex[:6]}.jpg"
    try:
        proc = process_camera_frame(contents, temp_path, auto_warp=False)
        if temp_path.exists():
            temp_path.unlink()
        return {
            "blur_score": proc["blur_score"],
            "mean_brightness": proc["mean_brightness"],
            "is_blurry": proc["is_blurry"],
            "is_dark": proc["is_dark"],
            "is_glare": proc["is_glare"],
            "boundary_detected": proc["boundary_detected"],
            "guidance": proc["guidance"]
        }
    except Exception as e:
        if temp_path.exists():
            temp_path.unlink()
        return {"error": str(e), "guidance": ["Ensure camera is enabled and focused on document."]}

@app.post("/api/re-evaluate")
async def re_evaluate_case(req: ReEvaluateRequest):
    """Allow user to manually correct misread OCR fields and re-run reference & decision engine."""
    case = get_case_by_uid(req.case_uid)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found.")

    extracted = case.get("extracted_data", {})
    if req.doc_type: extracted["doc_type"] = req.doc_type
    if req.doc_number: extracted["doc_number"] = req.doc_number
    if req.holder_name: extracted["holder_name"] = req.holder_name
    if req.issue_date: extracted["issue_date"] = req.issue_date
    if req.issuer_name: extracted["issuer_name"] = req.issuer_name

    # Re-run reference check and decision
    reference_match = compare_with_reference(extracted)
    forensics = case.get("forensic_data", {})
    ocr_data = {
        "fields": extracted,
        "confidence": 95.0,  # User-verified text
        "engine": "User Reviewed / Corrected OCR"
    }
    decision = evaluate_verification_case(ocr_data, forensics, reference_match)

    # Regenerate report
    case_data = {
        "case_uid": req.case_uid,
        "file_name": case["file_name"],
        "file_hash": case["file_hash"],
        "created_at": case["created_at"],
        "ocr_engine": "User Corrected OCR",
        "ocr_confidence": 98.0,
        "extracted_data": extracted,
        "forensic_data": forensics,
        "reference_data": reference_match,
        "decision": decision
    }

    pdf_path = REPORTS_DIR / f"report_{req.case_uid}.pdf"
    generate_pdf_report(case_data, pdf_path)
    json_path = REPORTS_DIR / f"report_{req.case_uid}.json"
    generate_json_report(case_data, json_path)

    # Update database
    save_case(
        case_uid=req.case_uid,
        file_name=case["file_name"],
        file_hash=case["file_hash"],
        doc_type=extracted.get("doc_type", "Unspecified"),
        extracted_data=extracted,
        reference_data=reference_match,
        forensic_data=forensics,
        decision_outcome=decision["outcome"],
        decision_reason=decision["reason"],
        severity=decision.get("severity", "INFO"),
        image_path=case.get("image_path"),
        heatmap_path=case.get("heatmap_path"),
        pdf_path=f"report_{req.case_uid}.pdf"
    )

    case_data["pdf_url"] = f"/api/cases/{req.case_uid}/pdf"
    case_data["json_url"] = f"/api/cases/{req.case_uid}/json"
    case_data["image_url"] = f"/api/files/image/{case.get('image_path')}"
    case_data["heatmap_url"] = f"/api/files/heatmap/{case.get('heatmap_path')}"
    return JSONResponse(content=case_data)

@app.get("/api/cases")
async def list_cases(
    search: Optional[str] = None,
    doc_type: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
):
    cases = get_cases(search=search, doc_type=doc_type, status=status, limit=limit, offset=offset)
    return {"cases": cases, "count": len(cases)}

@app.get("/api/cases/{case_uid}")
async def get_case_details(case_uid: str):
    case = get_case_by_uid(case_uid)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found.")
    case["pdf_url"] = f"/api/cases/{case_uid}/pdf"
    case["json_url"] = f"/api/cases/{case_uid}/json"
    case["image_url"] = f"/api/files/image/{case.get('image_path')}"
    case["heatmap_url"] = f"/api/files/heatmap/{case.get('heatmap_path')}"
    return case

@app.delete("/api/cases/{case_uid}")
async def delete_case(case_uid: str):
    success = delete_case_by_uid(case_uid)
    if not success:
        raise HTTPException(status_code=404, detail="Case not found.")
    return {"status": "success", "message": f"Case {case_uid} deleted successfully."}

@app.get("/api/cases/{case_uid}/pdf")
async def download_case_pdf(case_uid: str):
    pdf_path = REPORTS_DIR / f"report_{case_uid}.pdf"
    if not pdf_path.exists():
        # If not present, generate on the fly
        case = get_case_by_uid(case_uid)
        if not case:
            raise HTTPException(status_code=404, detail="Case not found.")
        case_data = {
            "case_uid": case_uid,
            "file_name": case["file_name"],
            "file_hash": case["file_hash"],
            "created_at": case["created_at"],
            "extracted_data": case.get("extracted_data", {}),
            "reference_data": case.get("reference_data", {}),
            "forensic_data": case.get("forensic_data", {}),
            "decision": {
                "outcome": case["decision_outcome"],
                "reason": case["decision_reason"],
                "headline": f"Verification Status: {case['decision_outcome']}",
                "evidence_checklist": case.get("forensic_data", {}).get("evidence_list", [])
            }
        }
        generate_pdf_report(case_data, pdf_path)

    return FileResponse(
        path=str(pdf_path),
        filename=f"Document_Verification_{case_uid}.pdf",
        media_type="application/pdf"
    )

@app.get("/api/cases/{case_uid}/json")
async def download_case_json(case_uid: str):
    json_path = REPORTS_DIR / f"report_{case_uid}.json"
    if not json_path.exists():
        case = get_case_by_uid(case_uid)
        if not case:
            raise HTTPException(status_code=404, detail="Case not found.")
        generate_json_report(case, json_path)

    return FileResponse(
        path=str(json_path),
        filename=f"Document_Verification_{case_uid}.json",
        media_type="application/json"
    )

# ==================== DEMO SAMPLES ENDPOINTS ====================

@app.get("/api/demo-samples")
async def list_demo_samples():
    """List 5 pre-packaged synthetic hackathon demo samples."""
    return {"samples": DEMO_SAMPLES_METADATA}

@app.post("/api/demo-samples/{sample_id}/load")
async def load_demo_sample(sample_id: str):
    """One-click trigger to execute the verification pipeline on a synthetic demo sample."""
    sample = next((s for s in DEMO_SAMPLES_METADATA if s["id"] == sample_id), None)
    if not sample:
        raise HTTPException(status_code=404, detail="Sample ID not found.")

    src_path = SAMPLES_DIR / sample["filename"]
    if not src_path.exists():
        generate_synthetic_samples(force=True)

    case_uid = f"QV-DEMO-{sample_id.replace('-', '').upper()}-{uuid.uuid4().hex[:4].upper()}"
    dest_path = UPLOAD_DIR / f"{case_uid}_{sample['filename']}"
    shutil.copyfile(src_path, dest_path)

    case_data = execute_pipeline(dest_path, sample["filename"], case_uid)
    case_data["demo_info"] = sample
    return JSONResponse(content=case_data)

@app.get("/api/demo-samples/{sample_id}/download")
async def download_demo_sample(sample_id: str):
    sample = next((s for s in DEMO_SAMPLES_METADATA if s["id"] == sample_id), None)
    if not sample:
        raise HTTPException(status_code=404, detail="Sample ID not found.")
    path = SAMPLES_DIR / sample["filename"]
    return FileResponse(path=str(path), filename=sample["filename"])

# ==================== REFERENCE RECORD MANAGEMENT ====================

@app.get("/api/reference-records")
async def list_reference_records(search: Optional[str] = None):
    records = get_reference_records(search=search)
    return {"records": records, "count": len(records)}

@app.post("/api/reference-records")
async def create_reference_record(req: NewReferenceRecordRequest):
    new_id = add_reference_record(
        record_id=req.record_id,
        doc_type=req.doc_type,
        issuer_name=req.issuer_name,
        holder_name=req.holder_name,
        issue_date=req.issue_date,
        expiry_date=req.expiry_date,
        status=req.status,
        is_authoritative=req.is_authoritative,
        notes=req.notes
    )
    return {"status": "success", "id": new_id, "record_id": req.record_id}

@app.delete("/api/reference-records/{record_id}")
async def remove_reference_record(record_id: str):
    deleted = delete_reference_record(record_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Record not found.")
    return {"status": "success", "message": f"Reference record {record_id} deleted."}

# ==================== STATIC FILE STREAMS ====================

@app.get("/api/files/image/{filename}")
async def serve_uploaded_image(filename: str):
    # Sanitize path traversal
    safe_name = os.path.basename(filename)
    path = UPLOAD_DIR / safe_name
    if not path.exists():
        path = SAMPLES_DIR / safe_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="Image not found.")
    return FileResponse(str(path))

@app.get("/api/files/heatmap/{filename}")
async def serve_heatmap_image(filename: str):
    safe_name = os.path.basename(filename)
    path = UPLOAD_DIR / safe_name
    if not path.exists():
        raise HTTPException(status_code=404, detail="Forensic heatmap not found.")
    return FileResponse(str(path))

# ==================== DEEP LEARNING MODEL ENDPOINTS ====================

@app.get("/api/model/info")
async def get_deep_learning_model_info():
    """Return PyTorch Deep Learning model metadata, parameters, and architecture."""
    return get_model_summary()

@app.post("/api/model/predict")
async def predict_document_model(file: UploadFile = File(...)):
    """Run direct neural forward pass on uploaded document image."""
    case_uid = f"QV-DL-{uuid.uuid4().hex[:6].upper()}"
    dest_path = UPLOAD_DIR / f"{case_uid}_{file.filename}"
    contents = await file.read()
    with open(dest_path, "wb") as f:
        f.write(contents)
    return run_deep_learning_inference(dest_path, case_uid)

@app.get("/api/health")
async def health_check():
    from app.ocr_engine import get_tesseract_path
    return {
        "status": "healthy",
        "project": PROJECT_NAME,
        "tagline": TAGLINE,
        "event": EVENT_NAME,
        "developer": DEVELOPER_CREDIT,
        "tesseract_path": get_tesseract_path() or "Not detected (Using Windows.Media.Ocr native engine)",
        "active_engine": "Windows.Media.Ocr + PyPDF Multi-Stage OCR",
        "db_status": "connected"
    }
