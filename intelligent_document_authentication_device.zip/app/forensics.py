import os
import cv2
import numpy as np
from PIL import Image, ExifTags
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
from app.config import (
    ELA_SCALE,
    ELA_QUALITY,
    ELA_ANOMALY_THRESHOLD,
    LAPLACIAN_BLUR_THRESHOLD,
    MIN_IMAGE_WIDTH,
    MIN_IMAGE_HEIGHT,
    UPLOAD_DIR
)

def analyze_metadata(file_path: Path) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Inspect file properties and EXIF metadata for editing footprints."""
    evidence = []
    meta_summary = {
        "file_name": file_path.name,
        "file_size_bytes": file_path.stat().st_size,
        "format": file_path.suffix.lower().replace(".", "").upper(),
        "software_detected": None,
        "has_exif": False
    }
    
    # Check for empty / zero-byte
    if meta_summary["file_size_bytes"] == 0:
        evidence.append({
            "id": "META-001",
            "category": "FILE_INTEGRITY",
            "severity": "CRITICAL",
            "title": "Corrupt or Empty File",
            "description": "Uploaded file is 0 bytes.",
            "why_it_matters": "Corrupt files cannot be processed or verified."
        })
        return evidence, meta_summary

    # For PDF files
    if file_path.suffix.lower() == ".pdf":
        meta_summary["format"] = "PDF"
        evidence.append({
            "id": "META-PDF",
            "category": "METADATA",
            "severity": "INFO",
            "title": "PDF Document Container",
            "description": f"File is a PDF document of size {meta_summary['file_size_bytes'] / 1024:.1f} KB.",
            "why_it_matters": "PDF documents can contain both vector text and rasterized scans."
        })
        return evidence, meta_summary

    # For image files, inspect EXIF
    try:
        with Image.open(file_path) as img:
            meta_summary["width"] = img.width
            meta_summary["height"] = img.height
            
            exif_raw = img.getexif()
            if exif_raw:
                meta_summary["has_exif"] = True
                exif_dict = {}
                for tag_id, value in exif_raw.items():
                    tag_name = ExifTags.TAGS.get(tag_id, str(tag_id))
                    exif_dict[tag_name] = str(value)
                
                # Check editing software signatures
                software = exif_dict.get("Software", "") or exif_dict.get("ProcessingSoftware", "")
                if software:
                    meta_summary["software_detected"] = software
                    suspicious_tools = ["photoshop", "gimp", "canva", "paint.net", "photopea", "coreldraw", "illustrator"]
                    if any(t in software.lower() for t in suspicious_tools):
                        evidence.append({
                            "id": "META-EDIT-TOOL",
                            "category": "METADATA",
                            "severity": "HIGH",
                            "title": "Image Editing Software Footprint Detected",
                            "description": f"EXIF metadata contains traces of editing software: '{software}'.",
                            "why_it_matters": "Official credentials and legal documents should be produced directly by original issuing systems without subsequent raster image modification."
                        })
                    else:
                        evidence.append({
                            "id": "META-SOFTWARE",
                            "category": "METADATA",
                            "severity": "INFO",
                            "title": "Software Signature in Metadata",
                            "description": f"Image metadata references software: '{software}'.",
                            "why_it_matters": "Helps establish origin and generation pipeline context."
                        })
            else:
                meta_summary["has_exif"] = False
                evidence.append({
                    "id": "META-NO-EXIF",
                    "category": "METADATA",
                    "severity": "INFO",
                    "title": "No EXIF Metadata Found",
                    "description": "The image has no EXIF headers or metadata was stripped.",
                    "why_it_matters": "Standard for screenshots, scans, web-compressed images, and privacy-sanitized documents."
                })
    except Exception as e:
        evidence.append({
            "id": "META-ERR",
            "category": "METADATA",
            "severity": "LOW",
            "title": "Metadata Parsing Notice",
            "description": f"Unable to parse embedded EXIF metadata: {str(e)}",
            "why_it_matters": "File will still be analyzed using computer vision methods."
        })
        
    return evidence, meta_summary

def assess_image_quality(img_cv: np.ndarray) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Evaluate resolution, blur (Laplacian variance), and exposure/glare."""
    evidence = []
    h, w = img_cv.shape[:2]
    
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY) if len(img_cv.shape) == 3 else img_cv
    
    # 1. Blur calculation via Laplacian variance
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    blur_score = float(laplacian.var())
    
    # 2. Brightness & contrast
    mean_brightness = float(np.mean(gray))
    std_contrast = float(np.std(gray))
    
    # Check lighting / glare - White document paper normally has high brightness (230-250).
    # Real glare/washout occurs when variance/contrast collapses and highlights clip at 255.
    is_overexposed = mean_brightness > 252.0 and std_contrast < 12.0
    is_underexposed = mean_brightness < 40.0
    
    quality_summary = {
        "width": w,
        "height": h,
        "blur_score": round(blur_score, 2),
        "mean_brightness": round(mean_brightness, 2),
        "std_contrast": round(std_contrast, 2),
        "is_blurry": blur_score < LAPLACIAN_BLUR_THRESHOLD,
        "is_underexposed": is_underexposed,
        "is_overexposed": is_overexposed,
        "is_low_res": w < MIN_IMAGE_WIDTH or h < MIN_IMAGE_HEIGHT
    }
    
    # Check blur
    if quality_summary["is_blurry"]:
        severity = "HIGH" if blur_score < 40.0 else "MEDIUM"
        evidence.append({
            "id": "QUAL-BLUR",
            "category": "IMAGE_QUALITY",
            "severity": severity,
            "title": "Severe Image Blur / Motion Defocus Detected",
            "description": f"Laplacian sharpness metric is {blur_score:.1f} (threshold: {LAPLACIAN_BLUR_THRESHOLD}).",
            "why_it_matters": "Heavy blur obscures fine typographic security features, microprint, and character strokes, preventing dependable automated verification."
        })
    else:
        evidence.append({
            "id": "QUAL-SHARP",
            "category": "IMAGE_QUALITY",
            "severity": "INFO",
            "title": "Adequate Document Sharpness",
            "description": f"Laplacian variance metric: {blur_score:.1f}. High-frequency edge information is well preserved.",
            "why_it_matters": "Sufficient sharpness is required for accurate optical character recognition."
        })
        
    # Check lighting / glare
    if is_overexposed:
        evidence.append({
            "id": "QUAL-GLARE",
            "category": "IMAGE_QUALITY",
            "severity": "MEDIUM",
            "title": "High Specular Glare / Washout Detected",
            "description": f"Average luminance is {mean_brightness:.1f} with collapsed contrast ({std_contrast:.1f}). Text washed out by hot spots.",
            "why_it_matters": "Specular glare washes out document text and masks potential digital edits."
        })
    elif is_underexposed:
        evidence.append({
            "id": "QUAL-DARK",
            "category": "IMAGE_QUALITY",
            "severity": "MEDIUM",
            "title": "Underexposed / Low-Light Capture",
            "description": f"Average luminance is {mean_brightness:.1f}. Image is excessively dark.",
            "why_it_matters": "Dark images introduce digital sensor noise that reduces OCR confidence."
        })
        
    # Check resolution
    if quality_summary["is_low_res"]:
        evidence.append({
            "id": "QUAL-LOWRES",
            "category": "IMAGE_QUALITY",
            "severity": "HIGH",
            "title": "Sub-Standard Resolution",
            "description": f"Dimensions {w}x{h} are below minimum recommended {MIN_IMAGE_WIDTH}x{MIN_IMAGE_HEIGHT}.",
            "why_it_matters": "Low resolution causes character interpolation artifacts and limits forensic precision."
        })
        
    return evidence, quality_summary

def compute_error_level_analysis(
    img_cv: np.ndarray,
    output_dir: Path,
    case_uid: str
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], np.ndarray, List[Dict[str, int]]]:
    """
    Error Level Analysis (ELA):
    Resaves image at 90% JPEG quality, calculates pixel-wise absolute difference.
    Altered regions with distinct compression history display elevated error deltas.
    """
    evidence = []
    suspicious_boxes = []
    
    # Save temp JPEG at known quality
    temp_jpeg = output_dir / f"temp_ela_{case_uid}.jpg"
    cv2.imwrite(str(temp_jpeg), img_cv, [int(cv2.IMWRITE_JPEG_QUALITY), ELA_QUALITY])
    
    # Reload and compute absolute difference
    recompressed = cv2.imread(str(temp_jpeg))
    if temp_jpeg.exists():
        temp_jpeg.unlink()
        
    if recompressed is None:
        return evidence, {"error": "ELA recompression failed"}, np.zeros_like(img_cv), suspicious_boxes

    # Match shapes if slight padding occurred
    h, w = img_cv.shape[:2]
    recompressed = cv2.resize(recompressed, (w, h))

    # Absolute difference
    diff = cv2.absdiff(img_cv, recompressed).astype(np.float32)
    # Scale difference
    diff_scaled = np.clip(diff * ELA_SCALE, 0, 255).astype(np.uint8)
    
    diff_gray = cv2.cvtColor(diff_scaled, cv2.COLOR_BGR2GRAY)
    
    mean_ela = float(np.mean(diff_gray))
    std_ela = float(np.std(diff_gray))
    max_ela = float(np.max(diff_gray))
    
    # Find local candidate anomaly clusters (regions where ELA difference is > mean + 2.8*std)
    threshold_val = min(250, mean_ela + 2.8 * std_ela)
    _, thresh_mask = cv2.threshold(diff_gray, max(int(threshold_val), 40), 255, cv2.THRESH_BINARY)
    
    # Morphological dilation to group adjacent outlier pixels
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
    dilated_mask = cv2.dilate(thresh_mask, kernel, iterations=2)
    
    contours, _ = cv2.findContours(dilated_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    total_area = w * h
    for cnt in contours:
        area = cv2.contourArea(cnt)
        # Filter for meaningful suspicious clusters (e.g. between 0.05% and 25% of image area)
        if area > (total_area * 0.0005) and area < (total_area * 0.25):
            bx, by, bw, bh = cv2.boundingRect(cnt)
            # Check aspect ratio
            aspect = bw / float(bh) if bh > 0 else 0
            if aspect > 0.15 and aspect < 15.0:
                suspicious_boxes.append({
                    "x": int(bx),
                    "y": int(by),
                    "w": int(bw),
                    "h": int(bh),
                    "area": int(area),
                    "reason": "Elevated compression error gradient (ELA anomaly)"
                })
                
    has_high_compression_inconsistency = (mean_ela > ELA_ANOMALY_THRESHOLD) or (mean_ela > 20.0 and len(suspicious_boxes) >= 3)
    ela_summary = {
        "mean_error": round(mean_ela, 2),
        "std_error": round(std_ela, 2),
        "max_error": round(max_ela, 2),
        "anomaly_clusters_count": len(suspicious_boxes),
        "has_high_compression_inconsistency": has_high_compression_inconsistency
    }
    
    if has_high_compression_inconsistency:
        evidence.append({
            "id": "FORENSIC-ELA-01",
            "category": "COMPRESSION_FORENSICS",
            "severity": "HIGH",
            "title": f"Local Compression Discrepancies ({len(suspicious_boxes)} clusters detected)",
            "description": f"Error Level Analysis highlighted {len(suspicious_boxes)} discrete regions exhibiting elevated error response compared to document background.",
            "why_it_matters": "When text or graphics are pasted from external sources into a JPEG document, their compression signature diverges from the surrounding canvas."
        })
    elif len(suspicious_boxes) >= 1:
        evidence.append({
            "id": "FORENSIC-ELA-02",
            "category": "COMPRESSION_FORENSICS",
            "severity": "LOW",
            "title": "Minor Local Compression Discontinuity",
            "description": f"{len(suspicious_boxes)} localized region(s) demonstrated minor compression variance.",
            "why_it_matters": "Could reflect legitimate graphic elements, signatures, or a candidate modified patch."
        })
    else:
        evidence.append({
            "id": "FORENSIC-ELA-OK",
            "category": "COMPRESSION_FORENSICS",
            "severity": "INFO",
            "title": "Uniform Error Level Profile",
            "description": f"ELA error distribution is globally coherent (mean error delta: {mean_ela:.1f}). No localized recompression anomalies found.",
            "why_it_matters": "Document shows uniform compression history across all quadrants."
        })

    return evidence, ela_summary, diff_scaled, suspicious_boxes

def analyze_noise_and_splicing(img_cv: np.ndarray) -> Tuple[List[Dict[str, Any]], Dict[str, Any], List[Dict[str, int]]]:
    """Analyze high-frequency block noise variance and sharp rectangular splicing edges."""
    evidence = []
    splicing_boxes = []
    
    gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY) if len(img_cv.shape) == 3 else img_cv
    h, w = gray.shape
    
    # 1. High-pass filter to isolate sensor noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    noise_residual = cv2.absdiff(gray, blurred)
    
    # Compute block-level noise variances across 32x32 blocks
    block_size = 32
    variances = []
    for y in range(0, h - block_size, block_size):
        for x in range(0, w - block_size, block_size):
            patch = noise_residual[y:y+block_size, x:x+block_size]
            var = np.var(patch)
            variances.append(var)
            
    if variances:
        var_mean = np.mean(variances)
        var_std = np.std(variances)
        dispersion = (var_std / var_mean) if var_mean > 0 else 0
    else:
        var_mean, var_std, dispersion = 0, 0, 0
        
    noise_summary = {
        "noise_variance_mean": round(float(var_mean), 2),
        "noise_variance_std": round(float(var_std), 2),
        "dispersion_coefficient": round(float(dispersion), 2)
    }
    
    # 2. Rectangular boundary detection for spliced patches
    # Spliced rectangular patches often show distinctive rectangular gradients
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    for cnt in contours:
        approx = cv2.approxPolyDP(cnt, 0.03 * cv2.arcLength(cnt, True), True)
        if len(approx) == 4 and cv2.isContourConvex(approx):
            area = cv2.contourArea(approx)
            # Only examine plausible pasted text/signature box sizes (between 0.1% and 15% of image)
            if (w * h * 0.001) < area < (w * h * 0.15):
                bx, by, bw, bh = cv2.boundingRect(approx)
                aspect = bw / float(bh) if bh > 0 else 0
                # Filter for elongated text boxes
                if 2.0 < aspect < 12.0:
                    splicing_boxes.append({
                        "x": int(bx),
                        "y": int(by),
                        "w": int(bw),
                        "h": int(bh),
                        "area": int(area),
                        "reason": "Rectangular contour edge anomaly with high-gradient boundary"
                    })
                    
    if len(splicing_boxes) > 0:
        evidence.append({
            "id": "FORENSIC-SPLICING-01",
            "category": "STRUCTURAL_FORENSICS",
            "severity": "HIGH",
            "title": f"Candidate Spliced Rectangular Boundary ({len(splicing_boxes)} detected)",
            "description": f"Identified sharp rectangular bounding discontinuities characteristic of pasted digital patches.",
            "why_it_matters": "Forgers frequently cut and paste replacement designations, marks, or names inside existing certificates."
        })
    else:
        evidence.append({
            "id": "FORENSIC-SPLICING-OK",
            "category": "STRUCTURAL_FORENSICS",
            "severity": "INFO",
            "title": "Continuous Structural Edges",
            "description": "No unnatural rectilinear gradient cut-lines or splicing seams were detected.",
            "why_it_matters": "Document substrate and layout lines show expected continuity."
        })
        
    return evidence, noise_summary, splicing_boxes

def generate_annotated_forensics_visual(
    img_cv: np.ndarray,
    ela_diff_scaled: np.ndarray,
    suspicious_boxes: List[Dict[str, int]],
    output_path: Path
) -> str:
    """Generate side-by-side or composite annotated image highlighting detected anomalies."""
    h, w = img_cv.shape[:2]
    
    # 1. Create jet color heatmap from ELA difference
    diff_gray = cv2.cvtColor(ela_diff_scaled, cv2.COLOR_BGR2GRAY) if len(ela_diff_scaled.shape) == 3 else ela_diff_scaled
    heatmap = cv2.applyColorMap(diff_gray, cv2.COLORMAP_JET)
    
    # 2. Alpha blend heatmap onto original image (60% original + 40% heatmap)
    blend = cv2.addWeighted(img_cv, 0.65, heatmap, 0.35, 0)
    
    # 3. Draw bounding boxes and alert flags on candidate anomaly regions
    annotated = blend.copy()
    for i, b in enumerate(suspicious_boxes[:6]):  # annotate top candidate regions
        bx, by, bw, bh = b["x"], b["y"], b["w"], b["h"]
        # Draw glowing red/cyan box
        cv2.rectangle(annotated, (bx, by), (bx + bw, by + bh), (0, 0, 255), 3)
        cv2.rectangle(annotated, (bx - 1, by - 1), (bx + bw + 1, by + bh + 1), (0, 230, 255), 1)
        
        label = f"ANOMALY #{i+1}"
        cv2.putText(annotated, label, (bx, max(20, by - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2)
        cv2.putText(annotated, label, (bx, max(20, by - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

    # 4. Stamp header watermark
    header_bar = np.zeros((45, w, 3), dtype=np.uint8)
    header_bar[:] = (31, 17, 7)  # Navy #07111F
    cv2.putText(header_bar, "INTELLIGENT DOCUMENT AUTHENTICATION DEVICE - ERROR LEVEL ANALYSIS & ANOMALY HEATMAP",
                (20, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (0, 229, 255), 2)
    
    combined = np.vstack([header_bar, annotated])
    
    # Save visualization
    cv2.imwrite(str(output_path), combined)
    return str(output_path)

def run_forensic_pipeline(
    file_path: Path,
    case_uid: str,
    output_dir: Path
) -> Dict[str, Any]:
    """Execute complete explainable forensics pipeline on document."""
    all_evidence = []
    
    # 1. Metadata analysis
    meta_evidence, meta_summary = analyze_metadata(file_path)
    all_evidence.extend(meta_evidence)
    
    # Convert or load as OpenCV image
    img_cv = None
    if file_path.suffix.lower() == ".pdf":
        # Render first page of PDF using PyPDF or fitz if available, or load fallback
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(file_path))
            num_pages = len(reader.pages)
            meta_summary["pdf_pages"] = num_pages
            # If PDF has embedded images, extract first image for forensics
            page0 = reader.pages[0]
            if len(page0.images) > 0:
                first_img = page0.images[0]
                temp_extracted = output_dir / f"extracted_pdf_{case_uid}.png"
                with open(temp_extracted, "wb") as f:
                    f.write(first_img.data)
                img_cv = cv2.imread(str(temp_extracted))
                if temp_extracted.exists():
                    temp_extracted.unlink()
        except Exception as e:
            all_evidence.append({
                "id": "PDF-READ-ERR",
                "category": "METADATA",
                "severity": "LOW",
                "title": "PDF Extraction Notice",
                "description": f"PDF raster extraction: {str(e)}",
                "why_it_matters": "Digital text will still be screened via native PDF parser."
            })
            
    if img_cv is None:
        img_cv = cv2.imread(str(file_path))
        
    if img_cv is None:
        # Generate dummy 800x600 for non-raster PDF to allow consistent pipeline execution
        img_cv = np.ones((800, 1100, 3), dtype=np.uint8) * 250
        cv2.putText(img_cv, "DIGITAL PDF CONTAINER - VECTOR TEXT DOCUMENT", (150, 400),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (50, 50, 50), 2)

    # 2. Quality assessment
    qual_evidence, quality_summary = assess_image_quality(img_cv)
    all_evidence.extend(qual_evidence)
    
    # 3. Error Level Analysis (ELA)
    ela_evidence, ela_summary, diff_scaled, ela_boxes = compute_error_level_analysis(img_cv, output_dir, case_uid)
    all_evidence.extend(ela_evidence)
    
    # 4. Noise & Splicing Edge Analysis
    noise_evidence, noise_summary, splicing_boxes = analyze_noise_and_splicing(img_cv)
    all_evidence.extend(noise_evidence)
    
    # Combine candidate anomaly boxes
    all_anomaly_boxes = ela_boxes + splicing_boxes
    
    # 5. Generate forensics annotated heatmap
    heatmap_filename = f"heatmap_{case_uid}.jpg"
    heatmap_path = output_dir / heatmap_filename
    generate_annotated_forensics_visual(img_cv, diff_scaled, all_anomaly_boxes, heatmap_path)
    
    # Calculate overall forensic risk
    has_critical = any(e["severity"] == "CRITICAL" for e in all_evidence)
    has_high = any(e["severity"] == "HIGH" for e in all_evidence)
    has_medium = any(e["severity"] == "MEDIUM" for e in all_evidence)
    
    if has_critical:
        forensic_risk = "CRITICAL"
    elif has_high:
        forensic_risk = "HIGH"
    elif has_medium:
        forensic_risk = "MEDIUM"
    else:
        forensic_risk = "LOW"
        
    return {
        "case_uid": case_uid,
        "metadata": meta_summary,
        "quality": quality_summary,
        "ela": ela_summary,
        "noise": noise_summary,
        "anomaly_boxes_count": len(all_anomaly_boxes),
        "forensic_risk": forensic_risk,
        "evidence_list": all_evidence,
        "heatmap_file": heatmap_filename,
        "heatmap_path": str(heatmap_path)
    }
