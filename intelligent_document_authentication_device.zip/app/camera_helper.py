import cv2
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import base64

def order_points(pts: np.ndarray) -> np.ndarray:
    """Order points in clockwise order: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect

def four_point_transform(image: np.ndarray, pts: np.ndarray) -> np.ndarray:
    """Apply perspective transform to warp document quadrangle into flat rectangle."""
    rect = order_points(pts)
    (tl, tr, br, bl) = rect

    # Width of new image
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))

    # Height of new image
    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    maxHeight = max(int(heightA), int(heightB))

    # Minimum bounding safety
    maxWidth = max(maxWidth, 400)
    maxHeight = max(maxHeight, 300)

    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]
    ], dtype="float32")

    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
    return warped

def find_document_contour(image: np.ndarray) -> Optional[np.ndarray]:
    """Detect 4-corner document quadrilateral boundary in camera capture."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 60, 180)
    
    # Dilate edges to close gaps
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    dilated = cv2.dilate(edged, kernel, iterations=1)

    contours, _ = cv2.findContours(dilated, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]

    img_area = image.shape[0] * image.shape[1]
    for c in contours:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.03 * peri, True)
        area = cv2.contourArea(approx)
        
        # Must occupy at least 15% of frame to be a document
        if len(approx) == 4 and area > (img_area * 0.15):
            return approx.reshape(4, 2)
            
    return None

def process_camera_frame(
    image_bytes: bytes,
    output_path: Path,
    auto_warp: bool = True
) -> Dict[str, Any]:
    """
    Process image captured by camera:
    - Assess blur and lighting
    - Detect document boundary & perspective correct if available
    - Enhance text contrast
    - Save sanitized capture file
    """
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image from camera buffer.")

    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # 1. Quality checks
    laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    mean_lum = float(np.mean(gray))
    
    is_blurry = laplacian_var < 80.0
    is_dark = mean_lum < 40.0
    is_glare = mean_lum > 240.0
    
    guidance = []
    if is_blurry:
        guidance.append("Image appears blurry. Hold camera steady or tap to refocus.")
    if is_dark:
        guidance.append("Lighting is dim. Increase ambient light for accurate scanning.")
    if is_glare:
        guidance.append("Strong glare detected. Tilt document away from direct lights.")
        
    # 2. Boundary detection & perspective warp
    doc_pts = find_document_contour(img)
    boundary_detected = doc_pts is not None
    
    final_img = img
    if boundary_detected and auto_warp:
        try:
            warped = four_point_transform(img, doc_pts)
            # Only use warp if resulting dimensions are reasonable
            if warped.shape[0] >= 300 and warped.shape[1] >= 400:
                final_img = warped
                guidance.append("Document boundary detected: perspective auto-corrected.")
        except Exception:
            final_img = img
            
    if not boundary_detected:
        guidance.append("Align entire document within the guide frame before capture.")
        
    # 3. Save final image
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), final_img)
    
    return {
        "saved_path": str(output_path),
        "width": int(final_img.shape[1]),
        "height": int(final_img.shape[0]),
        "blur_score": round(laplacian_var, 1),
        "mean_brightness": round(mean_lum, 1),
        "is_blurry": is_blurry,
        "is_dark": is_dark,
        "is_glare": is_glare,
        "boundary_detected": boundary_detected,
        "guidance": guidance or ["Capture quality is optimal for document verification."]
    }
