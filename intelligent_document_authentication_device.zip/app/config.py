import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
APP_DIR = BASE_DIR / "app"
STATIC_DIR = APP_DIR / "static"
TEMPLATES_DIR = APP_DIR / "templates"
SAMPLES_DIR = STATIC_DIR / "samples"

STORAGE_DIR = BASE_DIR / "storage"
UPLOAD_DIR = STORAGE_DIR / "uploads"
REPORTS_DIR = STORAGE_DIR / "reports"
DB_PATH = STORAGE_DIR / "verifier.db"

# Ensure directories exist
for path in [UPLOAD_DIR, REPORTS_DIR, SAMPLES_DIR]:
    path.mkdir(parents=True, exist_ok=True)

# Branding & Metadata
PROJECT_NAME = "Intelligent Document Authentication System"
TAGLINE = "Powered by Deep Learning"
TEAM_NAME = "Nexora"
TEAM_LEADER = "S. Deepak"
TEAM_MEMBERS = [
    "S. Deepak — Team Leader",
    "L. Dhanushya",
    "M. S. Elamparuthi",
    "G. Kavin"
]
DEVELOPER_CREDIT = "Team Nexora (S. Deepak — Team Leader, L. Dhanushya, M. S. Elamparuthi, G. Kavin)"
EVENT_NAME = "QUANTIX 2K26 — 24-Hour Hackathon"
PROJECT_GOAL = "Help users examine documents for possible tampering, extract their information using OCR, compare them with trusted reference records where available, and provide an explainable verification result."

# Security & Upload Constraints
MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024  # 10 MB per Phase 4 requirement
ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg"}
ALLOWED_MIME_TYPES = {
    "image/jpeg",
    "image/png",
    "application/pdf",
    "application/octet-stream"  # sometimes sent by browsers for binary
}

# OCR Settings
TESSERACT_CMD_ENV = os.getenv("TESSERACT_CMD", "")
COMMON_TESSERACT_PATHS = [
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    r"C:\Users\Deepa\AppData\Local\Programs\Tesseract-OCR\tesseract.exe",
]

def get_tesseract_path() -> str:
    if TESSERACT_CMD_ENV and os.path.exists(TESSERACT_CMD_ENV):
        return TESSERACT_CMD_ENV
    for p in COMMON_TESSERACT_PATHS:
        if os.path.exists(p):
            return p
    return ""

# Verification Decisions
STATUS_REAL = "REAL — VERIFIED"
STATUS_FAKE = "FAKE — EVIDENCE FOUND"
STATUS_SUSPICIOUS = "SUSPICIOUS — MANUAL REVIEW REQUIRED"

# Image Forensics Thresholds
ELA_SCALE = 15
ELA_QUALITY = 90
ELA_ANOMALY_THRESHOLD = 28.0  # Mean difference threshold indicating non-uniform compression
LAPLACIAN_BLUR_THRESHOLD = 95.0  # Below 95 is considered blurry
MIN_IMAGE_WIDTH = 400
MIN_IMAGE_HEIGHT = 400
