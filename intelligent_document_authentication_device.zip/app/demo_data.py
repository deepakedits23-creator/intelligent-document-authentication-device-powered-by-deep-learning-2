import os
import json
import numpy as np
import cv2
import qrcode
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from app.config import SAMPLES_DIR
from app.database import get_db_connection

def get_font(size: int, bold: bool = False):
    font_paths = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for p in font_paths:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

DEMO_SAMPLES_METADATA = [
    {
        "id": "sample-1",
        "title": "Sample 1: Authoritative Verified Certificate",
        "doc_type": "Degree Certificate",
        "filename": "sample1_verified_degree.png",
        "expected_status": "REAL — VERIFIED",
        "description": "Synthetic degree certificate matching an authoritative simulated registry ledger with zero tampering anomalies.",
        "badge_color": "green",
        "reference_id": "KSR-2026-ENG-8492"
    },
    {
        "id": "sample-2",
        "title": "Sample 2: Altered Identity / Field Mismatch",
        "doc_type": "National Identity Card",
        "filename": "sample2_altered_identity.png",
        "expected_status": "FAKE — EVIDENCE FOUND",
        "description": "Registered document ID NAT-2026-ID-4410 exists in database for 'Priya Sharma', but name on document was altered to 'Robert Vance'.",
        "badge_color": "red",
        "reference_id": "NAT-2026-ID-4410"
    },
    {
        "id": "sample-3",
        "title": "Sample 3: Digitally Tampered / Spliced Patch",
        "doc_type": "Experience Certificate",
        "filename": "sample3_tampered_experience.png",
        "expected_status": "FAKE — EVIDENCE FOUND",
        "description": "Employment certificate showing pasted text block with sharp edge discontinuity, compression mismatch, and Photoshop tags.",
        "badge_color": "red",
        "reference_id": "EXP-2025-CYBER-993"
    },
    {
        "id": "sample-4",
        "title": "Sample 4: Blurry / Degraded Scan",
        "doc_type": "Academic Transcript",
        "filename": "sample4_blurry_scan.png",
        "expected_status": "SUSPICIOUS — MANUAL REVIEW REQUIRED",
        "description": "Document with severe motion blur and low contrast where OCR extraction confidence is insufficient for automated screening.",
        "badge_color": "amber",
        "reference_id": "NONE"
    },
    {
        "id": "sample-5",
        "title": "Sample 5: Unregistered Unknown Document",
        "doc_type": "Professional Certificate",
        "filename": "sample5_unknown_document.png",
        "expected_status": "SUSPICIOUS — MANUAL REVIEW REQUIRED",
        "description": "Visually clean document without detectable tampering, but no matching record exists in reference repository and no authoritative confirmation is available.",
        "badge_color": "amber",
        "reference_id": "IQA-9912-UNKNOWN"
    }
]

def seed_reference_database() -> None:
    """Populate reference_records table with synthetic test records."""
    records = [
        (
            "KSR-2026-ENG-8492",
            "Degree Certificate",
            "KSR Institute of Technology",
            "Deepak Kumar",
            "2026-05-15",
            None,
            "ACTIVE",
            1,  # Authoritative verified ledger emulation
            "Synthetic degree record. Authorized by Registrar Office for QUANTIX 2K26 testing."
        ),
        (
            "NAT-2026-ID-4410",
            "National Identity Card",
            "National Identification Authority",
            "Priya Sharma",
            "2024-01-10",
            "2034-01-10",
            "ACTIVE",
            0,
            "Registered ID for Priya Sharma. Any document claiming this ID with another name is invalid."
        ),
        (
            "EXP-2025-CYBER-993",
            "Experience Certificate",
            "Apex Cyber Defence Laboratories",
            "Alex Mercer",
            "2025-11-20",
            None,
            "ACTIVE",
            0,
            "Original designation: Junior Security Analyst. Validated reference."
        ),
        (
            "MED-2026-LIC-1029",
            "Medical Board License",
            "State Medical Council",
            "Dr. Sunita Patel",
            "2023-04-12",
            "2028-04-12",
            "ACTIVE",
            1,
            "Synthetic medical license with authoritative registry integration."
        )
    ]
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        for r in records:
            cursor.execute("""
                INSERT OR IGNORE INTO reference_records (
                    record_id, doc_type, issuer_name, holder_name,
                    issue_date, expiry_date, status, is_authoritative, notes,
                    metadata_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '{}', datetime('now'))
            """, r)
        conn.commit()

def generate_synthetic_samples(force: bool = True) -> None:
    """Generate high-resolution synthetic test images with readable TrueType typography."""
    SAMPLES_DIR.mkdir(parents=True, exist_ok=True)
    
    font_large = get_font(36, bold=True)
    font_header = get_font(26, bold=True)
    font_title = get_font(22, bold=True)
    font_body = get_font(20, bold=False)
    font_bold = get_font(20, bold=True)
    font_small = get_font(16, bold=False)
    
    # ------------------ SAMPLE 1: Clean Authoritative Degree with Logo, Seal & QR ------------------
    s1_path = SAMPLES_DIR / "sample1_verified_degree.png"
    if force or not s1_path.exists():
        img = Image.new("RGB", (1400, 950), color=(252, 250, 245))
        d = ImageDraw.Draw(img)
        # Decorative double borders
        d.rectangle([(30, 30), (1370, 920)], outline=(15, 35, 75), width=5)
        d.rectangle([(42, 42), (1358, 908)], outline=(190, 150, 40), width=2)
        
        # Institutional Crest / Emblem
        d.rectangle([(180, 65), (280, 165)], fill=(15, 35, 75), outline=(190, 150, 40), width=3)
        d.polygon([(180, 115), (230, 165), (280, 115), (280, 65), (180, 65)], fill=(20, 50, 100), outline=(190, 150, 40))
        d.text((205, 100), "KSR", font=font_title, fill=(255, 255, 255))
        d.text((222, 132), "★", font=font_small, fill=(190, 150, 40))

        # Header
        d.text((360, 70), "KSR INSTITUTE OF TECHNOLOGY", font=font_large, fill=(15, 35, 75))
        d.text((430, 125), "Autonomous Institution - Tiruchengode, Tamil Nadu", font=font_body, fill=(70, 80, 100))
        d.text((480, 160), "Accredited with 'A++' Grade by NAAC", font=font_body, fill=(180, 130, 20))
        
        # Title
        d.text((440, 230), "DEGREE CERTIFICATE", font=font_header, fill=(15, 35, 75))
        
        # Body text
        d.text((220, 310), "This is to certify that", font=font_body, fill=(50, 50, 50))
        d.text((540, 345), "DEEPAK KUMAR", font=font_header, fill=(10, 25, 60))
        d.text((220, 400), "has been duly admitted to the Degree of Bachelor of Engineering in", font=font_body, fill=(50, 50, 50))
        d.text((390, 440), "COMPUTER SCIENCE AND ENGINEERING", font=font_title, fill=(20, 40, 80))
        d.text((220, 490), "having fulfilled all academic requirements with First Class with Distinction.", font=font_body, fill=(50, 50, 50))
        
        # Metadata footer
        d.text((120, 620), "Document Number: KSR-2026-ENG-8492", font=font_bold, fill=(30, 30, 30))
        d.text((120, 665), "Date of Issue: 2026-05-15", font=font_bold, fill=(30, 30, 30))
        d.text((120, 710), "Issuer: KSR Institute of Technology", font=font_bold, fill=(30, 30, 30))
        d.text((120, 755), "Auth Ledger Token: AUTH-REG-99120-VERIFIED", font=font_bold, fill=(20, 120, 40))
        
        # Signatures
        d.text((880, 640), "[ Dr. R. Murugan ]", font=font_bold, fill=(20, 30, 50))
        d.text((880, 675), "Controller of Examinations", font=font_small, fill=(70, 70, 70))
        d.text((880, 715), "Registrar", font=font_small, fill=(70, 70, 70))
        
        # Watermark / Official Embossed Seal
        d.ellipse([(570, 600), (750, 780)], outline=(190, 150, 40), width=5)
        d.ellipse([(582, 612), (738, 768)], outline=(190, 150, 40), width=2)
        d.text((615, 665), "★ OFFICIAL SEAL ★", font=font_small, fill=(190, 150, 40))
        d.text((605, 695), "KSR EDUCATIONAL", font=font_bold, fill=(180, 130, 20))
        d.text((620, 725), "INSTITUTIONS", font=font_small, fill=(180, 130, 20))

        # Real Cryptographic Scannable QR Code
        qr1 = qrcode.QRCode(box_size=3, border=1)
        qr1.add_data(json.dumps({
            "cert_id": "KSR-2026-ENG-8492",
            "name": "DEEPAK KUMAR",
            "issuer": "KSR Institute of Technology",
            "status": "VERIFIED_ACTIVE"
        }))
        qr1.make(fit=True)
        qr1_pil = qr1.make_image(fill_color="black", back_color="white").convert("RGB")
        img.paste(qr1_pil, (1160, 660))
        d.rectangle([(1158, 658), (1160 + qr1_pil.width + 2, 660 + qr1_pil.height + 2)], outline=(15, 35, 75), width=2)
        d.text((1170, 835), "SCAN TO VERIFY", font=font_small, fill=(15, 35, 75))

        img.save(s1_path, "PNG")

    # ------------------ SAMPLE 2: Altered Identity (Visual Name != QR Name) ------------------
    s2_path = SAMPLES_DIR / "sample2_altered_identity.png"
    if force or not s2_path.exists():
        img = Image.new("RGB", (1200, 750), color=(240, 244, 248))
        d = ImageDraw.Draw(img)
        d.rectangle([(25, 25), (1175, 725)], outline=(15, 60, 110), width=4)
        d.rectangle([(35, 35), (1165, 130)], fill=(15, 60, 110))
        d.text((320, 50), "NATIONAL DIGITAL IDENTITY CARD", font=font_large, fill=(255, 255, 255))
        d.text((370, 95), "NATIONAL IDENTIFICATION AUTHORITY", font=font_title, fill=(200, 225, 255))
        
        # Photo placeholder
        d.rectangle([(80, 180), (320, 480)], fill=(215, 220, 230), outline=(100, 100, 100), width=3)
        d.text((150, 310), "[ PHOTO ]", font=font_title, fill=(100, 100, 100))
        
        # Altered field: Visible text says Robert Vance, but QR says Priya Sharma
        d.text((380, 190), "Card ID Number: NAT-2026-ID-4410", font=font_bold, fill=(20, 20, 20))
        d.text((380, 250), "Cardholder Name: ROBERT VANCE", font=font_bold, fill=(190, 20, 20))  # Discrepancy!
        d.text((380, 310), "Date of Issue: 2024-01-10", font=font_body, fill=(30, 30, 30))
        d.text((380, 360), "Date of Expiry: 2034-01-10", font=font_body, fill=(30, 30, 30))
        d.text((380, 410), "Authority: National Identification Authority", font=font_body, fill=(30, 30, 30))
        
        # Real Cryptographic Scannable QR Code (Encodes the true original registered holder: Priya Sharma!)
        qr2 = qrcode.QRCode(box_size=3, border=1)
        qr2.add_data(json.dumps({
            "cert_id": "NAT-2026-ID-4410",
            "name": "PRIYA SHARMA",
            "issuer": "National Identification Authority",
            "status": "ACTIVE"
        }))
        qr2.make(fit=True)
        qr2_pil = qr2.make_image(fill_color="black", back_color="white").convert("RGB")
        img.paste(qr2_pil, (950, 480))
        d.rectangle([(948, 478), (950 + qr2_pil.width + 2, 480 + qr2_pil.height + 2)], outline=(15, 60, 110), width=2)
        d.text((955, 650), "SECURITY QR", font=font_small, fill=(15, 60, 110))

        d.text((80, 580), "DISCLAIMER: DEMO SYNTHETIC SAMPLE FOR TESTING QUANTIX 2K26 VERIFICATION ENGINE", font=font_small, fill=(120, 120, 120))
        img.save(s2_path, "PNG")

    # ------------------ SAMPLE 3: Spliced / Tampered Experience Certificate ------------------
    s3_path = SAMPLES_DIR / "sample3_tampered_experience.png"
    if force or not s3_path.exists():
        img = Image.new("RGB", (1300, 900), color=(250, 252, 255))
        d = ImageDraw.Draw(img)
        d.rectangle([(25, 25), (1275, 875)], outline=(40, 50, 70), width=3)
        
        d.text((320, 60), "APEX CYBER DEFENCE LABORATORIES", font=font_large, fill=(20, 40, 80))
        d.text((390, 120), "EXPERIENCE & APPRECIATION CERTIFICATE", font=font_header, fill=(90, 100, 120))
        
        d.text((100, 200), "Reference Number: EXP-2025-CYBER-993", font=font_bold, fill=(40, 40, 40))
        d.text((100, 245), "Date of Issue: 2025-11-20", font=font_bold, fill=(40, 40, 40))
        d.text((100, 290), "Issuer: Apex Cyber Defence Laboratories", font=font_bold, fill=(40, 40, 40))
        
        d.text((100, 370), "This document certifies that", font=font_body, fill=(60, 60, 60))
        d.text((420, 365), "ALEX MERCER", font=font_header, fill=(20, 20, 20))
        d.text((100, 430), "was employed with Apex Cyber Defence Laboratories from June 2021 to November 2025.", font=font_body, fill=(60, 60, 60))
        
        # Tampered patch simulation: draw spliced rectangular box with distinct color & font
        d.rectangle([(95, 490), (1150, 570)], fill=(230, 238, 250), outline=(150, 170, 200), width=3)
        d.text((115, 515), "Designation: CHIEF CYBERSECURITY ARCHITECT & SENIOR VICE PRESIDENT", font=font_bold, fill=(0, 0, 150))
        
        d.text((100, 630), "During their tenure, their conduct and contributions were evaluated as exceptional.", font=font_body, fill=(60, 60, 60))
        d.text((100, 740), "Authorized Signatory: Dr. Marcus Vance, Director of Cyber Forensics", font=font_bold, fill=(40, 40, 40))
        
        # Save as JPEG with compression artifact, and embed Photoshop software tag in EXIF
        exif = img.getexif()
        # EXIF tag 305 is Software
        exif[305] = "Adobe Photoshop 2026 (Windows)"
        img.save(s3_path, "JPEG", quality=75, exif=exif)

    # ------------------ SAMPLE 4: Blurry / Degraded Scan ------------------
    s4_path = SAMPLES_DIR / "sample4_blurry_scan.png"
    if force or not s4_path.exists():
        img = Image.new("RGB", (1200, 800), color=(235, 235, 230))
        d = ImageDraw.Draw(img)
        d.rectangle([(30, 30), (1170, 770)], outline=(80, 80, 80), width=3)
        d.text((350, 70), "ACADEMIC TRANSCRIPT RECORD", font=font_large, fill=(50, 50, 50))
        d.text((280, 130), "EXAMINATION BOARD RESULTS - RECORD OF MARKS", font=font_title, fill=(90, 90, 90))
        d.text((100, 220), "Student Identification: TRANS-2026-X992", font=font_body, fill=(60, 60, 60))
        d.text((100, 270), "Candidate Name: Samantha Green", font=font_body, fill=(60, 60, 60))
        d.text((100, 330), "Advanced Cryptography: 92/100  (Grade: O)", font=font_body, fill=(60, 60, 60))
        d.text((100, 380), "Machine Learning & AI: 88/100  (Grade: A+)", font=font_body, fill=(60, 60, 60))
        d.text((100, 440), "Information Forensics: 95/100  (Grade: O)", font=font_body, fill=(60, 60, 60))
        d.text((100, 550), "Date of Examination: 2026-03-22", font=font_body, fill=(80, 80, 80))
        
        # Apply heavy Gaussian blur to simulate severe out-of-focus camera capture
        blurred = img.filter(ImageFilter.GaussianBlur(radius=10.0))
        blurred.save(s4_path, "PNG")

    # ------------------ SAMPLE 5: Unregistered Unknown Document ------------------
    s5_path = SAMPLES_DIR / "sample5_unknown_document.png"
    if force or not s5_path.exists():
        img = Image.new("RGB", (1300, 850), color=(253, 254, 255))
        d = ImageDraw.Draw(img)
        d.rectangle([(30, 30), (1270, 820)], outline=(20, 70, 110), width=4)
        d.rectangle([(42, 42), (1258, 808)], outline=(180, 180, 190), width=2)
        
        d.text((360, 70), "INTERNATIONAL QUANTUM ACADEMY", font=font_large, fill=(10, 50, 90))
        d.text((380, 130), "CERTIFICATE OF PROFESSIONAL EXCELLENCE", font=font_header, fill=(100, 110, 130))
        
        d.text((220, 230), "This certificate is awarded to", font=font_body, fill=(70, 70, 70))
        d.text((500, 280), "ALAN T. CHEN", font=font_large, fill=(15, 30, 60))
        d.text((200, 370), "for successful completion of Quantum Cryptography & Deep Forensics Mastery.", font=font_body, fill=(70, 70, 70))
        
        d.text((120, 500), "Certificate ID: IQA-9912-UNKNOWN", font=font_bold, fill=(40, 40, 40))
        d.text((120, 550), "Date of Issuance: 2026-08-14", font=font_bold, fill=(40, 40, 40))
        d.text((120, 600), "Issuer: International Quantum Academy (Unregistered)", font=font_bold, fill=(40, 40, 40))
        
        d.text((850, 580), "[ Digital Signature Verified ]", font=font_bold, fill=(80, 80, 80))
        d.text((880, 620), "Academic Registrar", font=font_small, fill=(100, 100, 100))
        img.save(s5_path, "PNG")
