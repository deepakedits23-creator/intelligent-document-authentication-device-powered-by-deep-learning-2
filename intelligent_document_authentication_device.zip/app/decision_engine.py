from typing import Dict, Any, List
from app.config import STATUS_REAL, STATUS_FAKE, STATUS_SUSPICIOUS

def evaluate_verification_case(
    ocr_data: Dict[str, Any],
    forensic_data: Dict[str, Any],
    reference_data: Dict[str, Any],
    security_features: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Deterministic Verification Decision Engine following strict evidence rules:
    - REAL — VERIFIED only with genuine authoritative confirmation, logo/QR/name validation & zero tampering.
    - FAKE — EVIDENCE FOUND only with corroborated tampering, duplicate credential mismatch, or critical registry conflict.
    - SUSPICIOUS — MANUAL REVIEW REQUIRED for inconclusive, unverified, or degraded cases.
    """
    evidence_checklist = []
    limitations = []
    recommended_actions = []
    
    extracted_fields = ocr_data.get("fields", {})
    ocr_conf = ocr_data.get("confidence", 0.0)
    missing_fields = extracted_fields.get("missing_fields", [])
    
    forensic_evidence = forensic_data.get("evidence_list", [])
    forensic_risk = forensic_data.get("forensic_risk", "LOW")
    quality = forensic_data.get("quality", {})
    
    ref_found = reference_data.get("record_found", False)
    is_authoritative = reference_data.get("is_authoritative", False)
    has_critical_conflict = reference_data.get("has_critical_conflict", False)

    # Incorporate physical & digital security features (Logo, QR Code, Name Match)
    sec_critical_conflict = False
    if security_features:
        sec_critical_conflict = bool(security_features.get("has_critical_conflict", False))
        for item in security_features.get("security_checklist", []):
            evidence_checklist.append({
                "category": f"Security Features ({item.get('feature', 'Certificate Feature')})",
                "severity": "CRITICAL" if not item.get("passed") and item.get("status") in ["TAMPER_MISMATCH", "CRITICAL_CONFLICT"] else ("INFO" if item.get("passed") else "MEDIUM"),
                "title": item.get("feature", "Security Marker"),
                "summary": item.get("summary", ""),
                "impact": item.get("impact", "")
            })
    
    # Compile unified evidence items
    # 1. OCR findings
    if ocr_conf < 50.0 or len(missing_fields) >= 3:
        evidence_checklist.append({
            "category": "OCR & Extraction",
            "severity": "HIGH",
            "title": "Low OCR Extraction Confidence",
            "summary": f"OCR confidence is {ocr_conf:.1f}%. Critical fields missing: {', '.join(missing_fields) if missing_fields else 'Multiple'}.",
            "impact": "Unreliable textual data prevents definitive automated matching."
        })
    else:
        evidence_checklist.append({
            "category": "OCR & Extraction",
            "severity": "INFO",
            "title": "Text Successfully Extracted",
            "summary": f"Extracted document fields with {ocr_conf:.1f}% estimated confidence via {ocr_data.get('engine', 'OCR')}.",
            "impact": "Baseline text available for reference comparison."
        })

    # 2. Forensic findings
    for fe in forensic_evidence:
        if fe["severity"] in ["CRITICAL", "HIGH", "MEDIUM"]:
            evidence_checklist.append({
                "category": f"Forensics ({fe['category']})",
                "severity": fe["severity"],
                "title": fe["title"],
                "summary": fe["description"],
                "impact": fe["why_it_matters"]
            })
            
    # 3. Reference findings
    if ref_found:
        if has_critical_conflict:
            evidence_checklist.append({
                "category": "Reference Database",
                "severity": "CRITICAL",
                "title": "Registry Conflict: Identity Mismatch / Revocation",
                "summary": reference_data.get("summary", "Document fields conflict with registered record."),
                "impact": "Document presents conflicting credentials against registered repository."
            })
        else:
            evidence_checklist.append({
                "category": "Reference Database",
                "severity": "INFO" if is_authoritative else "LOW",
                "title": f"Reference Record Matched ({'Authoritative Source' if is_authoritative else 'Demo Local Cache'})",
                "summary": reference_data.get("summary", "Document fields correspond to reference entry."),
                "impact": "Matches reference data." if is_authoritative else "Synthetic demo match only; does not replace issuing authority confirmation."
            })
    else:
        evidence_checklist.append({
            "category": "Reference Database",
            "severity": "MEDIUM",
            "title": "No Reference Record Found",
            "summary": "Document ID could not be located in reference repository.",
            "impact": "Document origin cannot be cross-referenced without issuing authority query."
        })

    # ==================== DECISION RULES ====================
    
    # RULE 1: FAKE — EVIDENCE FOUND
    # Condition 1A: Record found, but critical conflict (e.g. name mismatch or revoked status)
    if ref_found and has_critical_conflict:
        outcome = STATUS_FAKE
        headline = "Discrepancy Detected: Document credentials conflict with registered reference record."
        reason = (
            "The document claims registered identifier '" + str(extracted_fields.get("doc_number")) +
            "', but the authoritative/reference repository records a critical conflict in holder identity or status."
        )
        recommended_actions = [
            "Do not accept this document as proof of credential.",
            "Contact the registered cardholder and issuing authority for official verification.",
            "Flag case for compliance review and fraud investigation."
        ]
        limitations = [
            "Finding is based on comparison against reference registry records.",
            "OCR transcription errors could theoretically contribute if fields were severely misread (user field review recommended)."
        ]
        return {
            "outcome": outcome,
            "headline": headline,
            "reason": reason,
            "severity": "CRITICAL",
            "badge_class": "badge-fake",
            "evidence_checklist": evidence_checklist,
            "limitations": limitations,
            "recommended_actions": recommended_actions
        }

    # Condition 1B: Corroborated Forensic Tampering
    # (High compression anomaly + spliced boundary OR editing tool footprint OR significant ELA clusters)
    has_splicing = any(e["id"].startswith("FORENSIC-SPLICING-01") for e in forensic_evidence)
    has_ela_anomaly = any(e["id"].startswith("FORENSIC-ELA-01") for e in forensic_evidence)
    has_edit_tool = any(e["id"].startswith("META-EDIT-TOOL") for e in forensic_evidence)
    ela_boxes_count = forensic_data.get("anomaly_boxes_count", 0)
    
    if (has_splicing and has_ela_anomaly) or (has_edit_tool and (has_splicing or has_ela_anomaly)) or (has_edit_tool and ela_boxes_count >= 2) or (has_splicing and ela_boxes_count >= 2):
        outcome = STATUS_FAKE
        headline = "Tampering Evidence Detected: Visual and digital artifacts indicate document manipulation."
        reason = (
            "Forensic analysis detected corroborating indicators of tampering: non-uniform compression error levels (ELA) "
            "coincident with spliced rectangular edge boundaries and/or photo-editing software fingerprints."
        )
        recommended_actions = [
            "Request the original physical document or cryptographically signed PDF directly from the issuing authority.",
            "Subject the document to formal manual forensic examination.",
            "Inspect candidate anomaly regions highlighted on the forensic heatmap."
        ]
        limitations = [
            "Image forensics flags digital and structural anomalies, which provide strong circumstantial evidence of tampering but do not replace legal certification by the issuing institution."
        ]
        return {
            "outcome": outcome,
            "headline": headline,
            "reason": reason,
            "severity": "HIGH",
            "badge_class": "badge-fake",
            "evidence_checklist": evidence_checklist,
            "limitations": limitations,
            "recommended_actions": recommended_actions
        }

    # Condition 1C: Security Feature Mismatch (e.g. QR Code payload contradicts Document Name / Duplicate Certificate)
    if sec_critical_conflict:
        outcome = STATUS_FAKE
        headline = "Duplicate / Altered Certificate Detected: Embedded QR Code or Credential Mismatch Found."
        conflict_msg = "; ".join(security_features.get("conflict_reasons", [])) if security_features else ""
        reason = (
            conflict_msg or
            "Critical security feature failure: The holder name or identifier in the embedded digital QR watermark "
            "contradicts visual document text or registered institutional ledger, indicating an unauthorized alteration or duplicate."
        )
        recommended_actions = [
            "Do not accept this certificate: Visual credentials contradict the embedded digital watermark.",
            "Verify the original credential directly via registrar portal.",
            "Report duplicate / altered credential to institutional compliance."
        ]
        limitations = [
            "Finding is corroborated by cryptographic QR payload decoding and multi-stage OCR field comparison."
        ]
        return {
            "outcome": outcome,
            "headline": headline,
            "reason": reason,
            "severity": "CRITICAL",
            "badge_class": "badge-fake",
            "evidence_checklist": evidence_checklist,
            "limitations": limitations,
            "recommended_actions": recommended_actions
        }

    # RULE 2: REAL — VERIFIED
    # Strict rule: Requires authoritative source confirmation, matching fields, and zero high/critical tampering indicators
    if is_authoritative and ref_found and not has_critical_conflict and not sec_critical_conflict and forensic_risk in ["LOW", "INFO"] and not quality.get("is_blurry", False):
        outcome = STATUS_REAL
        if security_features and security_features.get("overall_status") == "AUTHENTIC_ORIGINAL":
            headline = "Authenticity Confirmed: Institutional Logo, QR Code & Holder Name Verified."
            reason = (
                "Official institutional logo and embossed seal verified, cryptographic QR watermark validated, "
                "and holder name matches registered authoritative ledger with zero tampering anomalies."
            )
        else:
            headline = "Authenticity Confirmed: Verified against authoritative issuer registry with zero tampering detected."
            reason = (
                "Document identifier and holder credentials were successfully cross-referenced with the authoritative issuing registry ledger. "
                "Comprehensive image forensics confirmed clean structural continuity and uniform compression profile."
            )
        recommended_actions = [
            "Document can be accepted under standard operational credential workflows.",
            "Archive verification audit trail and verification certificate for compliance records."
        ]
        limitations = [
            "Verification is valid based on authoritative record state at the timestamp of query.",
            "Local test environment authoritative confirmations are simulated for demonstration purposes."
        ]
        return {
            "outcome": outcome,
            "headline": headline,
            "reason": reason,
            "severity": "LOW",
            "badge_class": "badge-real",
            "evidence_checklist": evidence_checklist,
            "limitations": limitations,
            "recommended_actions": recommended_actions
        }

    # RULE 3: SUSPICIOUS — MANUAL REVIEW REQUIRED (Default Safe Fallback)
    outcome = STATUS_SUSPICIOUS
    
    if quality.get("is_blurry", False):
        headline = "Review Required: Image quality too degraded for automated verification."
        reason = "Severe blur or focus degradation obscures critical security features and reduces OCR certainty below screening thresholds."
        recommended_actions = [
            "Re-scan document under steady, even lighting using the laptop camera or high-resolution scanner.",
            "Ensure document text is sharp and fill the scan frame before re-submitting."
        ]
    elif ref_found and not is_authoritative:
        headline = "Review Required: Matches local demo reference cache, but lacking authoritative confirmation."
        reason = (
            "The document matched a local synthetic reference record, but this system does not possess direct, authenticated "
            "integration with the official issuing authority. Per strict evidence guidelines, a local demo cache match alone cannot certify a document as REAL."
        )
        recommended_actions = [
            "Contact issuing registrar or utilize official government/institutional verification portal.",
            "Verify presence of physical security features (embossed seals, microprint, watermark) under manual inspection."
        ]
    elif not ref_found:
        headline = "Review Required: Unregistered document with no matching reference record."
        reason = (
            "No matching credential could be found in reference repositories. Although no blatant tampering was detected, "
            "the absence of tampering artifacts does NOT certify that a document is genuine."
        )
        recommended_actions = [
            "Verify whether the issuing institution provides an online verification portal or digital signature.",
            "Add institution reference records to repository if this is a supported credential schema.",
            "Perform manual review of document authenticity."
        ]
    else:
        headline = "Review Required: Inconclusive evidence requiring human specialist inspection."
        reason = "Analysis resulted in partial matches or non-critical anomalies that require manual discretion."
        recommended_actions = [
            "Inspect the forensic heatmap overlay to evaluate flagged candidate regions.",
            "Review OCR extracted fields and manually correct any misread characters."
        ]
        
    limitations = [
        "Automated screening provides decision support and does not replace official confirmation from the issuing authority.",
        "Unregistered documents cannot be authenticated without issuer verification."
    ]
    
    return {
        "outcome": outcome,
        "headline": headline,
        "reason": reason,
        "severity": "MEDIUM",
        "badge_class": "badge-suspicious",
        "evidence_checklist": evidence_checklist,
        "limitations": limitations,
        "recommended_actions": recommended_actions
    }
