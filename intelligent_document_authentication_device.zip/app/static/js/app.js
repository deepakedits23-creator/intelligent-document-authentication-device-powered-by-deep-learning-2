/**
 * DOCUMENT VERIFIER — Main Application Controller
 * QUANTIX 2K26 Hackathon | Developed by Deepak & Team
 * Single Page Application Router, File Upload, Verification Pipeline,
 * Live Results Dashboard, Demo Center, Case History, and Reference Manager.
 */

class DocumentVerifierApp {
  constructor() {
    this.currentCase = null;
    this.selectedFile = null;
    this.activeVisualTab = 'original';

    this.initNavigation();
    this.initUpload();
    this.initDemoCenter();
    this.initHistory();
    this.initReferenceManager();
    this.loadHealth();
  }

  // ==================== NAVIGATION ROUTER ====================
  initNavigation() {
    window.addEventListener('hashchange', () => this.handleHashChange());
    document.querySelectorAll('.nav-item a, [data-nav]').forEach(el => {
      el.addEventListener('click', (e) => {
        const target = el.getAttribute('data-nav') || el.getAttribute('href').replace('#', '');
        if (target) {
          e.preventDefault();
          this.navigateTo(target);
        }
      });
    });

    // Initial route
    const initialRoute = window.location.hash.replace('#', '') || 'home';
    this.navigateTo(initialRoute, false);
  }

  navigateTo(sectionId, updateHash = true) {
    if (updateHash) {
      window.location.hash = `#${sectionId}`;
    }

    // Stop camera scanner if leaving camera section
    if (sectionId !== 'camera' && window.cameraScanner) {
      window.cameraScanner.stopCamera();
    }

    document.querySelectorAll('.app-section').forEach(sec => sec.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));

    const targetSec = document.getElementById(`section-${sectionId}`);
    if (targetSec) {
      targetSec.classList.add('active');
    }

    const targetNav = document.getElementById(`nav-${sectionId}`);
    if (targetNav) {
      targetNav.classList.add('active');
    }

    // Section specific loaders
    if (sectionId === 'history') this.loadHistory();
    if (sectionId === 'reference') this.loadReferenceRecords();
    if (sectionId === 'demos') this.loadDemoSamples();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  handleHashChange() {
    const route = window.location.hash.replace('#', '') || 'home';
    this.navigateTo(route, false);
  }

  // ==================== DOCUMENT UPLOAD ====================
  initUpload() {
    const dropzone = document.getElementById('upload-dropzone');
    const fileInput = document.getElementById('file-input');
    const previewCard = document.getElementById('file-preview-card');
    const removeBtn = document.getElementById('btn-remove-file');
    const verifyBtn = document.getElementById('btn-start-verify');

    if (!dropzone || !fileInput) return;

    ['dragenter', 'dragover'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        dropzone.classList.add('drag-over');
      });
    });

    ['dragleave', 'drop'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        dropzone.classList.remove('drag-over');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files && files.length > 0) {
        this.handleFileSelected(files[0]);
      }
    });

    dropzone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files.length > 0) {
        this.handleFileSelected(fileInput.files[0]);
      }
    });

    if (removeBtn) {
      removeBtn.addEventListener('click', () => {
        this.selectedFile = null;
        fileInput.value = '';
        previewCard.style.display = 'none';
        dropzone.style.display = 'block';
      });
    }

    if (verifyBtn) {
      verifyBtn.addEventListener('click', () => {
        if (!this.selectedFile) {
          this.showToast('Please select a document to verify.', 'amber');
          return;
        }
        const formData = new FormData();
        formData.append('file', this.selectedFile);
        this.processUploadedFile(formData, '/api/upload');
      });
    }
  }

  handleFileSelected(file) {
    const validExtensions = ['.pdf', '.png', '.jpg', '.jpeg'];
    const fileName = file.name.toLowerCase();
    const isValid = validExtensions.some(ext => fileName.endsWith(ext));

    if (!isValid) {
      this.showToast('Unsupported file format. Please upload PDF, PNG, JPG, or JPEG.', 'red');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      this.showToast('File size exceeds 15 MB limit.', 'red');
      return;
    }

    this.selectedFile = file;

    const dropzone = document.getElementById('upload-dropzone');
    const previewCard = document.getElementById('file-preview-card');
    const nameEl = document.getElementById('preview-file-name');
    const detailsEl = document.getElementById('preview-file-details');
    const thumbEl = document.getElementById('preview-file-thumb');

    nameEl.innerText = file.name;
    const sizeKB = (file.size / 1024).toFixed(1);
    detailsEl.innerText = `${sizeKB} KB • ${file.type || 'Document'}`;

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => { thumbEl.src = e.target.result; };
      reader.readAsDataURL(file);
    } else {
      // PDF generic icon
      thumbEl.src = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' fill='%2300E5FF' viewBox='0 0 24 24'><path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z'/></svg>";
    }

    dropzone.style.display = 'none';
    previewCard.style.display = 'flex';
  }

  // ==================== PROCESS VERIFICATION ====================
  async processUploadedFile(formData, endpoint) {
    this.showLoading(true, "Examining document with deep learning & computer vision...");
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        body: formData
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Verification process encountered an error.');
      }

      const caseData = await res.json();
      this.currentCase = caseData;
      this.renderVerificationResults(caseData);
      this.navigateTo('results');
      this.showToast(`Verification completed: ${caseData.decision.outcome}`, 'green');
    } catch (e) {
      console.error(e);
      this.showToast(`Error: ${e.message}`, 'red');
    } finally {
      this.showLoading(false);
    }
  }

  // ==================== RENDER RESULTS DASHBOARD ====================
  renderVerificationResults(data) {
    const decision = data.decision || {};
    const outcome = decision.outcome || "SUSPICIOUS — MANUAL REVIEW REQUIRED";
    const extracted = data.extracted_data || {};
    const forensics = data.forensic_data || {};
    const reference = data.reference_data || {};

    // 1. Status Banner
    const banner = document.getElementById('results-status-banner');
    banner.className = 'status-banner';
    if (outcome.includes('REAL')) {
      banner.classList.add('banner-real');
    } else if (outcome.includes('FAKE')) {
      banner.classList.add('banner-fake');
    } else {
      banner.classList.add('banner-suspicious');
    }

    document.getElementById('res-outcome-label').innerText = outcome;
    document.getElementById('res-headline').innerText = decision.headline || "";
    document.getElementById('res-reason').innerText = decision.reason || "";
    document.getElementById('res-case-id').innerText = data.case_uid || "UNKNOWN";

    // 2. Document Preview & Forensics Heatmap
    const previewImg = document.getElementById('visualizer-img');
    const originalUrl = data.image_url || (data.image_path ? `/api/files/image/${data.image_path}` : '');
    const heatmapUrl = data.heatmap_url || (data.heatmap_path ? `/api/files/heatmap/${data.heatmap_path}` : originalUrl);

    previewImg.src = originalUrl;
    this.activeVisualTab = 'original';

    document.querySelectorAll('.visual-tab-btn').forEach(btn => {
      btn.classList.remove('active');
      if (btn.dataset.tab === 'original') btn.classList.add('active');
      btn.onclick = () => {
        document.querySelectorAll('.visual-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if (btn.dataset.tab === 'heatmap') {
          previewImg.src = heatmapUrl;
        } else {
          previewImg.src = originalUrl;
        }
      };
    });

    // 3. Extracted Fields Table with Editing Support
    const fieldsBody = document.getElementById('extracted-fields-body');
    fieldsBody.innerHTML = `
      <tr>
        <td class="field-label">Document Type</td>
        <td><input type="text" id="edit-doc-type" class="field-value-input" value="${extracted.doc_type || ''}" /></td>
      </tr>
      <tr>
        <td class="field-label">Document / ID Number</td>
        <td><input type="text" id="edit-doc-number" class="field-value-input" value="${extracted.doc_number || ''}" /></td>
      </tr>
      <tr>
        <td class="field-label">Cardholder / Name</td>
        <td><input type="text" id="edit-holder-name" class="field-value-input" value="${extracted.holder_name || ''}" /></td>
      </tr>
      <tr>
        <td class="field-label">Issue Date</td>
        <td><input type="text" id="edit-issue-date" class="field-value-input" value="${extracted.issue_date || ''}" /></td>
      </tr>
      <tr>
        <td class="field-label">Issuing Institution</td>
        <td><input type="text" id="edit-issuer-name" class="field-value-input" value="${extracted.issuer_name || ''}" /></td>
      </tr>
      <tr>
        <td class="field-label">OCR Recognition Engine</td>
        <td style="color: var(--text-secondary);">${data.ocr_engine || 'Multi-Stage OCR'} (${data.ocr_confidence || 90}% confidence)</td>
      </tr>
    `;

    // Re-evaluate button handler
    const reEvalBtn = document.getElementById('btn-re-evaluate');
    if (reEvalBtn) {
      reEvalBtn.onclick = () => this.handleReEvaluate();
    }

    // 4. Reference Comparison
    const refSourceEl = document.getElementById('ref-source-badge');
    refSourceEl.innerText = reference.source_type || 'NO REFERENCE RECORD FOUND';

    const refTableBody = document.getElementById('reference-table-body');
    refTableBody.innerHTML = '';
    const comparisons = reference.field_comparisons || [];

    if (comparisons.length > 0) {
      comparisons.forEach(c => {
        let badgeClass = 'badge-match';
        if (c.status === 'MISMATCH') badgeClass = 'badge-mismatch';
        if (c.status === 'PARTIAL') badgeClass = 'badge-partial';
        if (c.status.includes('MISSING')) badgeClass = 'badge-missing';

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="font-weight: 600;">${c.field_name}</td>
          <td>${c.extracted_value}</td>
          <td>${c.reference_value}</td>
          <td><span class="badge ${badgeClass}">${c.status}</span></td>
        `;
        refTableBody.appendChild(tr);
      });
    } else {
      refTableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">No matching record found in demo reference repository.</td></tr>`;
    }

    // 5. Evidence Findings Checklist
    const evidenceListEl = document.getElementById('evidence-findings-list');
    evidenceListEl.innerHTML = '';
    const evidenceList = decision.evidence_checklist || [];

    if (evidenceList.length > 0) {
      evidenceList.forEach(ev => {
        const item = document.createElement('div');
        item.className = `evidence-item sev-${ev.severity}`;
        item.innerHTML = `
          <div class="evidence-header">
            <span class="evidence-title">${ev.title}</span>
            <span class="badge ${ev.severity === 'CRITICAL' ? 'badge-mismatch' : (ev.severity === 'HIGH' ? 'badge-partial' : 'badge-match')}">${ev.severity}</span>
          </div>
          <p class="evidence-body">${ev.summary}</p>
          <p class="evidence-impact">Why it matters: ${ev.impact}</p>
        `;
        evidenceListEl.appendChild(item);
      });
    } else {
      evidenceListEl.innerHTML = `<div style="color: var(--text-muted); padding: 1rem;">No elevated anomalies detected.</div>`;
    }

    // 6. Recommended Actions
    const actionListEl = document.getElementById('recommended-actions-list');
    actionListEl.innerHTML = '';
    const actions = decision.recommended_actions || [];
    actions.forEach(act => {
      const li = document.createElement('li');
      li.innerText = act;
      actionListEl.appendChild(li);
    });

    // 7. Limitations Notice
    const limitsListEl = document.getElementById('limitations-list');
    limitsListEl.innerHTML = '';
    const limits = decision.limitations || [];
    limits.forEach(lim => {
      const li = document.createElement('li');
      li.innerText = lim;
      limitsListEl.appendChild(li);
    });

    // Action download buttons
    document.getElementById('btn-download-pdf').onclick = () => {
      window.open(data.pdf_url || `/api/cases/${data.case_uid}/pdf`, '_blank');
    };
    document.getElementById('btn-download-json').onclick = () => {
      window.open(data.json_url || `/api/cases/${data.case_uid}/json`, '_blank');
    };
  }

  async handleReEvaluate() {
    if (!this.currentCase) return;

    const payload = {
      case_uid: this.currentCase.case_uid,
      doc_type: document.getElementById('edit-doc-type').value,
      doc_number: document.getElementById('edit-doc-number').value,
      holder_name: document.getElementById('edit-holder-name').value,
      issue_date: document.getElementById('edit-issue-date').value,
      issuer_name: document.getElementById('edit-issuer-name').value
    };

    this.showLoading(true, "Re-evaluating decision engine with user corrected fields...");
    try {
      const res = await fetch('/api/re-evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Re-evaluation failed.');
      const updatedCase = await res.json();
      this.currentCase = updatedCase;
      this.renderVerificationResults(updatedCase);
      this.showToast('Fields updated and case re-evaluated successfully!', 'green');
    } catch (e) {
      this.showToast(`Error: ${e.message}`, 'red');
    } finally {
      this.showLoading(false);
    }
  }

  // ==================== DEMO CENTER ====================
  initDemoCenter() {
    // Initial fetch of demo cards
  }

  async loadDemoSamples() {
    const grid = document.getElementById('demo-cards-container');
    grid.innerHTML = '<div style="color: var(--text-secondary); text-align: center; padding: 2rem;">Loading synthetic samples...</div>';
    try {
      const res = await fetch('/api/demo-samples');
      const data = await res.json();
      const samples = data.samples || [];

      grid.innerHTML = '';
      samples.forEach(s => {
        const card = document.createElement('div');
        card.className = 'demo-card';
        card.innerHTML = `
          <div>
            <span class="demo-expected-badge badge-${s.badge_color}">EXPECTED: ${s.expected_status}</span>
            <h3 class="demo-title">${s.title}</h3>
            <p class="demo-desc">${s.description}</p>
          </div>
          <div class="demo-actions">
            <button class="btn btn-primary btn-sm" onclick="window.app.loadDemoSample('${s.id}')">⚡ Run Live Demo</button>
            <a class="btn btn-secondary btn-sm" href="/api/demo-samples/${s.id}/download" download>Download Sample</a>
          </div>
        `;
        grid.appendChild(card);
      });
    } catch (e) {
      grid.innerHTML = `<div style="color: var(--status-fake);">Failed to load demo samples: ${e.message}</div>`;
    }
  }

  async loadDemoSample(sampleId) {
    this.showLoading(true, `Executing verification pipeline on ${sampleId}...`);
    try {
      const res = await fetch(`/api/demo-samples/${sampleId}/load`, { method: 'POST' });
      if (!res.ok) throw new Error('Failed to load demo sample.');
      const caseData = await res.json();
      this.currentCase = caseData;
      this.renderVerificationResults(caseData);
      this.navigateTo('results');
      this.showToast(`Demo executed: ${caseData.decision.outcome}`, 'green');
    } catch (e) {
      this.showToast(`Error: ${e.message}`, 'red');
    } finally {
      this.showLoading(false);
    }
  }

  // ==================== VERIFICATION HISTORY ====================
  initHistory() {
    const searchInput = document.getElementById('history-search');
    const filterSelect = document.getElementById('history-filter-status');
    if (searchInput) {
      searchInput.addEventListener('input', () => this.loadHistory());
    }
    if (filterSelect) {
      filterSelect.addEventListener('change', () => this.loadHistory());
    }
  }

  async loadHistory() {
    const tbody = document.getElementById('history-table-body');
    const search = document.getElementById('history-search')?.value || '';
    const status = document.getElementById('history-filter-status')?.value || 'ALL';

    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-secondary); padding: 1.5rem;">Loading audit history...</td></tr>';
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (status !== 'ALL') params.append('status', status);

      const res = await fetch(`/api/cases?${params.toString()}`);
      const data = await res.json();
      const cases = data.cases || [];

      tbody.innerHTML = '';
      if (cases.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No verification records found.</td></tr>';
        return;
      }

      cases.forEach(c => {
        let badgeClass = 'badge-match';
        if (c.decision_outcome.includes('FAKE')) badgeClass = 'badge-mismatch';
        if (c.decision_outcome.includes('SUSPICIOUS')) badgeClass = 'badge-partial';

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="font-family: monospace; font-weight: 700; color: var(--accent-cyan);">${c.case_uid}</td>
          <td>${c.created_at.replace('T', ' ').substring(0, 19)}</td>
          <td>${c.doc_type || 'Unspecified'}</td>
          <td><span class="badge ${badgeClass}">${c.decision_outcome}</span></td>
          <td style="font-family: monospace; font-size: 0.75rem; color: var(--text-muted);">${c.file_hash.substring(0, 16)}...</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="window.app.openCaseHistory('${c.case_uid}')">Open</button>
            <a class="btn btn-secondary btn-sm" href="/api/cases/${c.case_uid}/pdf" target="_blank">PDF</a>
            <button class="btn btn-danger btn-sm" onclick="window.app.deleteCase('${c.case_uid}')">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (e) {
      tbody.innerHTML = `<tr><td colspan="6" style="color: var(--status-fake); text-align: center;">Error loading history: ${e.message}</td></tr>`;
    }
  }

  async openCaseHistory(caseUid) {
    this.showLoading(true, "Retrieving historical case record...");
    try {
      const res = await fetch(`/api/cases/${caseUid}`);
      if (!res.ok) throw new Error("Case record not found.");
      const caseData = await res.json();
      this.currentCase = caseData;
      this.renderVerificationResults(caseData);
      this.navigateTo('results');
    } catch (e) {
      this.showToast(`Error: ${e.message}`, 'red');
    } finally {
      this.showLoading(false);
    }
  }

  async deleteCase(caseUid) {
    if (!confirm(`Are you sure you want to delete case ${caseUid}? This action cannot be undone.`)) return;

    try {
      const res = await fetch(`/api/cases/${caseUid}`, { method: 'DELETE' });
      if (!res.ok) throw new Error("Failed to delete case.");
      this.showToast(`Case ${caseUid} deleted.`, 'green');
      this.loadHistory();
    } catch (e) {
      this.showToast(`Error: ${e.message}`, 'red');
    }
  }

  // ==================== REFERENCE RECORD MANAGEMENT ====================
  initReferenceManager() {
    const addBtn = document.getElementById('btn-add-ref-record');
    const modal = document.getElementById('ref-modal');
    const closeBtn = document.getElementById('btn-close-ref-modal');
    const form = document.getElementById('form-add-ref-record');

    if (addBtn && modal) {
      addBtn.onclick = () => { modal.style.display = 'flex'; };
    }
    if (closeBtn && modal) {
      closeBtn.onclick = () => { modal.style.display = 'none'; };
    }
    if (form) {
      form.onsubmit = async (e) => {
        e.preventDefault();
        const payload = {
          record_id: document.getElementById('ref-input-id').value,
          doc_type: document.getElementById('ref-input-type').value,
          issuer_name: document.getElementById('ref-input-issuer').value,
          holder_name: document.getElementById('ref-input-name').value,
          issue_date: document.getElementById('ref-input-date').value,
          status: document.getElementById('ref-input-status').value,
          is_authoritative: parseInt(document.getElementById('ref-input-auth').value)
        };

        try {
          const res = await fetch('/api/reference-records', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          if (!res.ok) throw new Error("Failed to save reference record.");
          modal.style.display = 'none';
          form.reset();
          this.loadReferenceRecords();
          this.showToast(`Synthetic record ${payload.record_id} registered.`, 'green');
        } catch (err) {
          this.showToast(`Error: ${err.message}`, 'red');
        }
      };
    }
  }

  async loadReferenceRecords() {
    const tbody = document.getElementById('reference-table-body-admin');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--text-secondary); padding: 1.5rem;">Loading reference repository...</td></tr>';
    try {
      const res = await fetch('/api/reference-records');
      const data = await res.json();
      const records = data.records || [];

      tbody.innerHTML = '';
      records.forEach(r => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="font-family: monospace; font-weight: 700; color: var(--accent-cyan);">${r.record_id}</td>
          <td>${r.doc_type}</td>
          <td>${r.holder_name}</td>
          <td>${r.issuer_name}</td>
          <td>${r.issue_date || '-'}</td>
          <td><span class="badge ${r.is_authoritative ? 'badge-match' : 'badge-missing'}">${r.is_authoritative ? 'AUTHORITATIVE' : 'LOCAL DEMO'}</span></td>
          <td>
            <button class="btn btn-danger btn-sm" onclick="window.app.deleteReferenceRecord('${r.id}')">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (e) {
      tbody.innerHTML = `<tr><td colspan="7" style="color: var(--status-fake); text-align: center;">Error loading reference database: ${e.message}</td></tr>`;
    }
  }

  async deleteReferenceRecord(id) {
    if (!confirm("Delete this synthetic reference record?")) return;
    try {
      const res = await fetch(`/api/reference-records/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error("Delete failed.");
      this.showToast("Reference record removed.", 'green');
      this.loadReferenceRecords();
    } catch (e) {
      this.showToast(`Error: ${e.message}`, 'red');
    }
  }

  // ==================== SYSTEM HEALTH ====================
  async loadHealth() {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      const ocrEngineEl = document.getElementById('settings-active-ocr');
      if (ocrEngineEl) ocrEngineEl.innerText = data.active_engine;
    } catch (e) {
      console.warn("Health check error:", e);
    }
  }

  // ==================== UI HELPERS ====================
  showLoading(show, message = "Processing...") {
    const overlay = document.getElementById('loading-overlay');
    const msgEl = document.getElementById('loading-message');
    if (overlay) {
      overlay.style.display = show ? 'flex' : 'none';
      if (msgEl) msgEl.innerText = message;
    }
  }

  showToast(message, type = 'cyan') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    let icon = 'ℹ️';
    if (type === 'green') icon = '✓';
    if (type === 'red') icon = '✕';
    if (type === 'amber') icon = '⚠️';

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }
}

// Global bootstrap
document.addEventListener('DOMContentLoaded', () => {
  window.app = new DocumentVerifierApp();
});
