/**
 * DOCUMENT VERIFIER — Live Laptop Camera Scanner
 * Uses browser MediaDevices API (getUserMedia) with document guide frame,
 * real-time quality diagnostics, boundary detection, and track lifecycle management.
 */

class CameraScanner {
  constructor() {
    this.video = document.getElementById('camera-video');
    this.canvas = document.getElementById('camera-canvas');
    this.startBtn = document.getElementById('btn-camera-start');
    this.stopBtn = document.getElementById('btn-camera-stop');
    this.captureBtn = document.getElementById('btn-camera-capture');
    this.retakeBtn = document.getElementById('btn-camera-retake');
    this.useBtn = document.getElementById('btn-camera-use');
    this.statusBadge = document.getElementById('camera-status-text');
    this.diagnosticsBox = document.getElementById('camera-diagnostics');
    this.fallbackNotice = document.getElementById('camera-fallback-notice');

    this.stream = null;
    this.capturedBlob = null;
    this.analysisInterval = null;

    this.initEvents();
  }

  initEvents() {
    if (this.startBtn) this.startBtn.addEventListener('click', () => this.startCamera());
    if (this.stopBtn) this.stopBtn.addEventListener('click', () => this.stopCamera());
    if (this.captureBtn) this.captureBtn.addEventListener('click', () => this.captureFrame());
    if (this.retakeBtn) this.retakeBtn.addEventListener('click', () => this.retake());
    if (this.useBtn) this.useBtn.addEventListener('click', () => this.useCapturedDocument());
  }

  async startCamera() {
    // Check getUserMedia support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      this.showFallback("Webcam API (getUserMedia) is not supported by your browser or requires localhost / HTTPS.");
      return;
    }

    try {
      this.updateStatus("Requesting camera access...", "var(--accent-cyan)");
      
      const constraints = {
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1920, min: 1280 },
          height: { ideal: 1080, min: 720 }
        },
        audio: false // Explicitly no microphone access
      };

      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.video.srcObject = this.stream;
      this.video.style.display = "block";
      this.canvas.style.display = "none";
      await this.video.play();

      this.startBtn.style.display = "none";
      this.stopBtn.style.display = "inline-flex";
      this.captureBtn.style.display = "inline-flex";
      this.retakeBtn.style.display = "none";
      this.useBtn.style.display = "none";
      this.fallbackNotice.style.display = "none";

      this.updateStatus("Camera Active - Align document inside frame", "var(--status-real)");
      this.startRealtimeDiagnostics();
    } catch (err) {
      console.warn("Camera access denied or failed:", err);
      let msg = "Camera access was denied or is unavailable.";
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        msg = "Camera permission was denied. Please allow camera permissions in your browser or switch to the file upload tab.";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        msg = "No webcam device was detected on this laptop.";
      } else if (window.location.protocol !== "https:" && window.location.hostname !== "localhost" && window.location.hostname !== "127.0.0.1") {
        msg = "Browser camera access requires HTTPS or localhost.";
      }
      this.showFallback(msg);
    }
  }

  stopCamera() {
    if (this.analysisInterval) {
      clearInterval(this.analysisInterval);
      this.analysisInterval = null;
    }

    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }

    if (this.video) {
      this.video.srcObject = null;
    }

    this.startBtn.style.display = "inline-flex";
    this.stopBtn.style.display = "none";
    this.captureBtn.style.display = "none";
    this.retakeBtn.style.display = "none";
    this.useBtn.style.display = "none";

    this.updateStatus("Camera Stopped", "var(--text-muted)");
  }

  startRealtimeDiagnostics() {
    // Periodically assess frame luminance & blur on a temporary canvas
    const sampleCanvas = document.createElement("canvas");
    const sampleCtx = sampleCanvas.getContext("2d");

    this.analysisInterval = setInterval(() => {
      if (!this.stream || !this.video || this.video.videoWidth === 0) return;

      sampleCanvas.width = 160;
      sampleCanvas.height = 120;
      sampleCtx.drawImage(this.video, 0, 0, 160, 120);

      const frameData = sampleCtx.getImageData(0, 0, 160, 120).data;
      let totalLum = 0;
      for (let i = 0; i < frameData.length; i += 4) {
        // Luminance formula
        totalLum += (0.299 * frameData[i] + 0.587 * frameData[i+1] + 0.114 * frameData[i+2]);
      }
      const meanLum = totalLum / (frameData.length / 4);

      if (meanLum < 45) {
        this.updateDiagnostics("Dim lighting detected. Increase ambient light for better OCR.", "var(--status-suspicious)");
      } else if (meanLum > 235) {
        this.updateDiagnostics("Strong glare detected. Adjust laptop or document angle.", "var(--status-suspicious)");
      } else {
        this.updateDiagnostics("Lighting level is good. Keep document flat and still.", "var(--status-real)");
      }
    }, 1500);
  }

  captureFrame() {
    if (!this.stream || !this.video) return;

    const w = this.video.videoWidth || 1280;
    const h = this.video.videoHeight || 720;

    this.canvas.width = w;
    this.canvas.height = h;
    const ctx = this.canvas.getContext('2d');
    ctx.drawImage(this.video, 0, 0, w, h);

    this.video.style.display = "none";
    this.canvas.style.display = "block";

    this.captureBtn.style.display = "none";
    this.retakeBtn.style.display = "inline-flex";
    this.useBtn.style.display = "inline-flex";

    this.canvas.toBlob((blob) => {
      this.capturedBlob = blob;
      this.updateStatus("Frame Captured - Review or Submit", "var(--accent-cyan)");
      this.updateDiagnostics(`Captured: ${w}x${h} resolution. Click 'Verify Document' to analyze.`, "var(--accent-cyan)");
    }, 'image/jpeg', 0.95);
  }

  retake() {
    this.capturedBlob = null;
    this.video.style.display = "block";
    this.canvas.style.display = "none";

    this.captureBtn.style.display = "inline-flex";
    this.retakeBtn.style.display = "none";
    this.useBtn.style.display = "none";

    this.updateStatus("Camera Active - Align document inside frame", "var(--status-real)");
  }

  async useCapturedDocument() {
    if (!this.capturedBlob) {
      alert("Please capture a document frame first.");
      return;
    }

    this.stopCamera();

    // Trigger verification pipeline with captured frame
    const formData = new FormData();
    formData.append("file", this.capturedBlob, "webcam_scan.jpg");
    formData.append("auto_warp", "true");

    if (window.app && typeof window.app.processUploadedFile === "function") {
      window.app.processUploadedFile(formData, "/api/scan");
    }
  }

  showFallback(message) {
    this.stopCamera();
    if (this.fallbackNotice) {
      this.fallbackNotice.innerHTML = `
        <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid var(--status-fake); border-radius: var(--radius-md); padding: 1.25rem; margin-top: 1rem;">
          <h4 style="color: var(--status-fake); margin-bottom: 0.5rem;">⚠️ Camera Unavailable</h4>
          <p style="font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 1rem;">${message}</p>
          <button class="btn btn-primary btn-sm" onclick="window.app.navigateTo('verify')">Use File Upload Instead</button>
        </div>
      `;
      this.fallbackNotice.style.display = "block";
    }
    this.updateStatus("Camera Access Unavailable", "var(--status-fake)");
  }

  updateStatus(text, color) {
    if (this.statusBadge) {
      this.statusBadge.innerText = text;
      this.statusBadge.style.color = color || "var(--text-secondary)";
    }
  }

  updateDiagnostics(text, color) {
    if (this.diagnosticsBox) {
      this.diagnosticsBox.innerHTML = `<span style="color: ${color || 'var(--text-secondary)'};">● ${text}</span>`;
    }
  }
}

// Instantiate scanner when DOM loads
document.addEventListener('DOMContentLoaded', () => {
  window.cameraScanner = new CameraScanner();
});
