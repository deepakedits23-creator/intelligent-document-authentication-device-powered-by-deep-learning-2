import re
import difflib
from typing import Dict, Any, List, Optional
from app.database import get_reference_record_by_number, get_reference_records

def normalize_string(s: Optional[str]) -> str:
    """Normalize string for safe formatting comparison: lowercase, strip punctuation and whitespace."""
    if not s:
        return ""
    return re.sub(r"[^a-zA-Z0-9]", "", s).lower()

def calculate_name_similarity(name1: Optional[str], name2: Optional[str]) -> float:
    """Calculate normalized token-based name similarity score between 0.0 and 1.0."""
    if not name1 or not name2:
        return 0.0
    
    n1_clean = name1.strip().lower()
    n2_clean = name2.strip().lower()
    
    if n1_clean == n2_clean:
        return 1.0
        
    # Levenshtein ratio
    ratio = difflib.SequenceMatcher(None, n1_clean, n2_clean).ratio()
    
    # Token set comparison (e.g. "Deepak Kumar" vs "Kumar Deepak")
    tokens1 = set(n1_clean.split())
    tokens2 = set(n2_clean.split())
    if tokens1 and tokens2:
        overlap = len(tokens1.intersection(tokens2)) / max(len(tokens1), len(tokens2))
        return max(ratio, overlap)
        
    return ratio

def compare_with_reference(extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
    """
    Compare extracted OCR fields against reference database.
    Explicitly labels local synthetic records as non-authoritative demo records.
    """
    doc_number = extracted_fields.get("doc_number")
    record = get_reference_record_by_number(doc_number) if doc_number else None
    
    if not record:
        return {
            "record_found": False,
            "source_type": "NO REFERENCE RECORD FOUND",
            "source_authority_level": "NONE",
            "is_authoritative": False,
            "matched_record": None,
            "field_comparisons": [],
            "has_critical_conflict": False,
            "summary": "Document ID does not exist in demo reference database or reference records repository."
        }

    # Determine authority label
    is_authoritative = bool(record["is_authoritative"])
    source_type = (
        "SIMULATED AUTHORITATIVE ISSUER LEDGER (TEST RECORD)"
        if is_authoritative
        else "DEMO REFERENCE DATABASE (NON-AUTHORITATIVE LOCAL CACHE)"
    )
    
    field_comparisons = []
    has_critical_conflict = False
    
    # 1. Document ID Comparison
    doc_num_ref = record["record_id"]
    doc_num_ext = extracted_fields.get("doc_number")
    num_sim = calculate_name_similarity(doc_num_ext, doc_num_ref)
    num_status = "MATCH" if num_sim > 0.85 else "MISMATCH"
    field_comparisons.append({
        "field_name": "Document / Reference Number",
        "extracted_value": doc_num_ext or "[Not Found in Document]",
        "reference_value": doc_num_ref,
        "status": num_status,
        "confidence": round(num_sim * 100, 1),
        "explanation": "Exact or normalized match against registered identifier." if num_status == "MATCH" else "Identifier differs from registry format."
    })
    
    # 2. Holder Name Comparison (CRITICAL FIELD)
    name_ref = record["holder_name"]
    name_ext = extracted_fields.get("holder_name")
    name_sim = calculate_name_similarity(name_ext, name_ref)
    
    if not name_ext:
        name_status = "MISSING_IN_DOC"
        name_expl = "Holder name could not be confidently identified in document text."
    elif name_sim >= 0.85:
        name_status = "MATCH"
        name_expl = f"Holder name matches reference record with {name_sim*100:.1f}% string similarity."
    elif name_sim >= 0.60:
        name_status = "PARTIAL"
        name_expl = f"Partial name match ({name_sim*100:.1f}% similarity). Possible transliteration or middle name abbreviation."
    else:
        name_status = "MISMATCH"
        has_critical_conflict = True
        name_expl = f"CRITICAL CONFLICT: Document states '{name_ext}', but registered record for this ID belongs to '{name_ref}'."
        
    field_comparisons.append({
        "field_name": "Holder Name",
        "extracted_value": name_ext or "[Not Found in Document]",
        "reference_value": name_ref,
        "status": name_status,
        "confidence": round(name_sim * 100, 1),
        "explanation": name_expl
    })
    
    # 3. Document Type Comparison
    type_ref = record["doc_type"]
    type_ext = extracted_fields.get("doc_type")
    type_sim = calculate_name_similarity(type_ext, type_ref)
    type_status = "MATCH" if type_sim >= 0.65 else ("PARTIAL" if type_sim >= 0.4 else "MISMATCH")
    field_comparisons.append({
        "field_name": "Document Type",
        "extracted_value": type_ext or "[Unspecified]",
        "reference_value": type_ref,
        "status": type_status,
        "confidence": round(type_sim * 100, 1),
        "explanation": "Classification matches credential taxonomy." if type_status == "MATCH" else "Discrepancy in document type category."
    })
    
    # 4. Issuer Authority Comparison
    issuer_ref = record["issuer_name"]
    issuer_ext = extracted_fields.get("issuer_name")
    issuer_sim = calculate_name_similarity(issuer_ext, issuer_ref)
    issuer_status = "MATCH" if issuer_sim >= 0.65 else ("PARTIAL" if issuer_sim >= 0.35 else "MISMATCH")
    field_comparisons.append({
        "field_name": "Issuing Authority",
        "extracted_value": issuer_ext or "[Not Found]",
        "reference_value": issuer_ref,
        "status": issuer_status,
        "confidence": round(issuer_sim * 100, 1),
        "explanation": "Issuing organization aligns with registry." if issuer_status == "MATCH" else "Issuer text mismatch."
    })
    
    # 5. Issue Date Comparison (if available)
    date_ref = record.get("issue_date")
    date_ext = extracted_fields.get("issue_date")
    if date_ref and date_ext:
        date_sim = calculate_name_similarity(date_ext, date_ref)
        date_status = "MATCH" if date_sim > 0.8 else "MISMATCH"
        field_comparisons.append({
            "field_name": "Issue Date",
            "extracted_value": date_ext,
            "reference_value": date_ref,
            "status": date_status,
            "confidence": round(date_sim * 100, 1),
            "explanation": "Issue date corresponds to record entry." if date_status == "MATCH" else "Issue date does not match registered date."
        })
        if date_status == "MISMATCH":
            has_critical_conflict = True
            
    # 6. Registry Status Check
    reg_status = record.get("status", "ACTIVE")
    if reg_status != "ACTIVE":
        has_critical_conflict = True
        field_comparisons.append({
            "field_name": "Registry Status",
            "extracted_value": "Presented as Valid",
            "reference_value": reg_status,
            "status": "MISMATCH",
            "confidence": 100.0,
            "explanation": f"CRITICAL: Record is marked as {reg_status} in reference repository."
        })
        
    matches_count = sum(1 for f in field_comparisons if f["status"] == "MATCH")
    total_count = len(field_comparisons)
    
    return {
        "record_found": True,
        "source_type": source_type,
        "source_authority_level": "AUTHORITATIVE_TEST_ENVIRONMENT" if is_authoritative else "DEMO_LOCAL_CACHE",
        "is_authoritative": is_authoritative,
        "matched_record": record,
        "field_comparisons": field_comparisons,
        "has_critical_conflict": has_critical_conflict,
        "matches_count": matches_count,
        "total_fields_compared": total_count,
        "summary": (
            f"Matched record {record['record_id']} with {matches_count}/{total_count} field correspondences. "
            + ("CRITICAL FIELD CONFLICT DETECTED." if has_critical_conflict else "Fields consistent.")
        )
    }
