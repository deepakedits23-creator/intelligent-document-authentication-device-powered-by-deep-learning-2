import pytest
from app.ocr_engine import clean_name_field, parse_extracted_fields

def test_clean_name_field():
    raw = "Deepak Kumar has been duly admitted to the Degree"
    cleaned = clean_name_field(raw)
    assert cleaned == "Deepak Kumar"

    raw2 = "Robert Vance date of issue: 2024-01-10"
    cleaned2 = clean_name_field(raw2)
    assert cleaned2 == "Robert Vance"

def test_parse_extracted_fields_degree():
    sample_text = """
    KSR INSTITUTE OF TECHNOLOGY
    DEGREE CERTIFICATE
    This is to certify that
    DEEPAK KUMAR
    has been duly admitted to the Degree of Bachelor of Engineering in
    COMPUTER SCIENCE AND ENGINEERING
    Document Number: KSR-2026-ENG-8492
    Date of Issue: 2026-05-15
    Issuer: KSR Institute of Technology
    Auth Ledger Token: AUTH-REG-99120-VERIFIED
    """
    fields = parse_extracted_fields(sample_text)
    assert fields["doc_type"] == "Degree Certificate"
    assert fields["doc_number"] == "KSR-2026-ENG-8492"
    assert "Deepak Kumar" in fields["holder_name"]
    assert fields["issue_date"] == "2026-05-15"
    assert "Ksr Institute Of Technology" in fields["issuer_name"] or "KSR Institute of Technology" in fields["issuer_name"]
    assert fields["auth_token"] == "AUTH-REG-99120-VERIFIED"

def test_parse_extracted_fields_id_card():
    sample_text = """
    NATIONAL DIGITAL IDENTITY CARD
    NATIONAL IDENTIFICATION AUTHORITY
    Card ID Number: NAT-2026-ID-4410
    Cardholder Name: Robert Vance
    Date of Issue: 2024-01-10
    Date of Expiry: 2034-01-10
    Authority: National Identification Authority
    """
    fields = parse_extracted_fields(sample_text)
    assert fields["doc_type"] == "National Identity Card"
    assert fields["doc_number"] == "NAT-2026-ID-4410"
    assert fields["holder_name"] == "Robert Vance"
    assert fields["issue_date"] == "2024-01-10"
    assert fields["expiry_date"] == "2034-01-10"

def test_parse_empty_text():
    fields = parse_extracted_fields("")
    assert fields["doc_type"] is None
    assert len(fields["missing_fields"]) > 0
