import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db
from app.demo_data import seed_reference_database, generate_synthetic_samples

@pytest.fixture(scope="module", autouse=True)
def setup_app():
    init_db()
    seed_reference_database()
    generate_synthetic_samples(force=False)

@pytest.fixture
def client():
    return TestClient(app)

def test_home_page_status(client):
    res = client.get("/")
    assert res.status_code == 200
    assert "Intelligent Document Authentication" in res.text or "INTELLIGENT DOCUMENT" in res.text

def test_health_check(client):
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert "Intelligent Document Authentication" in data["project"]

def test_list_demo_samples(client):
    res = client.get("/api/demo-samples")
    assert res.status_code == 200
    data = res.json()
    assert len(data["samples"]) == 5

def test_list_reference_records(client):
    res = client.get("/api/reference-records")
    assert res.status_code == 200
    data = res.json()
    assert data["count"] >= 4

def test_load_demo_sample_execution(client):
    # Test one-click demo pipeline execution on sample 1
    res = client.post("/api/demo-samples/sample-1/load")
    assert res.status_code == 200
    data = res.json()
    assert "case_uid" in data
    assert "decision" in data
    assert data["decision"]["outcome"] == "REAL — VERIFIED"

def test_load_demo_sample_altered(client):
    # Test one-click demo pipeline execution on sample 2 (altered ID)
    res = client.post("/api/demo-samples/sample-2/load")
    assert res.status_code == 200
    data = res.json()
    assert data["decision"]["outcome"] == "FAKE — EVIDENCE FOUND"
