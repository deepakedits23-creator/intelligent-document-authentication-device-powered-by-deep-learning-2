import pytest
from app.config import STATUS_REAL, STATUS_FAKE, STATUS_SUSPICIOUS
from app.decision_engine import evaluate_verification_case

def test_decision_real_verified():
    ocr_data = {
        "fields": {
            "doc_type": "Degree Certificate",
            "doc_number": "KSR-2026-ENG-8492",
            "holder_name": "Deepak Kumar"
        },
        "confidence": 95.0,
        "engine": "Test OCR"
    }
    forensic_data = {
        "forensic_risk": "LOW",
        "evidence_list": [
            {"id": "QUAL-SHARP", "severity": "INFO", "title": "Sharp", "description": "OK", "why_it_matters": "OK", "category": "QUALITY"}
        ],
        "quality": {"is_blurry": False}
    }
    reference_data = {
        "record_found": True,
        "is_authoritative": True,
        "has_critical_conflict": False,
        "summary": "Authoritative match confirmed."
    }

    result = evaluate_verification_case(ocr_data, forensic_data, reference_data)
    assert result["outcome"] == STATUS_REAL
    assert "Authenticity Confirmed" in result["headline"]

def test_decision_fake_on_identity_conflict():
    ocr_data = {
        "fields": {
            "doc_type": "National Identity Card",
            "doc_number": "NAT-2026-ID-4410",
            "holder_name": "Robert Vance"
        },
        "confidence": 92.0,
        "engine": "Test OCR"
    }
    forensic_data = {
        "forensic_risk": "LOW",
        "evidence_list": [],
        "quality": {"is_blurry": False}
    }
    reference_data = {
        "record_found": True,
        "is_authoritative": False,
        "has_critical_conflict": True,
        "summary": "CRITICAL CONFLICT: Document states Robert Vance, but ID is registered to Priya Sharma."
    }

    result = evaluate_verification_case(ocr_data, forensic_data, reference_data)
    assert result["outcome"] == STATUS_FAKE
    assert "Discrepancy Detected" in result["headline"]

def test_decision_fake_on_tampering():
    ocr_data = {
        "fields": {"doc_number": "EXP-2025-CYBER-993", "holder_name": "Alex Mercer"},
        "confidence": 88.0,
        "engine": "Test OCR"
    }
    forensic_data = {
        "forensic_risk": "HIGH",
        "anomaly_boxes_count": 5,
        "evidence_list": [
            {"id": "META-EDIT-TOOL", "severity": "HIGH", "title": "Photoshop", "description": "Photoshop EXIF", "why_it_matters": "Altered", "category": "METADATA"},
            {"id": "FORENSIC-ELA-01", "severity": "HIGH", "title": "ELA clusters", "description": "Compression anomaly", "why_it_matters": "Spliced", "category": "COMPRESSION"}
        ],
        "quality": {"is_blurry": False}
    }
    reference_data = {
        "record_found": True,
        "is_authoritative": False,
        "has_critical_conflict": False,
        "summary": "Record found."
    }

    result = evaluate_verification_case(ocr_data, forensic_data, reference_data)
    assert result["outcome"] == STATUS_FAKE
    assert "Tampering Evidence Detected" in result["headline"]

def test_decision_suspicious_on_blurry():
    ocr_data = {
        "fields": {"missing_fields": ["doc_number", "holder_name"]},
        "confidence": 35.0,
        "engine": "Test OCR"
    }
    forensic_data = {
        "forensic_risk": "HIGH",
        "evidence_list": [
            {"id": "QUAL-BLUR", "severity": "HIGH", "title": "Severe blur", "description": "Defocus", "why_it_matters": "Unreadable", "category": "QUALITY"}
        ],
        "quality": {"is_blurry": True}
    }
    reference_data = {"record_found": False, "is_authoritative": False, "has_critical_conflict": False}

    result = evaluate_verification_case(ocr_data, forensic_data, reference_data)
    assert result["outcome"] == STATUS_SUSPICIOUS
    assert "Image quality too degraded" in result["headline"]

def test_decision_suspicious_on_local_demo_match():
    ocr_data = {
        "fields": {"doc_number": "NAT-2026-ID-4410", "holder_name": "Priya Sharma"},
        "confidence": 90.0,
        "engine": "Test OCR"
    }
    forensic_data = {
        "forensic_risk": "LOW",
        "evidence_list": [],
        "quality": {"is_blurry": False}
    }
    reference_data = {
        "record_found": True,
        "is_authoritative": False,  # Non-authoritative local cache
        "has_critical_conflict": False,
        "summary": "Matches local demo record."
    }

    result = evaluate_verification_case(ocr_data, forensic_data, reference_data)
    assert result["outcome"] == STATUS_SUSPICIOUS
    assert "Matches local demo reference cache" in result["headline"]
