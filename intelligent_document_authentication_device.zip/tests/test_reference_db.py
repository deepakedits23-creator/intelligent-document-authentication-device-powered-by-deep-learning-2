import pytest
from app.database import init_db
from app.demo_data import seed_reference_database
from app.reference_db import (
    normalize_string,
    calculate_name_similarity,
    compare_with_reference
)

@pytest.fixture(autouse=True)
def setup_database():
    init_db()
    seed_reference_database()

def test_normalize_string():
    assert normalize_string("KSR-2026-ENG-8492") == "ksr2026eng8492"
    assert normalize_string(" Deepak  Kumar! ") == "deepakkumar"

def test_calculate_name_similarity():
    assert calculate_name_similarity("Deepak Kumar", "Deepak Kumar") == 1.0
    assert calculate_name_similarity("Deepak Kumar", "Kumar Deepak") >= 0.8
    assert calculate_name_similarity("Robert Vance", "Priya Sharma") < 0.4

def test_compare_with_reference_authoritative_match():
    extracted = {
        "doc_number": "KSR-2026-ENG-8492",
        "holder_name": "Deepak Kumar",
        "doc_type": "Degree Certificate",
        "issuer_name": "KSR Institute of Technology",
        "issue_date": "2026-05-15"
    }
    res = compare_with_reference(extracted)
    assert res["record_found"] is True
    assert res["is_authoritative"] is True
    assert res["has_critical_conflict"] is False
    assert "AUTHORITATIVE" in res["source_type"]

def test_compare_with_reference_conflict():
    extracted = {
        "doc_number": "NAT-2026-ID-4410",
        "holder_name": "Robert Vance",
        "doc_type": "National Identity Card",
        "issuer_name": "National Identification Authority"
    }
    res = compare_with_reference(extracted)
    assert res["record_found"] is True
    assert res["has_critical_conflict"] is True
    
    # Check that Holder Name has MISMATCH status
    name_comp = next(c for c in res["field_comparisons"] if c["field_name"] == "Holder Name")
    assert name_comp["status"] == "MISMATCH"

def test_compare_with_unregistered_document():
    extracted = {
        "doc_number": "UNREG-9999-FAKE",
        "holder_name": "Unknown User"
    }
    res = compare_with_reference(extracted)
    assert res["record_found"] is False
    assert "NO REFERENCE RECORD" in res["source_type"]
