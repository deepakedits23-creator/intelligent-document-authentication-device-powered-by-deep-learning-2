import pytest
import numpy as np
import cv2
from pathlib import Path
from app.forensics import assess_image_quality, compute_error_level_analysis, analyze_noise_and_splicing
from app.config import UPLOAD_DIR

def test_assess_image_quality_sharp():
    # Create sharp grid image
    img = np.zeros((600, 800, 3), dtype=np.uint8)
    for i in range(0, 600, 20):
        img[i:i+10, :] = 255
    evidence, quality = assess_image_quality(img)
    assert quality["is_blurry"] is False
    assert quality["width"] == 800
    assert quality["height"] == 600

def test_assess_image_quality_blurry():
    # Create blurry image
    img = np.ones((600, 800, 3), dtype=np.uint8) * 128
    blurred = cv2.GaussianBlur(img, (45, 45), 20)
    evidence, quality = assess_image_quality(blurred)
    assert quality["is_blurry"] is True

def test_compute_error_level_analysis():
    img = np.ones((400, 500, 3), dtype=np.uint8) * 200
    cv2.putText(img, "TEST CERTIFICATE", (50, 150), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 2)
    
    evidence, ela_summary, diff_scaled, ela_boxes = compute_error_level_analysis(img, UPLOAD_DIR, "TEST_UID")
    assert "mean_error" in ela_summary
    assert diff_scaled.shape == img.shape

def test_analyze_noise_and_splicing():
    img = np.ones((400, 500, 3), dtype=np.uint8) * 240
    evidence, noise_summary, splicing_boxes = analyze_noise_and_splicing(img)
    assert "noise_variance_mean" in noise_summary
